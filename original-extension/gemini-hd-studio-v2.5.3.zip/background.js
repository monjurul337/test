// Gemini HD Studio: Wallpaper Set Designer, AI Metadata & Panel Uploader (v2.5.0)
// Background Service Worker (Manifest V3)
//
// Features:
// 1. Zedge & Hub Wallpaper Sets (Dual 2x, 24-Hour 4x, Battery Level 6x, Single + 1:1/Landscape Companion, Mix Batch).
// 2. AI Set Director (Gemini plans story arc, neutral anchor, color palette & quantitative per-stage directions).
// 3. Story Arcs (24h: Light only, Bloom cycle, Daily rhythm; Battery: Energy glow, Growth, Awakening),
//    Display Tuning (Any, AMOLED, IPS), Color Boost (Off, Subtle, Vivid, Neon), Variation Strength (Subtle, Clear, Strong).
// 4. AI Listing Metadata Generator (via Gemini Web Session):
//    - Generates validated JSON { file, title (<=30 chars), tags (8-12 lowercase words), keywords (CSV), category (20 Zedge categories), description (<=200 chars) }.
// 5. Ready Files Folder & ZIP Packaging:
//    - Packs organized set folders (set-01/morning.jpg, set-01/afternoon.jpg, ... or exact WP_Battery_*.jpg),
//      plus root metadata.json and prompts/set-01-wallpaper.txt.
// 6. Direct Upload Set to Panel (Cloudflare R2 Worker + Firebase Realtime Database Queue):
//    - Mirrors distribute.dart: uploads each slot to <r2Folder>/wallpaper/<timestamp>_<slug>_<slot>.jpg with SHA-256,
//      builds the exact Hub/Zedge Firebase record with fixed slot keys (critical/low/mid/high/full/charging, morning/afternoon/evening/night, lock/home),
//      and pushes to <dbUrl>/<queuePath>.json (supporting multi-account Spread rotation or specific account targets).
// 7. Direct Local Set Import into Studio Panel:
//    - Import existing images from disk into a Studio Set, auto-resize/upscale to 1620x2880 JPG, generate AI metadata,
//      package Ready ZIP + metadata.json, or upload directly to the Panel.

// Multi-Account Gemini Session Cache (keyed by authUser index: 0, 1, 2, 3...)
const cachedSessionsByUser = new Map();
let activeAuthUserIndex = 0;

const SESSION_TTL_MS = 15 * 60 * 1000;

// Gemini Resumable Upload & RPC constants
const GEMINI_UPLOAD_INIT_URL = "https://push.clients6.google.com/upload/";
const GEMINI_PUSH_ID = "feeds/mcudyrk2a4khkz";
const GEMINI_CLIENT_PCTX = "CgcSBWjK7pYx";
const GEMINI_TENANT_ID = "bard-storage";

// Cloudinary AI Upscale constants
const CLOUDINARY_SIGN_URL = "https://cloudinary-tools.netlify.app/.netlify/functions/sign-upload-params";
const CLOUDINARY_UPLOAD_URL = "https://api.cloudinary.com/v1_1/dtz0urit6/auto/upload";
const CLOUDINARY_ARCHIVE_URL = "https://cloudinary-tools.netlify.app/.netlify/functions/archive";
const CLOUDINARY_CLOUD_NAME = "dtz0urit6";
const CLOUDINARY_API_KEY = "985946268373735";
const CLOUDINARY_UPLOAD_PRESET = "cloudinary-tools";
const CLOUDINARY_SOURCE = "ml";

// Default output dimensions & Zedge Technical Specification constants
const PORTRAIT_WIDTH = 1620;
const PORTRAIT_HEIGHT = 2880;
const LANDSCAPE_WIDTH = 2800;
const LANDSCAPE_HEIGHT = 2400;
const JPEG_QUALITY_100 = 1.0;
const MAX_ZEDGE_FILE_BYTES = 8 * 1024 * 1024;
const SAFE_ZEDGE_TARGET_BYTES = 8150000;
const MIN_ZEDGE_WIDTH = 1620;
const MIN_ZEDGE_HEIGHT = 2880;
const MAX_ZEDGE_MEGAPIXELS = 25000000;

// 20 Official Zedge Categories (from gemini_api.dart)
const ZEDGE_CATEGORIES = [
  "ANIMALS", "ANIME", "CARS_N_VEHICLES", "COMICS", "DESIGNS", "DRAWINGS",
  "ENTERTAINMENT", "FUNNY", "GAMES", "HOLIDAYS", "LOVE", "MUSIC", "NATURE",
  "PATTERNS", "PEOPLE", "SAYINGS", "SPACE", "SPIRITUAL", "SPORTS", "TECHNOLOGY"
];

const NO_TEXT_GUARD =
  ", no text, no letters, no numbers, no symbols, no icons, no watermark";
const PRO_FINISH_SUFFIX =
  ", one strong focal point, clean uncluttered composition, professional wallpaper finish";

// Variation strength instructions (from batch_screen.dart)
const VARIATION_STRENGTHS = {
  subtle:
    "Relight the reference image so it matches the ABSOLUTE lighting state described above - treat the stated lit-area, brightness, bloom and shadow values as exact targets to hit, not as a nudge from the reference. The change must be clearly noticeable side by side. Keep the exact same subject, objects, background, layout, composition, framing and art style: nothing may be added, removed or rearranged.",
  clear:
    "This is a relighting edit, not a copy: rebuild the light and atmosphere of the reference image until it matches the ABSOLUTE state described above - hit the stated lit-area percentage, brightness, bloom radius and shadow depth exactly, even if that means a large jump from the reference. The result must be immediately distinguishable at a glance from any other stage. Keep the exact same subject, objects, background, layout, composition, framing and art style: nothing may be added, removed or rearranged.",
  strong:
    "Dramatically relight the reference image to the ABSOLUTE state described above: push the stated lit-area percentage, brightness, bloom radius and shadow depth to the limit - bold light direction and color temperature, intense glow and bloom, thick atmosphere - an unmistakable transformation that can never be confused with a neighbouring stage. Keep the exact same subject, objects, background, layout, composition and framing: absolutely nothing may be added, removed or rearranged."
};

// Story Arcs (from models.dart)
const STORY_ARCS_24H = {
  light: [
    ", 6 am dawn: key light low on the horizon from the left at about 10 degrees elevation, roughly 3000K rose-gold color temperature, long soft shadows stretching to the right, low-lying mist, cool blue shadow tones, high-key gentle contrast, fresh tranquil mood",
    ", 1 pm midday: key light almost straight overhead at about 80 degrees elevation, roughly 5600K neutral white daylight, short hard shadows directly under the subject, no mist, maximum color saturation and micro-detail, bright high-contrast clarity",
    ", 6 pm golden hour: key light raking in low from the right at about 8 degrees elevation, roughly 2200K amber-orange color temperature, long dramatic shadows falling to the left, warm haze and strong rim light tracing every edge, glowing low-sun flare",
    ", 11 pm night: no sun, only cool moonlight from high behind at roughly 7500K deep indigo, about 70 percent of the frame in deep shadow, silver specular highlights on edges only, soft local glow from the scene own light sources, low-key nocturnal calm"
  ],
  bloom: [
    ", soft dawn light, the subject newly awakening, delicate buds beginning to open, rose-gold glow, misty fresh atmosphere",
    ", harsh midday sun, the subject in full bloom at its peak, vivid saturated colors lit brightly, intense vitality",
    ", ember-orange sunset light, the subject mature and complete, warm glowing rim light on its form, rich dramatic warmth",
    ", cold moonlight, the subject at rest gently closed, silver highlights on its silhouette, deep blue calm"
  ],
  rhythm: [
    ", soft pale dawn light, the scene calm and nearly empty, misty quiet atmosphere, gentle stillness",
    ", harsh bright midday light, the scene alive with movement, sharp shadows, vivid energetic clarity",
    ", ember-orange evening light, long dramatic shadows, warm glowing atmosphere as the light fades",
    ", cold blue moonlight, the scene asleep and empty, deep shadows, silent tranquil mood"
  ]
};

const STORY_ARCS_BATTERY = {
  energy: [
    ", charge level 0 of 100: the scene is almost completely dark, about 5 percent of the frame carries any light, a single dim ember of its own glow hue no larger than a coin, no bloom, no light spill, deep crushed black shadows filling the rest of the frame",
    ", charge level 20 of 100: about 20 percent of the frame is lit, the glow is a thin low-intensity core with a tight halo roughly twice its own size, faint light spill on the nearest surface only, the outer two thirds of the frame still sit in deep shadow",
    ", charge level 40 of 100: about 40 percent of the frame is lit, the glow core is clearly brighter and its halo now reaches roughly a quarter of the frame width, visible light rays and reflections on mid-distance surfaces, shadows softened to dark grey but the frame edges stay dark",
    ", charge level 60 of 100: about 60 percent of the frame is lit and roughly two stops brighter than the previous stage, the glow core is burning hot with a wide bloom reaching half the frame width, strong rays and reflections across the whole mid-ground, only the frame corners remain dark",
    ", charge level 80 of 100: about 80 percent of the frame is lit and clearly brighter again, the glow core is near-white hot at its center, heavy bloom with visible lens flare and volumetric light beams crossing the frame, bright haze filling the air, barely any shadow left except thin contact shadows",
    ", charge level 100 of 100: the whole frame is flooded with light at maximum output, the glow core is blown out pure white at its center with saturated hue at its rim, extreme bloom covering the entire frame, strong star-burst flare, glowing atmospheric haze everywhere, zero dark areas anywhere in the image"
  ],
  growth: [
    ", charge 0 of 100: a tiny seed of the subject occupying about a tenth of the frame height in near-darkness, about 5 percent of the frame lit by one faint ember of its own glow hue",
    ", charge 20 of 100: the subject sprouting to about a quarter of the frame height, about 20 percent of the frame lit, the same hue a thin core with a tight halo, the rest in deep shadow",
    ", charge 40 of 100: the subject at about half the frame height, about 40 percent of the frame lit, the identical hue brighter with a halo a quarter of the frame wide, rays and reflections appearing",
    ", charge 60 of 100: the subject filling about two thirds of the frame and two stops brighter, the same hue burning hot, bloom across half the frame, only corners dark",
    ", charge 80 of 100: the subject near-monumental filling most of the frame, about 80 percent of the frame lit, the unchanged hue near-white hot, heavy bloom, flare and volumetric beams",
    ", charge 100 of 100: the subject monumental and dominating the frame, the whole image flooded at maximum output in the same hue, blown out white core, extreme bloom, star-burst flare, zero dark areas"
  ],
  awaken: [
    ", charge 0 of 100: the subject dormant and perfectly still, about 5 percent of the frame lit by a dying ember of its own glow hue, no bloom, crushed black surroundings",
    ", charge 20 of 100: the first stir, about 20 percent of the frame lit, one thin crack of the same hue with a tight halo breaking the dark, everything else in deep shadow",
    ", charge 40 of 100: the subject stirring awake with gentle motion, about 40 percent of the frame lit, the identical hue spreading, halo a quarter of the frame wide, rays and reflections at mid distance",
    ", charge 60 of 100: the subject active and dynamic, about 60 percent of the frame lit and two stops brighter, the same hue burning hot, bloom across half the frame, motion trails, only corners dark",
    ", charge 80 of 100: the subject intensely alive, about 80 percent of the frame lit, the unchanged hue near-white hot, heavy bloom, lens flare, volumetric beams, energy streaming off its form",
    ", charge 100 of 100: the subject at explosive peak vitality, the whole frame flooded at maximum output in the exact same hue, blown out white core, extreme bloom and star-burst flare, zero dark areas"
  ]
};

function suggest24hArc(prompt) {
  const p = (prompt || "").toLowerCase();
  if (["flower", "lotus", "bloom", "blossom", "plant", "tree", "leaf", "leaves", "garden", "petal", "rose", "nature", "forest", "flora"].some((w) => p.includes(w))) {
    return "bloom";
  }
  if (["city", "street", "urban", "people", "crowd", "market", "traffic", "cafe", "town", "village", "lifestyle"].some((w) => p.includes(w))) {
    return "rhythm";
  }
  return "light";
}

function suggestBatteryArc(prompt) {
  const p = (prompt || "").toLowerCase();
  if (["flower", "plant", "tree", "seed", "leaf", "garden", "crystal", "bloom", "nature", "lotus"].some((w) => p.includes(w))) {
    return "growth";
  }
  if (["creature", "dragon", "animal", "being", "spirit", "robot", "phoenix", "bird", "beast"].some((w) => p.includes(w))) {
    return "awaken";
  }
  return "energy";
}

function buildNegativeGuard(negativePrompt = "") {
  const custom = String(negativePrompt || "").trim();
  if (!custom) return NO_TEXT_GUARD;
  return `${NO_TEXT_GUARD}, strictly avoid / negative prompt: ${custom}`;
}

function buildStyleSuffix(displayTarget = "any", colorBoost = "off") {
  let out = "";
  if (displayTarget === "amoled") {
    out += ", high contrast, vivid luminous colors, optimized for AMOLED displays";
  } else if (displayTarget === "ips") {
    out += ", balanced brightness, natural color reproduction, optimized for IPS displays";
  }
  if (colorBoost === "subtle") {
    out += ", subtly enhanced color richness";
  } else if (colorBoost === "vivid") {
    out += ", vivid rich colors with enhanced saturation";
  } else if (colorBoost === "neon") {
    out += ", bold electrifying colors, striking chromatic intensity";
  }
  return out;
}

// In-memory cache of ready-to-download 100% quality JPG Data URLs keyed by assetId
const readyJpgCache = new Map();
const MAX_CACHE_ITEMS = 64;

function storePreparedJpg(assetId, item) {
  if (readyJpgCache.size >= MAX_CACHE_ITEMS) {
    const oldestKey = readyJpgCache.keys().next().value;
    if (oldestKey) readyJpgCache.delete(oldestKey);
  }
  readyJpgCache.set(assetId, item);
}

// Default stage definitions for the 3 Zedge Wallpaper Set modes
const DEFAULT_DUAL_SET_STAGES = [
  {
    key: "lock",
    distSlot: "lock",
    zipName: "lock.jpg",
    slotIndex: 1,
    role: "dual_lock",
    badge: "Lock Screen (1/2)",
    shortLabel: "Lock",
    exactFilename: "WP_Dual_1_LockScreen.jpg",
    isAnchor: true,
    promptSuffix:
      ", lock screen framing: macro close-up, the hero fills about 80 percent of the frame height, shallow depth of field with a softly blurred background, striking fine surface detail, hero mass in the lower two thirds"
  },
  {
    key: "home",
    distSlot: "home",
    zipName: "home.jpg",
    slotIndex: 2,
    role: "dual_home",
    badge: "Home Screen (2/2)",
    shortLabel: "Home",
    exactFilename: "WP_Dual_2_HomeScreen.jpg",
    isAnchor: false,
    transitionInstruction:
      ", home screen framing: wide establishing view of the same scene pulled far back, the hero now occupies only about 30 percent of the frame height and sits low, deep focus, generous calm negative space and quiet low-detail area across the upper half for icons and widgets"
  }
];

const DEFAULT_24H_SET_STAGES = [
  {
    key: "morning",
    distSlot: "morning",
    zipName: "morning.jpg",
    slotIndex: 1,
    role: "time_morning",
    badge: "Morning • সকাল (1/4)",
    shortLabel: "Morning",
    exactFilename: "WP_24Hour_1_Morning.jpg",
    isAnchor: true,
    promptSuffix: STORY_ARCS_24H.light[0]
  },
  {
    key: "afternoon",
    distSlot: "afternoon",
    zipName: "afternoon.jpg",
    slotIndex: 2,
    role: "time_afternoon",
    badge: "Afternoon • দুপুর (2/4)",
    shortLabel: "Afternoon",
    exactFilename: "WP_24Hour_2_Afternoon.jpg",
    isAnchor: false,
    transitionInstruction: STORY_ARCS_24H.light[1]
  },
  {
    key: "evening",
    distSlot: "evening",
    zipName: "evening.jpg",
    slotIndex: 3,
    role: "time_evening",
    badge: "Evening • সন্ধ্যা (3/4)",
    shortLabel: "Evening",
    exactFilename: "WP_24Hour_3_Evening.jpg",
    isAnchor: false,
    transitionInstruction: STORY_ARCS_24H.light[2]
  },
  {
    key: "night",
    distSlot: "night",
    zipName: "night.jpg",
    slotIndex: 4,
    role: "time_night",
    badge: "Night • রাত (4/4)",
    shortLabel: "Night",
    exactFilename: "WP_24Hour_4_Night.jpg",
    isAnchor: false,
    transitionInstruction: STORY_ARCS_24H.light[3]
  }
];

const DEFAULT_BATTERY_SET_STAGES = [
  {
    key: "critical",
    distSlot: "critical",
    zipName: "0.jpg",
    slotIndex: 1,
    role: "battery_l1",
    badge: "Level 1: 0–20% Critical",
    shortLabel: "0% (Critical)",
    exactFilename: "WP_Battery_Level1_Critical.jpg",
    isAnchor: false,
    transitionInstruction: STORY_ARCS_BATTERY.energy[0]
  },
  {
    key: "low",
    distSlot: "low",
    zipName: "20.jpg",
    slotIndex: 2,
    role: "battery_l2",
    badge: "Level 2: 21–40% Low",
    shortLabel: "20% (Low)",
    exactFilename: "WP_Battery_Level2_Low.jpg",
    isAnchor: false,
    transitionInstruction: STORY_ARCS_BATTERY.energy[1]
  },
  {
    key: "mid",
    distSlot: "mid",
    zipName: "40.jpg",
    slotIndex: 3,
    role: "battery_l3",
    badge: "Level 3: 41–60% Mid",
    shortLabel: "40% (Mid)",
    exactFilename: "WP_Battery_Level3_Mid.jpg",
    isAnchor: true,
    promptSuffix: STORY_ARCS_BATTERY.energy[2]
  },
  {
    key: "high",
    distSlot: "high",
    zipName: "60.jpg",
    slotIndex: 4,
    role: "battery_l4",
    badge: "Level 4: 61–80% High",
    shortLabel: "60% (High)",
    exactFilename: "WP_Battery_Level4_High.jpg",
    isAnchor: false,
    transitionInstruction: STORY_ARCS_BATTERY.energy[3]
  },
  {
    key: "full",
    distSlot: "full",
    zipName: "80.jpg",
    slotIndex: 5,
    role: "battery_l5",
    badge: "Level 5: 81–100% Full",
    shortLabel: "80% (Full)",
    exactFilename: "WP_Battery_Level5_Full.jpg",
    isAnchor: false,
    transitionInstruction: STORY_ARCS_BATTERY.energy[4]
  },
  {
    key: "charging",
    distSlot: "charging",
    zipName: "100.jpg",
    slotIndex: 6,
    role: "battery_charging",
    badge: "Charging (100% Active)",
    shortLabel: "100% (Charging)",
    exactFilename: "WP_Battery_Charging.jpg",
    isAnchor: false,
    transitionInstruction: STORY_ARCS_BATTERY.energy[5]
  }
];

async function openOrFocusDashboardTab() {
  const dashboardUrl = chrome.runtime.getURL("dashboard.html");
  const tabs = await chrome.tabs.query({ url: dashboardUrl });
  if (tabs && tabs.length > 0) {
    const existingTab = tabs[0];
    await chrome.tabs.update(existingTab.id, { active: true });
    if (existingTab.windowId) {
      await chrome.windows.update(existingTab.windowId, { focused: true });
    }
    return;
  }
  await chrome.tabs.create({ url: dashboardUrl });
}

chrome.action.onClicked.addListener(() => {
  openOrFocusDashboardTab();
});

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    openOrFocusDashboardTab();
  }
});

function broadcastStatus(payload) {
  chrome.storage.local.set({ lastStatus: { ...payload, timestamp: Date.now() } });
  chrome.runtime.sendMessage({ type: "STATUS_UPDATE", payload }).catch(() => {});
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function arrayBufferToBase64(buffer) {
  const bytes = new Uint8Array(buffer);
  let binary = "";
  const chunkSize = 0x8000;
  for (let i = 0; i < bytes.length; i += chunkSize) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunkSize));
  }
  return btoa(binary);
}

function base64ToUint8Array(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
}

function dataUrlToBlob(dataUrl) {
  const commaIdx = dataUrl.indexOf(",");
  const header = dataUrl.slice(0, commaIdx);
  const base64 = dataUrl.slice(commaIdx + 1);
  const mimeMatch = header.match(/data:([^;]+)/);
  const mimeType = mimeMatch ? mimeMatch[1] : "image/jpeg";
  const bytes = base64ToUint8Array(base64);
  return new Blob([bytes], { type: mimeType });
}

async function sha256Hex(uint8Bytes) {
  const hashBuf = await crypto.subtle.digest("SHA-256", uint8Bytes);
  const hashArr = Array.from(new Uint8Array(hashBuf));
  return hashArr.map((b) => b.toString(16).padStart(2, "0")).join("");
}

function normalizeZedgeDimensions(width, height, enforceZedgeRules = true) {
  let w = parseInt(width, 10) || PORTRAIT_WIDTH;
  let h = parseInt(height, 10) || PORTRAIT_HEIGHT;

  if (enforceZedgeRules) {
    if (w < MIN_ZEDGE_WIDTH || h < MIN_ZEDGE_HEIGHT) {
      const scale = Math.max(MIN_ZEDGE_WIDTH / w, MIN_ZEDGE_HEIGHT / h);
      w = Math.max(MIN_ZEDGE_WIDTH, Math.round(w * scale));
      h = Math.max(MIN_ZEDGE_HEIGHT, Math.round(h * scale));
    }
    if (w * h >= MAX_ZEDGE_MEGAPIXELS) {
      const downScale = Math.sqrt(24500000 / (w * h));
      w = Math.max(MIN_ZEDGE_WIDTH, Math.floor(w * downScale));
      h = Math.max(MIN_ZEDGE_HEIGHT, Math.floor(h * downScale));
    }
  }
  return { width: w, height: h };
}

function extractEmailFromGeminiHtml(html) {
  if (!html) return "";
  const wizEmail = html.match(/"oPEP7c":"([^"]+@[^"]+)"/);
  if (wizEmail && wizEmail[1]) return wizEmail[1].trim();
  const genericEmail = html.match(/([a-zA-Z0-9._%+-]+@(?:gmail\.com|googlemail\.com))/i);
  if (genericEmail && genericEmail[1]) return genericEmail[1].trim().toLowerCase();
  return "";
}

async function resolveTargetAuthUser(explicitAuthUser = null) {
  if (explicitAuthUser !== null && explicitAuthUser !== undefined && explicitAuthUser !== "auto") {
    const parsed = parseInt(explicitAuthUser, 10);
    if (!isNaN(parsed) && parsed >= 0) {
      activeAuthUserIndex = parsed;
      return parsed;
    }
  }
  try {
    const { geminiAccountMode = "auto" } = await chrome.storage.local.get("geminiAccountMode");
    if (geminiAccountMode !== "auto") {
      const parsed = parseInt(geminiAccountMode, 10);
      if (!isNaN(parsed) && parsed >= 0) {
        activeAuthUserIndex = parsed;
        return parsed;
      }
    }
  } catch (_) {}
  return activeAuthUserIndex || 0;
}

async function getGeminiSession(forceRefresh = false, explicitAuthUser = null) {
  const authUser = await resolveTargetAuthUser(explicitAuthUser);
  const now = Date.now();
  const existing = cachedSessionsByUser.get(authUser);

  if (
    !forceRefresh &&
    existing &&
    existing.at &&
    existing.bl &&
    now - existing.fetchedAt < SESSION_TTL_MS
  ) {
    return existing;
  }

  broadcastStatus({
    state: "authenticating",
    step: 1,
    message: `Connecting to Gemini Account u/${authUser} (fetching SNlM0e token)...`
  });

  const appUrl = `https://gemini.google.com/u/${authUser}/app?authuser=${authUser}`;
  const response = await fetch(appUrl, {
    method: "GET",
    credentials: "include",
    headers: {
      "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
    }
  });

  if (!response.ok) {
    throw new Error(
      `Failed to reach gemini.google.com/u/${authUser}/app (HTTP ${response.status}). Make sure you are signed into Google in this browser.`
    );
  }

  const html = await response.text();
  const atMatch = html.match(/"SNlM0e":"([^"]+)"/);
  const blMatch = html.match(/"cfb2h":"([^"]+)"/);
  const fSidMatch = html.match(/"FdrFJe":"([^"]+)"/);
  const email = extractEmailFromGeminiHtml(html);

  if (!atMatch || !atMatch[1]) {
    throw new Error(
      `Could not find Gemini session token (SNlM0e) for Account u/${authUser}. Please sign in at https://gemini.google.com/u/${authUser}/app in your browser.`
    );
  }

  const sessionObj = {
    authUser,
    email: email || `Account u/${authUser}`,
    at: atMatch[1],
    bl: blMatch ? blMatch[1] : "boq_gemini-web-uiserver_20261106.06_p0",
    fSid: fSidMatch ? fSidMatch[1] : "",
    fetchedAt: now
  };

  cachedSessionsByUser.set(authUser, sessionObj);
  chrome.storage.local.set({
    activeGeminiAccountInfo: {
      authUser: sessionObj.authUser,
      email: sessionObj.email,
      bl: sessionObj.bl
    }
  });
  return sessionObj;
}

/**
 * Scans /u/0 through /u/5 in parallel to discover all signed-in Gmail / Gemini accounts in the browser.
 */
async function scanAvailableGeminiAccounts() {
  const indices = [0, 1, 2, 3, 4, 5];
  const probePromises = indices.map(async (u) => {
    try {
      const url = `https://gemini.google.com/u/${u}/app?authuser=${u}`;
      const resp = await fetch(url, {
        method: "GET",
        credentials: "include",
        headers: {
          "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
        }
      });
      if (!resp.ok) return null;
      const finalUrl = resp.url || "";
      const redirectedMatch = finalUrl.match(/\/u\/(\d+)\//);
      if (redirectedMatch && parseInt(redirectedMatch[1], 10) !== u) {
        return null;
      }
      const html = await resp.text();
      const atMatch = html.match(/"SNlM0e":"([^"]+)"/);
      if (!atMatch || !atMatch[1]) return null;
      const blMatch = html.match(/"cfb2h":"([^"]+)"/);
      const fSidMatch = html.match(/"FdrFJe":"([^"]+)"/);
      const email = extractEmailFromGeminiHtml(html);

      const sessionObj = {
        authUser: u,
        email: email || `Account u/${u}`,
        at: atMatch[1],
        bl: blMatch ? blMatch[1] : "boq_gemini-web-uiserver_20261106.06_p0",
        fSid: fSidMatch ? fSidMatch[1] : "",
        fetchedAt: Date.now()
      };
      cachedSessionsByUser.set(u, sessionObj);
      return {
        authUser: u,
        email: sessionObj.email,
        bl: sessionObj.bl,
        atPreview: sessionObj.at.slice(0, 12)
      };
    } catch (_) {
      return null;
    }
  });

  const rawResults = (await Promise.all(probePromises)).filter(Boolean);
  const uniqueAccounts = [];
  const seenKeys = new Set();

  for (const acc of rawResults) {
    const dedupeKey = acc.email && acc.email.includes("@") ? acc.email.toLowerCase() : acc.atPreview;
    if (!seenKeys.has(dedupeKey)) {
      seenKeys.add(dedupeKey);
      uniqueAccounts.push({
        authUser: acc.authUser,
        email: acc.email,
        bl: acc.bl
      });
    }
  }

  await chrome.storage.local.set({ discoveredGeminiAccounts: uniqueAccounts });
  return uniqueAccounts;
}

function isQuotaOrLimitFailure(status, assistantText = "") {
  if (status === 429 || status === 503) return true;
  const t = String(assistantText || "").toLowerCase();
  if (!t) return false;
  const limitKeywords = [
    "reached your limit",
    "rate limit",
    "quota",
    "too many requests",
    "try again later",
    "can not generate more",
    "cannot generate more",
    "limit for generating images",
    "create more images tomorrow",
    "high demand"
  ];
  return limitKeywords.some((kw) => t.includes(kw));
}

async function trySwitchToNextGeminiAccount(failedAuthUser) {
  const { geminiAccountMode = "auto", discoveredGeminiAccounts = [] } =
    await chrome.storage.local.get(["geminiAccountMode", "discoveredGeminiAccounts"]);

  let accounts = discoveredGeminiAccounts;
  if (!Array.isArray(accounts) || accounts.length <= 1) {
    accounts = await scanAvailableGeminiAccounts();
  }

  const otherAccounts = accounts.filter((a) => a.authUser !== failedAuthUser);
  if (otherAccounts.length === 0) {
    return null;
  }

  const currentIdx = accounts.findIndex((a) => a.authUser === failedAuthUser);
  const nextAcc =
    currentIdx >= 0
      ? accounts[(currentIdx + 1) % accounts.length]
      : otherAccounts[0];

  if (!nextAcc || nextAcc.authUser === failedAuthUser) return null;

  activeAuthUserIndex = nextAcc.authUser;
  if (geminiAccountMode !== "auto") {
    await chrome.storage.local.set({ geminiAccountMode: String(nextAcc.authUser) });
  }
  const newSession = await getGeminiSession(true, nextAcc.authUser);
  broadcastStatus({
    state: "authenticating",
    step: 1,
    message: `Account u/${failedAuthUser} limit/quota reached — auto-switched to u/${newSession.authUser} (${newSession.email})!`
  });
  return newSession;
}

function buildImagePrompt(rawPrompt, aspectRatio, forceImagePrefix) {
  let prompt = rawPrompt.trim();
  const hasImageVerb = /^(generate|create|draw|make|paint|render|design)\s+(an?\s+)?(image|picture|photo|illustration|art|wallpaper)/i.test(prompt);

  if (forceImagePrefix && !hasImageVerb) {
    prompt = `Generate an image of: ${prompt}`;
  }
  if (aspectRatio && aspectRatio !== "auto" && !prompt.toLowerCase().includes("aspect ratio")) {
    prompt = `${prompt} (aspect ratio ${aspectRatio})`;
  }
  return prompt;
}

function extractImageUrlsFromNode(node, foundSet) {
  if (!node) return;

  if (typeof node === "string") {
    const urlRegex = /https:\/\/(?:lh3\.googleusercontent\.com|[a-zA-Z0-9\-]+\.fife\.usercontent\.google\.com)\/[a-zA-Z0-9_\-\/=+%]+/g;
    const matches = node.match(urlRegex);
    if (matches) {
      for (const rawUrl of matches) {
        if (!rawUrl.includes("/a/") && !rawUrl.includes("/a-/") && rawUrl.length > 48) {
          foundSet.add(rawUrl);
        }
      }
    }

    const trimmed = node.trim();
    if (
      (trimmed.startsWith("[") && trimmed.endsWith("]")) ||
      (trimmed.startsWith("{") && trimmed.endsWith("}"))
    ) {
      try {
        const parsed = JSON.parse(trimmed);
        extractImageUrlsFromNode(parsed, foundSet);
      } catch (_) {}
    }
    return;
  }

  if (Array.isArray(node)) {
    for (const item of node) {
      extractImageUrlsFromNode(item, foundSet);
    }
    return;
  }

  if (typeof node === "object") {
    for (const key of Object.keys(node)) {
      extractImageUrlsFromNode(node[key], foundSet);
    }
  }
}

function parseStreamGenerateResponse(rawText, excludeUrls = []) {
  const candidateImageUrls = new Set();
  const fallbackImageUrls = new Set();
  let assistantText = "";
  let conversationMeta = null;

  const excludeBaseSet = new Set(
    excludeUrls.map((u) => u.replace(/["'\\]+$/, "").replace(/=[a-zA-Z0-9\-_]+$/, ""))
  );

  const lines = rawText.split("\n");
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed.startsWith("[")) continue;
    try {
      const outer = JSON.parse(trimmed);
      extractImageUrlsFromNode(outer, fallbackImageUrls);

      if (Array.isArray(outer)) {
        for (const entry of outer) {
          if (Array.isArray(entry) && entry[0] === "wrb.fr" && typeof entry[2] === "string") {
            try {
              const inner = JSON.parse(entry[2]);
              if (Array.isArray(inner)) {
                if (Array.isArray(inner[1]) && typeof inner[1][0] === "string") {
                  conversationMeta = {
                    conversationId: inner[1][0] || "",
                    responseId: inner[1][1] || "",
                    choiceId:
                      Array.isArray(inner[4]) &&
                      Array.isArray(inner[4][0]) &&
                      typeof inner[4][0][0] === "string"
                        ? inner[4][0][0]
                        : ""
                  };
                }
                if (Array.isArray(inner[4])) {
                  extractImageUrlsFromNode(inner[4], candidateImageUrls);
                  if (
                    Array.isArray(inner[4][0]) &&
                    Array.isArray(inner[4][0][1]) &&
                    typeof inner[4][0][1][0] === "string"
                  ) {
                    const candidateText = inner[4][0][1][0];
                    if (candidateText.trim().length >= assistantText.trim().length) {
                      assistantText = candidateText;
                    }
                  }
                }
              }
            } catch (_) {}
          }
        }
      }
    } catch (_) {}
  }

  const unescapedRaw = rawText
    .replace(/\\u003d/g, "=")
    .replace(/\\u0026/g, "&")
    .replace(/\\\//g, "/");
  const rawRegex = /https:\/\/(?:lh3\.googleusercontent\.com|[a-zA-Z0-9\-]+\.fife\.usercontent\.google\.com)\/(?:gg-dl|rd-gg-dl|gg)\/[a-zA-Z0-9_\-\/=+%]+/g;
  const directMatches = unescapedRaw.match(rawRegex);
  if (directMatches) {
    directMatches.forEach((u) => fallbackImageUrls.add(u));
  }

  const sourceSet = candidateImageUrls.size > 0 ? candidateImageUrls : fallbackImageUrls;
  const uniqueBaseMap = new Map();
  for (const url of sourceSet) {
    const cleanUrl = url.replace(/["'\\]+$/, "").replace(/\?.*$/, "");
    const baseKey = cleanUrl.replace(/=[a-zA-Z0-9\-_]+$/, "");
    if (!excludeBaseSet.has(baseKey)) {
      uniqueBaseMap.set(baseKey, cleanUrl);
    }
  }

  return {
    urls: Array.from(uniqueBaseMap.keys()),
    assistantText,
    conversationMeta
  };
}

// ============================================================================
// AI METADATA GENERATOR & AI SET DIRECTOR (Ported 1:1 from lib/gemini_api.dart)
// ============================================================================

/**
 * Sends a pure text prompt to Gemini StreamGenerate (fresh chat) and returns the assistant text reply.
 */
async function askGeminiText(promptText, session, attempts = 3) {
  let activeSession = session || (await getGeminiSession(false));
  let lastErr = "Empty response from Gemini";

  for (let i = 0; i < attempts; i++) {
    try {
      const u = activeSession.authUser || 0;
      const reqId = Math.floor(100000 + Math.random() * 900000);
      const queryParams = new URLSearchParams({
        bl: activeSession.bl,
        hl: "en",
        _reqid: String(reqId),
        rt: "c",
        authuser: String(u)
      });
      if (activeSession.fSid) {
        queryParams.set("f.sid", activeSession.fSid);
      }

      const endpoint = `https://gemini.google.com/u/${u}/_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate?${queryParams.toString()}`;
      const innerPayload = [
        [promptText],
        null,
        [null, null, null]
      ];
      const outerPayload = [null, JSON.stringify(innerPayload)];
      const formBody = new URLSearchParams();
      formBody.set("f.req", JSON.stringify(outerPayload));
      formBody.set("at", activeSession.at);

      let response = await fetch(endpoint, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
          "X-Same-Domain": "1"
        },
        body: formBody.toString()
      });

      if (response.status === 401 || response.status === 403 || response.status === 400) {
        activeSession = await getGeminiSession(true);
        formBody.set("at", activeSession.at);
        response = await fetch(endpoint, {
          method: "POST",
          credentials: "include",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
            "X-Same-Domain": "1"
          },
          body: formBody.toString()
        });
      }

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }

      const rawText = await response.text();
      const parsed = parseStreamGenerateResponse(rawText);
      if (parsed.assistantText && parsed.assistantText.trim().length > 0) {
        return parsed.assistantText.trim();
      }
    } catch (err) {
      lastErr = err.message || String(err);
    }
    if (i < attempts - 1) {
      await sleep(1500 * (i + 1));
    }
  }
  throw new Error(`Gemini text completion failed: ${lastErr}`);
}

/**
 * Balanced {...} JSON block scanner (ported from GeminiApi._balancedBlocks in gemini_api.dart)
 */
function extractBalancedJsonBlocks(text) {
  const blocks = [];
  let depth = 0;
  let start = -1;
  let quote = null;
  let escaped = false;

  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (quote !== null) {
      if (escaped) {
        escaped = false;
      } else if (c === "\\") {
        escaped = true;
      } else if (c === quote) {
        quote = null;
      }
      continue;
    }
    if (c === '"' || c === "'") {
      quote = c;
    } else if (c === "{") {
      if (depth === 0) start = i;
      depth++;
    } else if (c === "}") {
      if (depth > 0) {
        depth--;
        if (depth === 0 && start >= 0) {
          blocks.push(text.slice(start, i + 1));
          start = -1;
        }
      }
    }
  }
  blocks.sort((a, b) => b.length - a.length);
  return blocks;
}

function decodeJsonMap(str) {
  const t = (str || "").trim();
  if (!t) return null;
  const knownKeys = new Set([
    "title", "tags", "category", "description",
    "arc", "anchor", "palette", "stages", "direction", "label"
  ]);

  function asMap(v) {
    if (!v) return null;
    if (Array.isArray(v)) {
      for (const item of v) {
        const m = asMap(item);
        if (m) return m;
      }
      return null;
    }
    if (typeof v === "object") return v;
    return null;
  }

  function unwrap(m) {
    const keys = Object.keys(m);
    if (
      keys.length === 1 &&
      !knownKeys.has(keys[0]) &&
      m[keys[0]] &&
      typeof m[keys[0]] === "object" &&
      !Array.isArray(m[keys[0]])
    ) {
      return m[keys[0]];
    }
    return m;
  }

  for (const candidate of [t, t.replace(/,\s*([}\]])/g, "$1")]) {
    try {
      const parsed = JSON.parse(candidate);
      const m = asMap(parsed);
      if (m) return unwrap(m);
    } catch (_) {}
  }
  return null;
}

function extractJsonMapFromReply(text) {
  const cleaned = (text || "").replace(/```(?:\w+)?/gi, "").trim();
  const direct = decodeJsonMap(cleaned);
  if (direct) return direct;
  for (const block of extractBalancedJsonBlocks(cleaned)) {
    const m = decodeJsonMap(block);
    if (m) return m;
  }
  return null;
}

/**
 * Generates Zedge / Hub listing metadata for a wallpaper set via Gemini Web Session
 * (ported 1:1 from GeminiApi.generate & GeminiApi.parseMetadata in gemini_api.dart).
 */
async function generateSetMetadata({
  workflowMode = "set_24h",
  prompt = "",
  file = "set-01/morning.jpg",
  session = null
}) {
  const setTypeStr =
    workflowMode === "set_24h"
      ? "24-HOUR"
      : workflowMode === "set_dual"
      ? "DUAL"
      : workflowMode === "set_battery"
      ? "BATTERY"
      : "SINGLE";

  const concept = (prompt || "wallpaper")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 40);

  const systemPrompt =
    `You write Zedge wallpaper listing metadata. Reply with ONE JSON object only, no markdown, no commentary.\n` +
    `Schema: {"title": string (max 30 characters, Title Case, catchy, no emoji, no quotes), ` +
    `"tags": array of 8 to 12 single lowercase words (no spaces, no hyphens, no duplicates, no brand or franchise names), ` +
    `"category": one of ${JSON.stringify(ZEDGE_CATEGORIES)}, ` +
    `"description": string (1-2 sentences, max 200 characters, natural, no hashtags, no emoji)}.\n` +
    `Set types: 24-HOUR = 4 time-of-day wallpapers; DUAL = lock + home screen pair; BATTERY = 6 charge-level wallpapers; SINGLE = one wallpaper. ` +
    `Mention the set behaviour naturally in the description when the type is not SINGLE. Never mention copyrighted characters, brands, humans or text. ` +
    `Do not describe the image in sentences - output only the JSON object.`;

  const varietyNote =
    `Write like a normal human uploader, not a template: vary the title structure naturally (sometimes the subject, sometimes the mood, sometimes a short phrase), ` +
    `never start the description the same way twice, and pick tags that fit this specific image - specific over generic - shuffling their order every time.`;

  const webJsonNote =
    `OUTPUT RULE: reply with the raw JSON object ONLY. No markdown, no code fences, no commentary, no explanation before or after it.`;

  const fullPrompt =
    `${systemPrompt}\n\n${varietyNote}\n\n` +
    `Set type: ${setTypeStr}\n` +
    `Concept name: ${concept}\n` +
    `Image prompt: ${prompt}\n\n` +
    `Return the JSON object now.\n\n${webJsonNote}`;

  let metaMap = null;
  let lastReply = "";
  for (let attempt = 0; attempt < 3; attempt++) {
    const replyText = await askGeminiText(fullPrompt, session, 2);
    lastReply = replyText;
    metaMap = extractJsonMapFromReply(replyText);
    if (metaMap && (metaMap.title || metaMap.tags)) break;
    await sleep(1200);
  }

  if (!metaMap) {
    throw new Error(`Gemini did not return valid metadata JSON. Reply: ${lastReply.slice(0, 120)}`);
  }

  const tags = [];
  if (Array.isArray(metaMap.tags)) {
    for (const rawTag of metaMap.tags) {
      const clean = String(rawTag)
        .toLowerCase()
        .replace(/[^a-z0-9]/g, "");
      if (clean && !tags.includes(clean)) {
        tags.push(clean);
      }
      if (tags.length === 12) break;
    }
  }

  let category = String(metaMap.category || "").toUpperCase().trim();
  if (!ZEDGE_CATEGORIES.includes(category)) {
    category = "DESIGNS";
  }

  const title = String(metaMap.title || "")
    .replace(/["']/g, "")
    .trim()
    .slice(0, 30);

  const description = String(metaMap.description || "")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 200);

  return {
    file,
    title,
    tags,
    keywords: tags.join(", "),
    category,
    description,
    model: "gemini-web (cookie)",
    generatedAt: Date.now()
  };
}

/**
 * AI Set Director: plans a set's story arc, neutral anchor, color palette, and quantitative stage directions
 * (ported 1:1 from GeminiApi.directSet in lib/gemini_api.dart).
 */
async function directSetWithGemini({
  workflowMode = "set_24h",
  variantLabels = [],
  prompt = "",
  session = null
}) {
  const stageCount = variantLabels.length;
  const typeUpper =
    workflowMode === "set_battery"
      ? "BATTERY"
      : workflowMode === "set_24h"
      ? "24-HOUR"
      : workflowMode === "set_dual"
      ? "DUAL"
      : "SINGLE";

  let perTypeRules = "";
  if (typeUpper === "BATTERY") {
    perTypeRules =
      `BATTERY set (${stageCount} charge levels, 0% to 100%):\n` +
      `- The glow HUE is locked by the concept and must be identical in every stage. Only the AMOUNT of light changes.\n` +
      `- Every direction MUST state, as absolute values: the share of the frame that is lit (about 5, 20, 40, 60, 80 then 100 percent), the brightness of the glow core, the bloom radius, and how much of the frame is still in shadow.\n` +
      `- Spread the ladder evenly and make the top half obvious: 60% must read as clearly dimmer than 80%, and 80% clearly dimmer than 100%. Use different physical light behaviour per stage (halo size, light rays, reflections, volumetric beams, lens flare, blown-out core, haze) so the upper levels can never look the same.\n` +
      `- 0% is almost black, 100% has no dark area left anywhere in the frame.`;
  } else if (typeUpper === "24-HOUR") {
    perTypeRules =
      `24-HOUR set (${stageCount} times of day):\n` +
      `- Every direction MUST state: the clock hour, the key-light direction and elevation in degrees, the color temperature in Kelvin, the shadow length and direction, and the amount of atmosphere (mist, haze, clarity).\n` +
      `- Dawn is low warm light with long shadows, midday is near-overhead neutral light with short hard shadows, evening is low raking warm light with long shadows the opposite way, night has no sun at all, cool light and mostly deep shadow.\n` +
      `- Shadow direction must visibly flip between morning and evening.`;
  } else if (typeUpper === "DUAL") {
    perTypeRules =
      `DUAL set (${stageCount} screens):\n` +
      `- Lock and Home must differ in FRAMING, not in lighting. Keep the lighting and palette the same.\n` +
      `- Every direction MUST state: how much of the frame height the hero fills (about 80 percent for Lock, about 30 percent for Home), the depth of field (shallow and blurred background for Lock, deep focus for Home), and where the calm empty space sits.\n` +
      `- Home must leave a quiet low-detail area in the upper half for clock, icons and widgets.`;
  }

  const directorPrompt =
    `You are a professional art director for premium mobile wallpaper sets sold on wallpaper marketplaces. Reply with ONE JSON object only, no markdown, no commentary.\n` +
    `Schema: {"arc": string (short evocative arc name, e.g. "Bloom cycle"), ` +
    `"anchor": string (one neutral base-scene description fragment, no strong time-of-day or energy bias — it is the reference image every stage is re-lit from, so it must be a clean, mid-dark, unbiased rendering of the concept), ` +
    `"palette": array of 1-3 lowercase color words actually present in the concept, ` +
    `"stages": array with EXACTLY ${stageCount} objects, one per variant label in the given order, each {"label": string (the exact label), "direction": string (1-3 sentences describing ONLY what this stage looks like: lighting, state, atmosphere, framing — the subject, objects, background and art style stay identical)}}.\n` +
    `Hard rules:\n` +
    `- Never describe text, letters, numbers, symbols, icons, logos or watermarks in the image.\n` +
    `- Each direction is an ABSOLUTE description of that stage, never a relative one.\n` +
    `- Never reuse the same adjective, light behaviour or mood in two stages.\n` +
    `- Never add, remove, resize or rearrange the subject, objects or background unless the set type explicitly asks for a framing change.\n` +
    `${perTypeRules}\n\n` +
    `Set type: ${typeUpper}\n` +
    `Variant labels in order: ${variantLabels.map((l) => `"${l}"`).join(", ")}\n` +
    `User prompt: ${prompt}\n\n` +
    `Return the JSON object now.\n` +
    `OUTPUT RULE: reply with the raw JSON object ONLY. No markdown, no code fences, no commentary.`;

  const replyText = await askGeminiText(directorPrompt, session, 2);
  const meta = extractJsonMapFromReply(replyText);
  if (!meta || !Array.isArray(meta.stages) || meta.stages.length < stageCount) {
    throw new Error("AI Set Director returned an incomplete stage plan.");
  }

  const stages = [];
  for (let i = 0; i < stageCount; i++) {
    const s = meta.stages[i];
    const dir = s && s.direction ? String(s.direction).trim() : "";
    if (!dir) throw new Error("Empty stage direction in AI plan.");
    stages.push({ label: variantLabels[i], direction: dir });
  }

  const palette = [];
  if (Array.isArray(meta.palette)) {
    for (const c of meta.palette) {
      const w = String(c).toLowerCase().replace(/[^a-z]/g, "");
      if (w && !palette.includes(w)) palette.push(w);
      if (palette.length === 3) break;
    }
  }

  return {
    arc: String(meta.arc || "AI Directed Arc"),
    anchorDirection: String(meta.anchor || "").trim(),
    palette,
    stages
  };
}

function toHdImageUrl(baseUrl) {
  const withoutQuery = baseUrl.replace(/\?.*$/, "");
  const stripped = withoutQuery.replace(/=[a-zA-Z0-9\-_]+$/, "");
  return `${stripped}=s0`;
}

async function fetchGeminiHdBlob(baseUrl) {
  let currentUrl = toHdImageUrl(baseUrl);

  for (let hop = 0; hop < 4; hop++) {
    const resp = await fetch(currentUrl, {
      method: "GET",
      credentials: "include",
      redirect: "follow"
    });

    if (!resp.ok) {
      throw new Error(`Gemini HD image fetch returned HTTP ${resp.status}`);
    }

    const contentType = (resp.headers.get("content-type") || "").toLowerCase();

    if (contentType.includes("text/plain")) {
      const textBody = (await resp.text()).trim();
      if (textBody.startsWith("https://")) {
        currentUrl = toHdImageUrl(textBody);
        continue;
      }
      throw new Error("Unexpected text/plain response when fetching Gemini image.");
    }

    const buffer = await resp.arrayBuffer();
    const mimeType = contentType.includes("png")
      ? "image/png"
      : contentType.includes("webp")
      ? "image/webp"
      : "image/jpeg";
    const ext = mimeType === "image/png" ? "png" : mimeType === "image/webp" ? "webp" : "jpg";

    return {
      blob: new Blob([buffer], { type: mimeType }),
      buffer,
      mimeType,
      ext,
      finalHdUrl: currentUrl
    };
  }

  throw new Error("Exceeded maximum redirect hops while fetching Gemini HD image.");
}

async function uploadImageToGeminiForImg2Img(imageBlob, filename, session, stepNum = 2) {
  const activeSession = session || (await getGeminiSession(false));
  const u = activeSession.authUser || 0;
  const byteLength = imageBlob.size;
  const mimeType = imageBlob.type || "image/jpeg";

  broadcastStatus({
    state: "img2img_uploading",
    step: stepNum,
    message: `Uploading anchor reference image to Gemini u/${u} (${Math.round(byteLength / 1024)} KB)...`
  });

  const uploadInitUrl = `${GEMINI_UPLOAD_INIT_URL}?authuser=${u}`;
  const startResp = await fetch(uploadInitUrl, {
    method: "POST",
    credentials: "include",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
      "Push-Id": GEMINI_PUSH_ID,
      "X-Client-Pctx": GEMINI_CLIENT_PCTX,
      "X-Goog-AuthUser": String(u),
      "X-Goog-Upload-Command": "start",
      "X-Goog-Upload-Header-Content-Length": String(byteLength),
      "X-Goog-Upload-Protocol": "resumable",
      "X-Tenant-Id": GEMINI_TENANT_ID
    },
    body: `File name: ${filename}`
  });

  if (!startResp.ok) {
    throw new Error(`Gemini resumable upload init failed (HTTP ${startResp.status})`);
  }

  const uploadUrl =
    startResp.headers.get("x-goog-upload-url") ||
    startResp.headers.get("X-Goog-Upload-URL") ||
    startResp.headers.get("x-goog-upload-control-url");

  if (!uploadUrl) {
    throw new Error("Gemini upload init did not return x-goog-upload-url header.");
  }

  const rawBuffer = await imageBlob.arrayBuffer();
  const finalizeResp = await fetch(uploadUrl, {
    method: "POST",
    credentials: "include",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded;charset=utf-8",
      "Push-Id": GEMINI_PUSH_ID,
      "X-Client-Pctx": GEMINI_CLIENT_PCTX,
      "X-Goog-Upload-Command": "upload, finalize",
      "X-Goog-Upload-Offset": "0",
      "X-Tenant-Id": GEMINI_TENANT_ID
    },
    body: rawBuffer
  });

  if (!finalizeResp.ok) {
    throw new Error(`Gemini image binary upload failed (HTTP ${finalizeResp.status})`);
  }

  const uploadPath = (await finalizeResp.text()).trim();
  if (!uploadPath || !uploadPath.startsWith("/contrib_service/")) {
    throw new Error(`Unexpected upload path returned by bard-storage: "${uploadPath.slice(0, 100)}"`);
  }

  let processFileUuid = null;
  try {
    const reqId = Math.floor(100000 + Math.random() * 900000);
    const queryParams = new URLSearchParams({
      bl: activeSession.bl,
      hl: "en",
      _reqid: String(reqId),
      rt: "c",
      authuser: String(u)
    });
    if (activeSession.fSid) {
      queryParams.set("f.sid", activeSession.fSid);
    }

    const processEndpoint = `https://gemini.google.com/u/${u}/_/BardChatUi/data/assistant.lamda.BardFrontendService/ProcessFile?${queryParams.toString()}`;
    const processInner = [
      [
        [uploadPath, null, 1, mimeType],
        filename,
        null,
        null,
        null,
        null,
        null,
        null,
        [0]
      ],
      null,
      1,
      ["en"]
    ];
    const processOuter = [null, JSON.stringify(processInner)];
    const formBody = new URLSearchParams();
    formBody.set("f.req", JSON.stringify(processOuter));
    formBody.set("at", session.at);

    const procResp = await fetch(processEndpoint, {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        "X-Same-Domain": "1"
      },
      body: formBody.toString()
    });

    if (procResp.ok) {
      const procText = await procResp.text();
      const uuidMatch = procText.match(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i);
      if (uuidMatch) {
        processFileUuid = uuidMatch[0];
      }
    }
  } catch (_) {}

  return {
    uploadPath,
    mimeType,
    filename,
    processFileUuid,
    authUser: u,
    sourceBlob: imageBlob
  };
}

async function callGeminiStreamGenerate({
  prompt,
  session,
  attachment = null,
  aspectRatioHint = null,
  excludeUrls = []
}) {
  const payloadVariants = [];

  if (attachment) {
    const aspectField10 = aspectRatioHint
      ? [null, null, null, null, null, null, [null, [null, aspectRatioHint]]]
      : null;

    const desc1 = attachment.processFileUuid
      ? [attachment.uploadPath, 1, null, attachment.mimeType, attachment.processFileUuid]
      : [attachment.uploadPath, 1, null, attachment.mimeType];
    const att1 = [desc1, attachment.filename, null, null, null, null, null, null, [0]];
    const first1 = aspectField10
      ? [prompt, 0, null, [att1], null, null, 0, null, null, aspectField10]
      : [prompt, 0, null, [att1], null, null, 0];

    const inner1 = [
      first1,
      ["en"],
      ["", "", ""],
      null,
      null,
      null,
      [1],
      1,
      null,
      null,
      1,
      0
    ];
    while (inner1.length < 41) inner1.push(null);
    inner1[41] = [1];
    payloadVariants.push(inner1);

    const desc2 = [attachment.uploadPath, null, 1, attachment.mimeType];
    const att2 = [desc2, attachment.filename, null, null, null, null, null, null, [0]];
    payloadVariants.push([
      [prompt, 0, null, [att2], null, null, 0],
      ["en"],
      ["", "", ""],
      null,
      null,
      null,
      [1],
      1,
      null,
      null,
      1,
      0
    ]);

    payloadVariants.push([
      [prompt, 0, null, [[[attachment.uploadPath], attachment.filename]], null, null, 0],
      ["en"],
      ["", "", ""],
      null,
      null,
      null,
      [1],
      1,
      null,
      null,
      1,
      0
    ]);
  } else {
    payloadVariants.push([
      [prompt, 0, null, null, null, null, 0],
      ["en"],
      ["", "", ""],
      null,
      null,
      null,
      [1],
      1,
      null,
      null,
      1,
      0
    ]);
  }

  let lastParsed = { urls: [], assistantText: "" };
  let activeSession = session || (await getGeminiSession(false));
  let currentAttachment = attachment;
  let switchedAccountOnce = false;

  for (let vIdx = 0; vIdx < payloadVariants.length; vIdx++) {
    if (
      currentAttachment &&
      currentAttachment.sourceBlob &&
      currentAttachment.authUser !== undefined &&
      currentAttachment.authUser !== (activeSession.authUser || 0)
    ) {
      currentAttachment = await uploadImageToGeminiForImg2Img(
        currentAttachment.sourceBlob,
        currentAttachment.filename,
        activeSession,
        2
      );
    }

    const innerPayload = payloadVariants[vIdx];
    const u = activeSession.authUser || 0;
    const reqId = Math.floor(100000 + Math.random() * 900000);
    const queryParams = new URLSearchParams({
      bl: activeSession.bl,
      hl: "en",
      _reqid: String(reqId),
      rt: "c",
      authuser: String(u)
    });
    if (activeSession.fSid) {
      queryParams.set("f.sid", activeSession.fSid);
    }

    const endpoint = `https://gemini.google.com/u/${u}/_/BardChatUi/data/assistant.lamda.BardFrontendService/StreamGenerate?${queryParams.toString()}`;
    const outerPayload = [null, JSON.stringify(innerPayload)];
    const formBody = new URLSearchParams();
    formBody.set("f.req", JSON.stringify(outerPayload));
    formBody.set("at", activeSession.at);

    let response = await fetch(endpoint, {
      method: "POST",
      credentials: "include",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        "X-Same-Domain": "1"
      },
      body: formBody.toString()
    });

    if (response.status === 401 || response.status === 403 || response.status === 400) {
      activeSession = await getGeminiSession(true, u);
      formBody.set("at", activeSession.at);
      response = await fetch(endpoint, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
          "X-Same-Domain": "1"
        },
        body: formBody.toString()
      });
    }

    if (response.status === 429 || response.status === 503) {
      if (!switchedAccountOnce) {
        const failoverSession = await trySwitchToNextGeminiAccount(u);
        if (failoverSession) {
          switchedAccountOnce = true;
          activeSession = failoverSession;
          vIdx--;
          continue;
        }
      }
    }

    if (!response.ok) {
      if (vIdx === payloadVariants.length - 1) {
        throw new Error(`StreamGenerate RPC failed on u/${u} with HTTP ${response.status}`);
      }
      continue;
    }

    const rawText = await response.text();
    const parsed = parseStreamGenerateResponse(rawText, excludeUrls);
    lastParsed = parsed;

    if (parsed.urls && parsed.urls.length > 0) {
      return parsed;
    }

    if (
      !switchedAccountOnce &&
      (!parsed.urls || parsed.urls.length === 0) &&
      (isQuotaOrLimitFailure(200, parsed.assistantText) || vIdx === payloadVariants.length - 1)
    ) {
      const failoverSession = await trySwitchToNextGeminiAccount(u);
      if (failoverSession) {
        switchedAccountOnce = true;
        activeSession = failoverSession;
        if (currentAttachment && currentAttachment.sourceBlob) {
          currentAttachment = await uploadImageToGeminiForImg2Img(
            currentAttachment.sourceBlob,
            currentAttachment.filename,
            activeSession,
            2
          );
          payloadVariants[0][0][3] = [
            [
              [currentAttachment.uploadPath, 1, null, currentAttachment.mimeType, currentAttachment.processFileUuid].filter((x) => x !== undefined),
              currentAttachment.filename,
              null, null, null, null, null, null, [0]
            ]
          ];
        }
        vIdx = -1;
        continue;
      }
    }
  }

  return lastParsed;
}

function isValidImageBuffer(buffer) {
  if (!buffer || buffer.byteLength < 2048) return false;
  const b = new Uint8Array(buffer);
  if (b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return true;
  if (b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47) return true;
  if (
    b[0] === 0x52 &&
    b[1] === 0x49 &&
    b[2] === 0x46 &&
    b[3] === 0x46 &&
    b[8] === 0x57 &&
    b[9] === 0x45 &&
    b[10] === 0x42 &&
    b[11] === 0x50
  ) {
    return true;
  }
  return false;
}

async function validateDecodableImageBlob(blob) {
  if (!blob || blob.size < 2048) return false;
  try {
    const bmp = await createImageBitmap(blob);
    const valid = bmp.width > 16 && bmp.height > 16;
    bmp.close();
    return valid;
  } catch (_) {
    return false;
  }
}

async function decompressZipSlice(compressedSlice, compressionMethod) {
  if (compressionMethod === 0) {
    return compressedSlice.buffer.slice(
      compressedSlice.byteOffset,
      compressedSlice.byteOffset + compressedSlice.byteLength
    );
  }
  if (compressionMethod === 8) {
    try {
      const ds = new DecompressionStream("deflate-raw");
      const writer = ds.writable.getWriter();
      writer.write(compressedSlice);
      writer.close();
      const decompressedResp = new Response(ds.readable);
      return await decompressedResp.arrayBuffer();
    } catch (_) {
      const wrapped = new Uint8Array(compressedSlice.byteLength + 2);
      wrapped[0] = 0x78;
      wrapped[1] = 0x9c;
      wrapped.set(compressedSlice, 2);
      const ds = new DecompressionStream("deflate");
      const writer = ds.writable.getWriter();
      const reader = ds.readable.getReader();
      const chunks = [];
      writer.write(wrapped).catch(() => {});
      writer.close().catch(() => {});
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          if (value) chunks.push(value);
        }
      } catch (_) {}
      const total = chunks.reduce((acc, c) => acc + c.byteLength, 0);
      const out = new Uint8Array(total);
      let offset = 0;
      for (const c of chunks) {
        out.set(c, offset);
        offset += c.byteLength;
      }
      return out.buffer;
    }
  }
  throw new Error(`Unsupported ZIP compression method: ${compressionMethod}`);
}

async function extractFirstFileFromZip(zipBuffer) {
  if (!zipBuffer || zipBuffer.byteLength < 4096) {
    throw new Error("Archive ZIP is too small (still processing or NOT_FOUND).");
  }

  const view = new DataView(zipBuffer);
  const bytes = new Uint8Array(zipBuffer);

  if (view.getUint32(0, true) !== 0x04034b50) {
    throw new Error("Invalid ZIP header received from Cloudinary archive endpoint.");
  }

  const decoder = new TextDecoder("utf-8");

  let eocdOffset = -1;
  const minEocdSearch = Math.max(0, bytes.length - 65557);
  for (let i = bytes.length - 22; i >= minEocdSearch; i--) {
    if (view.getUint32(i, true) === 0x06054b50) {
      eocdOffset = i;
      break;
    }
  }

  if (eocdOffset !== -1) {
    const totalEntries = view.getUint16(eocdOffset + 10, true);
    let cdPos = view.getUint32(eocdOffset + 16, true);

    for (let e = 0; e < totalEntries && cdPos + 46 <= bytes.length; e++) {
      if (view.getUint32(cdPos, true) !== 0x02014b50) break;

      const compressionMethod = view.getUint16(cdPos + 10, true);
      const compressedSize = view.getUint32(cdPos + 20, true);
      const uncompressedSize = view.getUint32(cdPos + 24, true);
      const nameLen = view.getUint16(cdPos + 28, true);
      const extraLen = view.getUint16(cdPos + 30, true);
      const commentLen = view.getUint16(cdPos + 32, true);
      const localHeaderOffset = view.getUint32(cdPos + 42, true);

      const entryName = decoder.decode(bytes.subarray(cdPos + 46, cdPos + 46 + nameLen));
      cdPos += 46 + nameLen + extraLen + commentLen;

      if (
        entryName.endsWith("/") ||
        entryName.includes(".text") ||
        uncompressedSize < 2048 ||
        compressedSize === 0
      ) {
        continue;
      }

      if (localHeaderOffset + 30 > bytes.length) continue;
      if (view.getUint32(localHeaderOffset, true) !== 0x04034b50) continue;

      const localNameLen = view.getUint16(localHeaderOffset + 26, true);
      const localExtraLen = view.getUint16(localHeaderOffset + 28, true);
      const dataStart = localHeaderOffset + 30 + localNameLen + localExtraLen;
      if (dataStart + compressedSize > bytes.length) continue;

      const compressedSlice = bytes.subarray(dataStart, dataStart + compressedSize);
      const outBuffer = await decompressZipSlice(compressedSlice, compressionMethod);

      if (isValidImageBuffer(outBuffer)) {
        return new Blob([outBuffer], { type: "image/jpeg" });
      }
    }
  }

  throw new Error("ZIP archive did not contain a valid upscaled image yet.");
}

async function normalizeImageBlobForUpload(sourceBlob) {
  try {
    const bmp = await createImageBitmap(sourceBlob);
    try {
      const canvas = new OffscreenCanvas(bmp.width, bmp.height);
      const ctx = canvas.getContext("2d", { alpha: false });
      ctx.fillStyle = "#FFFFFF";
      ctx.fillRect(0, 0, bmp.width, bmp.height);
      ctx.drawImage(bmp, 0, 0);
      return await canvas.convertToBlob({ type: "image/jpeg", quality: 0.96 });
    } finally {
      bmp.close();
    }
  } catch (_) {
    return sourceBlob;
  }
}

async function upscaleViaCloudinary(imageBlob, uploadFilename, label = "Image", stepNum = 2) {
  const maxUploadCycles = 2;
  let lastError = null;

  for (let cycle = 1; cycle <= maxUploadCycles; cycle++) {
    try {
      const timestamp = Math.floor(Date.now() / 1000);
      const blobToUpload = cycle === 1 ? imageBlob : await normalizeImageBlobForUpload(imageBlob);

      broadcastStatus({
        state: "upscaling",
        step: stepNum,
        message: `Cloudinary AI Upscale (${label}) [1/3]: Signing upload parameters${cycle > 1 ? " (retry)" : ""}...`
      });

      const signResp = await fetch(CLOUDINARY_SIGN_URL, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "*/*"
        },
        body: JSON.stringify({
          paramsToSign: {
            timestamp,
            upload_preset: CLOUDINARY_UPLOAD_PRESET,
            source: CLOUDINARY_SOURCE
          }
        })
      });

      if (!signResp.ok) {
        throw new Error(`Cloudinary signature request failed (HTTP ${signResp.status})`);
      }

      const signJson = await signResp.json();
      const signature = signJson.signature;
      if (!signature) {
        throw new Error("Cloudinary sign-upload-params did not return a valid signature.");
      }

      broadcastStatus({
        state: "upscaling",
        step: stepNum,
        message: `Cloudinary AI Upscale (${label}) [2/3]: Uploading image to Cloudinary...`
      });

      const formData = new FormData();
      formData.append("upload_preset", CLOUDINARY_UPLOAD_PRESET);
      formData.append("source", CLOUDINARY_SOURCE);
      formData.append("signature", signature);
      formData.append("timestamp", String(timestamp));
      formData.append("api_key", CLOUDINARY_API_KEY);
      formData.append("file", blobToUpload, uploadFilename);

      const uploadResp = await fetch(CLOUDINARY_UPLOAD_URL, {
        method: "POST",
        headers: {
          "Accept": "application/json, text/javascript, */*; q=0.01",
          "X-Requested-With": "XMLHttpRequest"
        },
        body: formData
      });

      if (!uploadResp.ok) {
        const errText = await uploadResp.text().catch(() => "");
        throw new Error(`Cloudinary upload failed (HTTP ${uploadResp.status}): ${errText.slice(0, 120)}`);
      }

      const uploadJson = await uploadResp.json();
      const publicId = uploadJson.public_id;
      const version = uploadJson.version;
      if (!publicId) {
        throw new Error("Cloudinary upload response missing public_id.");
      }

      const upscaleUrl = `https://res.cloudinary.com/${CLOUDINARY_CLOUD_NAME}/image/upload/f_jpg,w_512,e_upscale,q_auto/${publicId}.jpg`;
      const versionedUpscaleUrl = version
        ? `https://res.cloudinary.com/${CLOUDINARY_CLOUD_NAME}/image/upload/f_jpg,w_512,e_upscale,q_auto/v${version}/${publicId}.jpg`
        : upscaleUrl;
      const shortName = publicId.split("/").pop() || "upscaled_image";

      broadcastStatus({
        state: "upscaling",
        step: stepNum,
        message: `Cloudinary AI Upscale (${label}) [3/3]: Triggering AI super-resolution...`
      });

      try {
        await fetch(upscaleUrl, { method: "HEAD" });
      } catch (_) {}

      try {
        const initGetResp = await fetch(upscaleUrl, {
          method: "GET",
          headers: {
            "Accept": "image/jxl,image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8"
          }
        });
        if (initGetResp.status === 200) {
          const arrBuf = await initGetResp.arrayBuffer();
          if (isValidImageBuffer(arrBuf)) {
            const candidateBlob = new Blob([arrBuf], { type: "image/jpeg" });
            if (await validateDecodableImageBlob(candidateBlob)) {
              return { blob: candidateBlob, upscaleUrl, publicId };
            }
          }
        }
      } catch (_) {}

      await sleep(4500);

      const maxAttempts = 10;
      let resourceExpired404 = false;

      for (let attempt = 1; attempt <= maxAttempts; attempt++) {
        broadcastStatus({
          state: "upscaling",
          step: stepNum,
          message: `Cloudinary AI Upscale (${label}): Waiting for super-resolution (${attempt}/${maxAttempts})...`
        });

        try {
          const targetUrlForArchive = attempt % 2 === 1 ? upscaleUrl : versionedUpscaleUrl;
          const imagesParam = JSON.stringify([
            { url: targetUrlForArchive, name: shortName, type: "jpg" }
          ]);
          const archiveResp = await fetch(
            `${CLOUDINARY_ARCHIVE_URL}?images=${encodeURIComponent(imagesParam)}`,
            {
              method: "GET",
              headers: { "Accept": "*/*" }
            }
          );
          if (archiveResp.ok) {
            const zipBuf = await archiveResp.arrayBuffer();
            if (zipBuf && zipBuf.byteLength >= 4096) {
              const unzippedBlob = await extractFirstFileFromZip(zipBuf);
              if (await validateDecodableImageBlob(unzippedBlob)) {
                return {
                  blob: unzippedBlob,
                  upscaleUrl,
                  publicId
                };
              }
            }
          }
        } catch (_) {}

        try {
          const directPollUrl =
            attempt % 2 === 1
              ? `${versionedUpscaleUrl}?_cb=${Date.now()}_${attempt}`
              : `${upscaleUrl}?_cb=${Date.now()}_${attempt}`;
          const pollResp = await fetch(directPollUrl, {
            method: "GET",
            headers: {
              "Accept": "image/jxl,image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8"
            }
          });

          if (pollResp.status === 200) {
            const arrBuf = await pollResp.arrayBuffer();
            if (isValidImageBuffer(arrBuf)) {
              const candidateBlob = new Blob([arrBuf], { type: "image/jpeg" });
              if (await validateDecodableImageBlob(candidateBlob)) {
                return {
                  blob: candidateBlob,
                  upscaleUrl,
                  publicId
                };
              }
            }
          }

          if (pollResp.status === 404) {
            const cldErr = (pollResp.headers.get("x-cld-error") || "").toLowerCase();
            if (cldErr.includes("not found") || attempt >= 3) {
              resourceExpired404 = true;
              break;
            }
          }
        } catch (_) {}

        if (resourceExpired404) break;
        await sleep(3000);
      }

      lastError = new Error(
        resourceExpired404
          ? `Temporary Cloudinary asset expired after 35s on cycle ${cycle}`
          : `Timed out waiting for Cloudinary AI upscale (${label}) on cycle ${cycle}`
      );
    } catch (cycleErr) {
      lastError = cycleErr;
    }
  }

  throw lastError || new Error(`Timed out waiting for Cloudinary AI upscale (${label}).`);
}

async function preCropBlobToTargetAspect(sourceBlob, targetWidth, targetHeight) {
  try {
    const bmp = await createImageBitmap(sourceBlob);
    try {
      const srcAspect = bmp.width / bmp.height;
      const targetAspect = targetWidth / targetHeight;

      if (Math.abs(srcAspect - targetAspect) / targetAspect <= 0.008) {
        return sourceBlob;
      }

      let cropX = 0;
      let cropY = 0;
      let cropW = bmp.width;
      let cropH = bmp.height;

      if (srcAspect > targetAspect) {
        cropW = Math.max(1, Math.round(bmp.height * targetAspect));
        cropX = Math.round((bmp.width - cropW) / 2);
      } else {
        cropH = Math.max(1, Math.round(bitmap.width / targetAspect));
        cropY = Math.round((bmp.height - cropH) / 2);
      }

      const cropCanvas = new OffscreenCanvas(cropW, cropH);
      const cropCtx = cropCanvas.getContext("2d", { alpha: false });
      cropCtx.fillStyle = "#000000";
      cropCtx.fillRect(0, 0, cropW, cropH);
      cropCtx.imageSmoothingEnabled = true;
      cropCtx.imageSmoothingQuality = "high";
      cropCtx.drawImage(bmp, cropX, cropY, cropW, cropH, 0, 0, cropW, cropH);

      return await cropCanvas.convertToBlob({
        type: "image/jpeg",
        quality: JPEG_QUALITY_100
      });
    } finally {
      bmp.close();
    }
  } catch (_) {
    return sourceBlob;
  }
}

async function resizeImageToJpg100(sourceBlob, targetWidth, targetHeight, fallbackBlob = null) {
  let bitmap;
  try {
    bitmap = await createImageBitmap(sourceBlob);
  } catch (decodeErr) {
    if (fallbackBlob && fallbackBlob !== sourceBlob) {
      bitmap = await createImageBitmap(fallbackBlob);
    } else {
      throw decodeErr;
    }
  }

  try {
    const srcAspect = bitmap.width / bitmap.height;
    const targetAspect = targetWidth / targetHeight;

    let cropX = 0;
    let cropY = 0;
    let cropW = bitmap.width;
    let cropH = bitmap.height;

    if (Math.abs(srcAspect - targetAspect) / targetAspect > 0.002) {
      if (srcAspect > targetAspect) {
        cropW = Math.max(1, Math.round(bitmap.height * targetAspect));
        cropX = Math.round((bitmap.width - cropW) / 2);
      } else {
        cropH = Math.max(1, Math.round(bitmap.width / targetAspect));
        cropY = Math.round((bitmap.height - cropH) / 2);
      }
    }

    let currentSource = bitmap;
    let currentW = cropW;
    let currentH = cropH;

    if (cropX !== 0 || cropY !== 0 || cropW !== bitmap.width || cropH !== bitmap.height) {
      const baseCropCanvas = new OffscreenCanvas(cropW, cropH);
      const baseCropCtx = baseCropCanvas.getContext("2d", { alpha: false });
      baseCropCtx.imageSmoothingEnabled = true;
      baseCropCtx.imageSmoothingQuality = "high";
      baseCropCtx.drawImage(bitmap, cropX, cropY, cropW, cropH, 0, 0, cropW, cropH);
      currentSource = baseCropCanvas;
    }

    while (currentW * 1.5 < targetWidth) {
      const stepW = Math.min(targetWidth, Math.round(currentW * 1.5));
      const stepH = Math.min(targetHeight, Math.round((stepW / targetWidth) * targetHeight));
      if (stepW <= currentW || stepH <= currentH) break;

      const stepCanvas = new OffscreenCanvas(stepW, stepH);
      const stepCtx = stepCanvas.getContext("2d", { alpha: false });
      stepCtx.imageSmoothingEnabled = true;
      stepCtx.imageSmoothingQuality = "high";
      stepCtx.drawImage(currentSource, 0, 0, stepW, stepH);
      currentSource = stepCanvas;
      currentW = stepW;
      currentH = stepH;
    }

    const canvas = new OffscreenCanvas(targetWidth, targetHeight);
    const ctx = canvas.getContext("2d", { alpha: false });

    ctx.fillStyle = "#000000";
    ctx.fillRect(0, 0, targetWidth, targetHeight);
    ctx.imageSmoothingEnabled = true;
    ctx.imageSmoothingQuality = "high";

    ctx.drawImage(currentSource, 0, 0, targetWidth, targetHeight);

    let appliedQuality = JPEG_QUALITY_100;
    let jpgBlob = await canvas.convertToBlob({
      type: "image/jpeg",
      quality: appliedQuality
    });

    const qualitySteps = [0.96, 0.92, 0.88, 0.84, 0.80];
    for (const q of qualitySteps) {
      if (jpgBlob.size <= SAFE_ZEDGE_TARGET_BYTES) break;
      appliedQuality = q;
      jpgBlob = await canvas.convertToBlob({
        type: "image/jpeg",
        quality: appliedQuality
      });
    }

    const thumbWidth = targetWidth >= targetHeight ? 640 : 450;
    const thumbHeight = Math.round((targetHeight / targetWidth) * thumbWidth) || 800;
    const thumbCanvas = new OffscreenCanvas(thumbWidth, thumbHeight);
    const thumbCtx = thumbCanvas.getContext("2d", { alpha: false });
    thumbCtx.imageSmoothingEnabled = true;
    thumbCtx.imageSmoothingQuality = "high";
    thumbCtx.drawImage(canvas, 0, 0, thumbWidth, thumbHeight);
    const thumbBlob = await thumbCanvas.convertToBlob({
      type: "image/jpeg",
      quality: 0.88
    });
    const thumbBuffer = await thumbBlob.arrayBuffer();
    const thumbDataUrl = `data:image/jpeg;base64,${arrayBufferToBase64(thumbBuffer)}`;

    return {
      jpgBlob,
      width: targetWidth,
      height: targetHeight,
      qualityPct: Math.round(appliedQuality * 100),
      megapixels: Number(((targetWidth * targetHeight) / 1000000).toFixed(2)),
      zedgeCompliant:
        targetWidth >= MIN_ZEDGE_WIDTH &&
        targetHeight >= MIN_ZEDGE_HEIGHT &&
        targetWidth * targetHeight < MAX_ZEDGE_MEGAPIXELS &&
        jpgBlob.size <= MAX_ZEDGE_FILE_BYTES,
      thumbDataUrl
    };
  } finally {
    bitmap.close();
  }
}

async function upscaleResizeAndSaveBlob({
  sourceBlob,
  uploadFilename,
  downloadFilename,
  exactFilename = null,
  zipName = null,
  distSlot = null,
  targetWidth,
  targetHeight,
  label,
  badge = null,
  slotIndex = null,
  stageKey = null,
  stagePrompt = null,
  stepNum,
  hdUrl,
  role,
  upscaleEnabled = true,
  autoDownload = false
}) {
  const aspectMatchedBlob = await preCropBlobToTargetAspect(sourceBlob, targetWidth, targetHeight);
  let blobToResize = aspectMatchedBlob;
  let upscaleUrl = null;
  let upscaledViaCloudinary = false;

  if (upscaleEnabled) {
    try {
      const upRes = await upscaleViaCloudinary(aspectMatchedBlob, uploadFilename, label, stepNum);
      if (upRes && upRes.blob) {
        blobToResize = upRes.blob;
        upscaleUrl = upRes.upscaleUrl;
        upscaledViaCloudinary = true;
      }
    } catch (err) {
      broadcastStatus({
        state: "upscaling",
        step: stepNum,
        message: `Cloudinary notice on ${label} (${err.message}). Using progressive HD super-sampling to ${targetWidth}×${targetHeight} JPG...`
      });
      blobToResize = aspectMatchedBlob;
    }
  }

  broadcastStatus({
    state: "resizing",
    step: stepNum,
    message: `Preparing ${label} (${targetWidth}×${targetHeight} JPG, <=8MB verified)...`
  });

  const {
    jpgBlob,
    width,
    height,
    qualityPct,
    megapixels,
    zedgeCompliant,
    thumbDataUrl
  } = await resizeImageToJpg100(
    blobToResize,
    targetWidth,
    targetHeight,
    aspectMatchedBlob
  );

  const finalBuffer = await jpgBlob.arrayBuffer();
  const base64DataUrl = `data:image/jpeg;base64,${arrayBufferToBase64(finalBuffer)}`;
  const assetId = `asset_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

  storePreparedJpg(assetId, {
    base64DataUrl,
    filename: downloadFilename,
    exactFilename: exactFilename || downloadFilename.split("/").pop(),
    zipName: zipName || exactFilename || downloadFilename.split("/").pop(),
    distSlot: distSlot || stageKey || "wallpaper",
    width,
    height,
    byteSize: finalBuffer.byteLength
  });

  let downloadId = null;
  if (autoDownload) {
    downloadId = await chrome.downloads.download({
      url: base64DataUrl,
      filename: downloadFilename,
      saveAs: false
    });
  }

  return {
    assetId,
    downloadId,
    downloaded: Boolean(autoDownload),
    filename: downloadFilename,
    exactFilename: exactFilename || downloadFilename.split("/").pop(),
    zipName: zipName || exactFilename || downloadFilename.split("/").pop(),
    distSlot: distSlot || stageKey || "wallpaper",
    role,
    label,
    badge: badge || label,
    slotIndex,
    stageKey,
    stagePrompt,
    hdUrl: hdUrl || upscaleUrl,
    upscaleUrl,
    upscaledViaCloudinary,
    width,
    height,
    megapixels,
    zedgeCompliant,
    format: "jpg",
    quality: qualityPct,
    byteSize: finalBuffer.byteLength,
    previewDataUrl: thumbDataUrl
  };
}

/**
 * Generates a multi-image Wallpaper Set with support for:
 * - AI Set Director (optional)
 * - Story Arcs (24h: auto/light/bloom/rhythm; Battery: auto/energy/growth/awaken)
 * - Display Tuning (any/amoled/ips), Color Boost (off/subtle/vivid/neon), Variation Strength (subtle/clear/strong)
 * - Auto AI Metadata Generation (title, tags, keywords CSV, category, description)
 */
async function generateWallpaperSetWorkflow({
  prompt,
  negativePrompt = "",
  workflowMode, // "set_dual" | "set_24h" | "set_battery"
  customStages = null,
  storyArc = "auto",
  variationStrength = "clear",
  displayTarget = "any",
  colorBoost = "off",
  aiDirectorEnabled = false,
  autoWriteMetadata = true,
  includeFoldableCompanion = false,
  landscapePrompt = "make it landscape mode, re-frame the exact same artwork for a foldable screen without cropping the main subject",
  referenceDataUrl = null,
  referenceFilename = "reference_image.jpg",
  forceImagePrefix = true,
  upscaleEnabled = true,
  autoDownload = false,
  useExactZedgeNames = true,
  subfolder = "Gemini_HD",
  portraitWidth = PORTRAIT_WIDTH,
  portraitHeight = PORTRAIT_HEIGHT,
  landscapeWidth = LANDSCAPE_WIDTH,
  landscapeHeight = LANDSCAPE_HEIGHT
}) {
  const session = await getGeminiSession(false);
  const { width: targetWidth, height: targetHeight } = normalizeZedgeDimensions(
    portraitWidth,
    portraitHeight,
    true
  );

  const defaultStageTemplate =
    workflowMode === "set_dual"
      ? DEFAULT_DUAL_SET_STAGES
      : workflowMode === "set_24h"
      ? DEFAULT_24H_SET_STAGES
      : DEFAULT_BATTERY_SET_STAGES;

  // Resolve Story Arc stages if applicable
  let arcStagePrompts = null;
  if (workflowMode === "set_24h") {
    const resolvedArc = storyArc === "auto" ? suggest24hArc(prompt) : storyArc;
    arcStagePrompts = STORY_ARCS_24H[resolvedArc] || STORY_ARCS_24H.light;
  } else if (workflowMode === "set_battery") {
    const resolvedArc = storyArc === "auto" ? suggestBatteryArc(prompt) : storyArc;
    arcStagePrompts = STORY_ARCS_BATTERY[resolvedArc] || STORY_ARCS_BATTERY.energy;
  }

  // Optional AI Set Director planning step
  let directorPlan = null;
  if (aiDirectorEnabled) {
    try {
      broadcastStatus({
        state: "generating",
        step: 1,
        message: "AI Set Director: Planning set story arc, anchor & stage lighting directions..."
      });
      directorPlan = await directSetWithGemini({
        workflowMode,
        variantLabels: defaultStageTemplate.map((s) => s.shortLabel),
        prompt,
        session
      });
    } catch (_) {
      directorPlan = null;
    }
  }

  const styleSuffix = buildStyleSuffix(displayTarget, colorBoost);
  const chainStrengthNote = VARIATION_STRENGTHS[variationStrength] || VARIATION_STRENGTHS.clear;

  const stages = defaultStageTemplate.map((st, idx) => {
    const customOverride =
      Array.isArray(customStages) && customStages[idx] ? customStages[idx].trim() : "";
    const directedStage =
      directorPlan && directorPlan.stages && directorPlan.stages[idx]
        ? directorPlan.stages[idx].direction
        : "";
    const arcDefault = arcStagePrompts && arcStagePrompts[idx] ? arcStagePrompts[idx] : "";

    return {
      ...st,
      customInstruction:
        customOverride || directedStage || arcDefault || st.transitionInstruction || st.promptSuffix
    };
  });

  const totalStages = stages.length;
  const safeSlug =
    (prompt || referenceFilename || "wallpaper_set")
      .toLowerCase()
      .replace(/\.[^.]+$/, "")
      .replace(/[^a-z0-9]+/g, "_")
      .replace(/^_+|_+$/g, "")
      .slice(0, 32) || "wallpaper_set";
  const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
  const baseSubfolder = subfolder ? subfolder.replace(/^\/+|\/+$/g, "") : "Gemini_HD";
  const setFolderName = `${safeSlug}_${workflowMode}_${timestamp}`;
  const setFolderPrefix = `${baseSubfolder}/${setFolderName}/`;

  const anchorStage = stages.find((s) => s.isAnchor) || stages[0];
  let anchorSourceBlob = null;
  let anchorSourceFilename = `${safeSlug}_anchor_HD.jpg`;
  let anchorHdUrl = null;
  const seenBaseUrls = [];
  const resultsBySlot = new Map();

  // STEP A: Obtain or Generate the Anchor Image first
  if (referenceDataUrl) {
    anchorSourceBlob = dataUrlToBlob(referenceDataUrl);
    anchorSourceFilename = referenceFilename || `${safeSlug}_anchor_ref.jpg`;
  } else {
    const directorAnchorExtra =
      directorPlan && directorPlan.anchorDirection ? `, ${directorPlan.anchorDirection}` : "";
    const negGuard = buildNegativeGuard(negativePrompt);
    const combinedAnchorPrompt = `${prompt.trim()}${directorAnchorExtra}, ${anchorStage.customInstruction}${styleSuffix}${negGuard}${PRO_FINISH_SUFFIX}`;
    const fullAnchorPrompt = buildImagePrompt(combinedAnchorPrompt, "9:16", forceImagePrefix);

    broadcastStatus({
      state: "generating",
      step: 1,
      message: `[1/${totalStages}] Generating Anchor (${anchorStage.shortLabel}) via Gemini 9:16 RPC...`
    });

    const parsedAnchor = await callGeminiStreamGenerate({
      prompt: fullAnchorPrompt,
      session
    });

    if (!parsedAnchor.urls || parsedAnchor.urls.length === 0) {
      const hint = parsedAnchor.assistantText
        ? `Gemini replied with text instead of an image: "${parsedAnchor.assistantText.slice(0, 180)}"`
        : "No 9:16 anchor image URL was returned by Gemini StreamGenerate.";
      throw new Error(hint);
    }

    parsedAnchor.urls.forEach((u) => seenBaseUrls.push(u));
    const fetchedAnchor = await fetchGeminiHdBlob(parsedAnchor.urls[0]);
    anchorSourceBlob = fetchedAnchor.blob;
    anchorSourceFilename = `${safeSlug}_anchor.${fetchedAnchor.ext}`;
    anchorHdUrl = fetchedAnchor.finalHdUrl;

    const anchorDownloadName = useExactZedgeNames
      ? `${setFolderPrefix}${anchorStage.exactFilename}`
      : `${setFolderPrefix}set-01/${anchorStage.zipName}`;

    const anchorSaved = await upscaleResizeAndSaveBlob({
      sourceBlob: anchorSourceBlob,
      uploadFilename: anchorSourceFilename,
      downloadFilename: anchorDownloadName,
      exactFilename: anchorStage.exactFilename,
      zipName: anchorStage.zipName,
      distSlot: anchorStage.distSlot,
      targetWidth,
      targetHeight,
      label: anchorStage.shortLabel,
      badge: anchorStage.badge,
      slotIndex: anchorStage.slotIndex,
      stageKey: anchorStage.key,
      stagePrompt: combinedAnchorPrompt,
      stepNum: 1,
      hdUrl: anchorHdUrl,
      role: anchorStage.role,
      upscaleEnabled,
      autoDownload
    });

    resultsBySlot.set(anchorStage.slotIndex, anchorSaved);
  }

  // STEP B: Upload Anchor Image once to Gemini
  const uploadedAnchorAttachment = await uploadImageToGeminiForImg2Img(
    anchorSourceBlob,
    anchorSourceFilename,
    session,
    2
  );

  const anchorPreviewSaved = resultsBySlot.get(anchorStage.slotIndex);
  let anchorReferenceDataUrl = anchorPreviewSaved ? anchorPreviewSaved.previewDataUrl : referenceDataUrl;

  // STEP C: Generate all remaining stages from the uploaded Anchor Attachment
  let completedCount = resultsBySlot.size;

  for (const stage of stages) {
    if (resultsBySlot.has(stage.slotIndex)) {
      continue;
    }

    completedCount++;
    const progressStep = Math.min(4, Math.max(2, Math.ceil((completedCount / totalStages) * 4)));
    const hueAnchor =
      workflowMode === "set_battery"
        ? ", keep the exact same glow and light hue as the reference image - the hue never changes, only the charge level changes"
        : "";
    const negGuard = buildNegativeGuard(negativePrompt);
    const img2imgPrompt = `${prompt.trim()}, ${stage.customInstruction}, ${chainStrengthNote}${styleSuffix}${hueAnchor}${negGuard}${PRO_FINISH_SUFFIX} (aspect ratio 9:16)`;

    broadcastStatus({
      state: "img2img_generating",
      step: progressStep,
      message: `[${completedCount}/${totalStages}] Generating ${stage.shortLabel} via Gemini Image-to-Image RPC...`
    });

    let parsedStage = await callGeminiStreamGenerate({
      prompt: img2imgPrompt,
      session,
      attachment: uploadedAnchorAttachment,
      aspectRatioHint: "9:16",
      excludeUrls: seenBaseUrls
    });

    if (!parsedStage.urls || parsedStage.urls.length === 0) {
      parsedStage = await callGeminiStreamGenerate({
        prompt: `Generate an edited 9:16 vertical wallpaper version of this exact image: ${img2imgPrompt}`,
        session,
        attachment: uploadedAnchorAttachment,
        aspectRatioHint: "9:16",
        excludeUrls: seenBaseUrls
      });
    }

    if (!parsedStage.urls || parsedStage.urls.length === 0) {
      const hint =
        parsedStage && parsedStage.assistantText
          ? `Gemini replied with text on ${stage.shortLabel}: "${parsedStage.assistantText.slice(0, 160)}"`
          : `No image URL returned by Gemini for ${stage.shortLabel}.`;
      throw new Error(hint);
    }

    parsedStage.urls.forEach((u) => seenBaseUrls.push(u));
    const fetchedStage = await fetchGeminiHdBlob(parsedStage.urls[0]);

    const stageDownloadName = useExactZedgeNames
      ? `${setFolderPrefix}${stage.exactFilename}`
      : `${setFolderPrefix}set-01/${stage.zipName}`;

    const stageSaved = await upscaleResizeAndSaveBlob({
      sourceBlob: fetchedStage.blob,
      uploadFilename: `${safeSlug}_${stage.key}_HD.${fetchedStage.ext}`,
      downloadFilename: stageDownloadName,
      exactFilename: stage.exactFilename,
      zipName: stage.zipName,
      distSlot: stage.distSlot,
      targetWidth,
      targetHeight,
      label: stage.shortLabel,
      badge: stage.badge,
      slotIndex: stage.slotIndex,
      stageKey: stage.key,
      stagePrompt: img2imgPrompt,
      stepNum: progressStep,
      hdUrl: fetchedStage.finalHdUrl,
      role: stage.role,
      upscaleEnabled,
      autoDownload
    });

    if (!anchorReferenceDataUrl && stage.slotIndex === anchorStage.slotIndex) {
      anchorReferenceDataUrl = stageSaved.previewDataUrl;
    }

    resultsBySlot.set(stage.slotIndex, stageSaved);
  }

  const orderedOutputs = stages
    .slice()
    .sort((a, b) => a.slotIndex - b.slotIndex)
    .map((s) => resultsBySlot.get(s.slotIndex))
    .filter(Boolean);

  if (includeFoldableCompanion && uploadedAnchorAttachment) {
    try {
      const negGuard = buildNegativeGuard(negativePrompt);
      const isSquareFoldable = Math.abs(landscapeWidth - landscapeHeight) <= 32;
      const ratioHint = isSquareFoldable ? "1:1" : "4:3";
      const foldablePrompt = `${(landscapePrompt || "make it landscape mode").trim()}, keep the exact same subject identity, geometry, pose, materials, color palette, lighting direction and mood, extend the background naturally to fill the foldable frame (${landscapeWidth}x${landscapeHeight})${styleSuffix}${negGuard}${PRO_FINISH_SUFFIX}`;

      broadcastStatus({
        state: "img2img_generating",
        step: 4,
        message: `[+Foldable] Generating Foldable Companion (${landscapeWidth}×${landscapeHeight} JPG) from Anchor...`
      });

      let parsedFoldable = await callGeminiStreamGenerate({
        prompt: foldablePrompt,
        session,
        attachment: uploadedAnchorAttachment,
        aspectRatioHint: ratioHint,
        excludeUrls: seenBaseUrls
      });

      if (parsedFoldable && parsedFoldable.urls && parsedFoldable.urls.length > 0) {
        const fetchedFold = await fetchGeminiHdBlob(parsedFoldable.urls[0]);
        const foldExact = useExactZedgeNames
          ? `WP_Foldable_${landscapeWidth}x${landscapeHeight}.jpg`
          : `wallpaper-landscape.jpg`;
        const foldDownloadName = useExactZedgeNames
          ? `${setFolderPrefix}${foldExact}`
          : `${setFolderPrefix}set-01/wallpaper-landscape.jpg`;

        const foldSaved = await upscaleResizeAndSaveBlob({
          sourceBlob: fetchedFold.blob,
          uploadFilename: `${safeSlug}_foldable_HD.${fetchedFold.ext}`,
          downloadFilename: foldDownloadName,
          exactFilename: foldExact,
          zipName: "wallpaper-landscape.jpg",
          distSlot: "wallpaper-landscape",
          targetWidth: landscapeWidth,
          targetHeight: landscapeHeight,
          label: `Foldable (${landscapeWidth}×${landscapeHeight})`,
          badge: `Foldable (${landscapeWidth}×${landscapeHeight})`,
          slotIndex: orderedOutputs.length + 1,
          stageKey: "wallpaper-landscape",
          stagePrompt: foldablePrompt,
          stepNum: 4,
          hdUrl: fetchedFold.finalHdUrl,
          role: "landscape",
          upscaleEnabled,
          autoDownload
        });
        orderedOutputs.push(foldSaved);
      }
    } catch (_) {}
  }

  // STEP D: Automatically generate Zedge/Hub AI Metadata (`metadata.json`) if enabled
  let generatedMeta = null;
  if (autoWriteMetadata && orderedOutputs.length > 0) {
    try {
      broadcastStatus({
        state: "generating",
        step: 4,
        message: "Writing AI listing metadata (Title, Tags, Category, Description) via Gemini..."
      });
      const firstZipFile = `set-01/${orderedOutputs[0].zipName || orderedOutputs[0].exactFilename}`;
      generatedMeta = await generateSetMetadata({
        workflowMode,
        prompt: prompt || referenceFilename,
        file: firstZipFile,
        session
      });
    } catch (_) {
      generatedMeta = null;
    }
  }

  const { history = [] } = await chrome.storage.local.get("history");
  const setTypeLabel =
    workflowMode === "set_dual"
      ? "Dual Wallpaper Set (2 JPGs)"
      : workflowMode === "set_24h"
      ? "24-Hour Wallpaper Set (4 JPGs)"
      : "Battery Level Wallpaper Set (6 JPGs)";

  const newEntry = {
    id: Date.now(),
    prompt: prompt || `[Reference Set] ${referenceFilename}`,
    workflowMode,
    setTypeLabel,
    setFolderName,
    anchorHdUrl,
    anchorReferenceDataUrl,
    directorPlan,
    metadata: generatedMeta,
    createdAt: new Date().toISOString(),
    images: orderedOutputs
  };

  const updatedHistory = [newEntry, ...history].slice(0, 20);
  await chrome.storage.local.set({ history: updatedHistory });

  const doneVerb = autoDownload ? "Downloaded" : "Ready in Studio Showcase";
  broadcastStatus({
    state: "completed",
    step: 4,
    message: `${doneVerb}: ${setTypeLabel}${generatedMeta ? ` + AI Metadata ("${generatedMeta.title}")` : ""}!`,
    results: orderedOutputs
  });

  return { ok: true, results: orderedOutputs, entry: newEntry };
}

/**
 * Imports local image files uploaded by the user directly into a Studio Set in the panel,
 * resizing/upscaling them to 1620x2880 JPG (<=8MB) and optionally generating AI Metadata.
 */
async function importLocalSetToStudio({
  files = [], // Array of { dataUrl, filename }
  workflowMode = "set_24h",
  prompt = "",
  upscaleEnabled = false,
  autoWriteMetadata = true,
  subfolder = "Gemini_HD",
  portraitWidth = PORTRAIT_WIDTH,
  portraitHeight = PORTRAIT_HEIGHT
}) {
  try {
    if (!files || files.length === 0) {
      throw new Error("Please select at least 1 image file to import into the Studio Panel.");
    }

    const { width: targetWidth, height: targetHeight } = normalizeZedgeDimensions(
      portraitWidth,
      portraitHeight,
      true
    );

    const template =
      files.length === 2 || workflowMode === "set_dual"
        ? DEFAULT_DUAL_SET_STAGES
        : files.length === 4 || workflowMode === "set_24h"
        ? DEFAULT_24H_SET_STAGES
        : files.length >= 6 || workflowMode === "set_battery"
        ? DEFAULT_BATTERY_SET_STAGES
        : DEFAULT_DUAL_SET_STAGES;

    const effectiveMode =
      files.length === 2
        ? "set_dual"
        : files.length === 4
        ? "set_24h"
        : files.length >= 6
        ? "set_battery"
        : workflowMode;

    const safeSlug =
      (prompt || files[0].filename || "imported_set")
        .toLowerCase()
        .replace(/\.[^.]+$/, "")
        .replace(/[^a-z0-9]+/g, "_")
        .replace(/^_+|_+$/g, "")
        .slice(0, 28) || "imported_set";
    const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
    const baseSubfolder = subfolder ? subfolder.replace(/^\/+|\/+$/g, "") : "Gemini_HD";
    const setFolderName = `${safeSlug}_${effectiveMode}_${timestamp}`;
    const setFolderPrefix = `${baseSubfolder}/${setFolderName}/`;

    const savedOutputs = [];
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      const st = template[i] || {
        key: `frame${i + 1}`,
        distSlot: `frame${i + 1}`,
        zipName: `frame-${i + 1}.jpg`,
        slotIndex: i + 1,
        role: "portrait",
        badge: `Frame ${i + 1}`,
        shortLabel: `Frame ${i + 1}`,
        exactFilename: `WP_Set_Frame_${i + 1}.jpg`
      };

      broadcastStatus({
        state: "resizing",
        step: Math.min(4, i + 1),
        message: `Importing & formatting [${i + 1}/${files.length}]: ${st.exactFilename} (${targetWidth}×${targetHeight} JPG)...`
      });

      const blob = dataUrlToBlob(f.dataUrl);
      const saved = await upscaleResizeAndSaveBlob({
        sourceBlob: blob,
        uploadFilename: f.filename || st.exactFilename,
        downloadFilename: `${setFolderPrefix}${st.exactFilename}`,
        exactFilename: st.exactFilename,
        zipName: st.zipName,
        distSlot: st.distSlot,
        targetWidth,
        targetHeight,
        label: st.shortLabel,
        badge: st.badge,
        slotIndex: st.slotIndex,
        stageKey: st.key,
        stagePrompt: prompt || f.filename,
        stepNum: Math.min(4, i + 1),
        hdUrl: null,
        role: st.role,
        upscaleEnabled,
        autoDownload: false
      });

      savedOutputs.push(saved);
    }

    let generatedMeta = null;
    if (autoWriteMetadata && (prompt || files[0].filename)) {
      try {
        broadcastStatus({
          state: "generating",
          step: 4,
          message: "Generating AI listing metadata for imported set..."
        });
        const session = await getGeminiSession(false);
        generatedMeta = await generateSetMetadata({
          workflowMode: effectiveMode,
          prompt: prompt || files.map((f) => f.filename).join(", "),
          file: `set-01/${savedOutputs[0].zipName}`,
          session
        });
      } catch (_) {}
    }

    const { history = [] } = await chrome.storage.local.get("history");
    const setTypeLabel =
      effectiveMode === "set_dual"
        ? "Dual Wallpaper Set (2 JPGs)"
        : effectiveMode === "set_24h"
        ? "24-Hour Wallpaper Set (4 JPGs)"
        : effectiveMode === "set_battery"
        ? "Battery Level Wallpaper Set (6 JPGs)"
        : `Imported Wallpaper Set (${savedOutputs.length} JPGs)`;

    const newEntry = {
      id: Date.now(),
      prompt: prompt || `[Imported Set] ${files[0].filename}`,
      workflowMode: effectiveMode,
      setTypeLabel,
      setFolderName,
      anchorReferenceDataUrl: savedOutputs[0] ? savedOutputs[0].previewDataUrl : null,
      metadata: generatedMeta,
      createdAt: new Date().toISOString(),
      images: savedOutputs
    };

    const updatedHistory = [newEntry, ...history].slice(0, 20);
    await chrome.storage.local.set({ history: updatedHistory });

    broadcastStatus({
      state: "completed",
      step: 4,
      message: `Imported ${savedOutputs.length} image(s) into Studio Showcase${generatedMeta ? ` + AI Metadata ("${generatedMeta.title}")` : ""}!`
    });

    return { ok: true, entry: newEntry, results: savedOutputs };
  } catch (error) {
    broadcastStatus({
      state: "error",
      message: error.message || "Failed to import local set."
    });
    return { ok: false, error: error.message };
  }
}

/**
 * Regenerates or updates AI Metadata for an existing set in history.
 */
async function generateOrUpdateHistoryMetadata({ entryId, customMetadata = null }) {
  try {
    const { history = [] } = await chrome.storage.local.get("history");
    const idx = history.findIndex((h) => h.id === entryId);
    if (idx === -1) throw new Error("Set entry not found in history.");

    const entry = history[idx];
    if (customMetadata) {
      entry.metadata = {
        ...entry.metadata,
        ...customMetadata,
        keywords: Array.isArray(customMetadata.tags)
          ? customMetadata.tags.join(", ")
          : customMetadata.keywords || ""
      };
      history[idx] = entry;
      await chrome.storage.local.set({ history });
      return { ok: true, metadata: entry.metadata, entry };
    }

    broadcastStatus({
      state: "generating",
      step: 4,
      message: `Generating AI listing metadata for "${entry.prompt.slice(0, 42)}..."`
    });

    const session = await getGeminiSession(false);
    const firstImg = (entry.images && entry.images[0]) || {};
    const fileRef = `set-01/${firstImg.zipName || firstImg.exactFilename || "wallpaper.jpg"}`;
    const meta = await generateSetMetadata({
      workflowMode: entry.workflowMode || "set_24h",
      prompt: entry.prompt,
      file: fileRef,
      session
    });

    entry.metadata = meta;
    history[idx] = entry;
    await chrome.storage.local.set({ history });

    broadcastStatus({
      state: "completed",
      step: 4,
      message: `AI Metadata generated: "${meta.title}" [${meta.category}] (${meta.tags.length} tags)!`
    });

    return { ok: true, metadata: meta, entry };
  } catch (error) {
    broadcastStatus({
      state: "error",
      message: error.message || "Metadata generation failed."
    });
    return { ok: false, error: error.message };
  }
}

/**
 * Regenerates a single state/slot inside an existing Set Entry using its Anchor Image.
 */
async function regenerateSingleSetStage({
  entryId,
  slotIndex,
  stageKey,
  customStagePrompt,
  upscaleEnabled = true,
  subfolder = "Gemini_HD"
}) {
  try {
    const session = await getGeminiSession(false);
    const { history = [] } = await chrome.storage.local.get("history");
    const entryIndex = history.findIndex((h) => h.id === entryId);
    if (entryIndex === -1) {
      throw new Error("Could not find set entry in history to regenerate.");
    }

    const entry = history[entryIndex];
    const targetImgIndex = (entry.images || []).findIndex(
      (img) => img.slotIndex === slotIndex || img.stageKey === stageKey
    );
    if (targetImgIndex === -1) {
      throw new Error("Could not find target state slot in set.");
    }

    const oldImg = entry.images[targetImgIndex];
    const targetWidth = oldImg.width || PORTRAIT_WIDTH;
    const targetHeight = oldImg.height || PORTRAIT_HEIGHT;

    broadcastStatus({
      state: "generating",
      step: 2,
      message: `Regenerating ${oldImg.label} (${targetWidth}×${targetHeight} JPG) from set anchor...`
    });

    let anchorBlob = null;
    if (entry.anchorHdUrl) {
      try {
        const fetchedAnchor = await fetchGeminiHdBlob(entry.anchorHdUrl);
        anchorBlob = fetchedAnchor.blob;
      } catch (_) {}
    }
    if (!anchorBlob && entry.anchorReferenceDataUrl) {
      anchorBlob = dataUrlToBlob(entry.anchorReferenceDataUrl);
    }
    if (!anchorBlob && entry.images && entry.images[0] && entry.images[0].previewDataUrl) {
      anchorBlob = dataUrlToBlob(entry.images[0].previewDataUrl);
    }

    let parsedNew = null;
    const promptToRun = (customStagePrompt || oldImg.stagePrompt || entry.prompt).trim();

    if (anchorBlob) {
      const uploadedAnchor = await uploadImageToGeminiForImg2Img(
        anchorBlob,
        "set_anchor_ref.jpg",
        session,
        2
      );
      parsedNew = await callGeminiStreamGenerate({
        prompt: `${promptToRun} (aspect ratio 9:16)`,
        session,
        attachment: uploadedAnchor,
        aspectRatioHint: "9:16"
      });
    } else {
      parsedNew = await callGeminiStreamGenerate({
        prompt: buildImagePrompt(promptToRun, "9:16", true),
        session
      });
    }

    if (!parsedNew || !parsedNew.urls || parsedNew.urls.length === 0) {
      throw new Error(`Gemini did not return an image while regenerating ${oldImg.label}.`);
    }

    const fetchedNew = await fetchGeminiHdBlob(parsedNew.urls[0]);
    const baseSubfolder = subfolder ? subfolder.replace(/^\/+|\/+$/g, "") : "Gemini_HD";
    const downloadFilename =
      oldImg.filename ||
      `${baseSubfolder}/${entry.setFolderName || "Set"}/${oldImg.exactFilename || "regenerated.jpg"}`;

    const updatedImg = await upscaleResizeAndSaveBlob({
      sourceBlob: fetchedNew.blob,
      uploadFilename: `regen_${oldImg.exactFilename || "state.jpg"}`,
      downloadFilename,
      exactFilename: oldImg.exactFilename,
      zipName: oldImg.zipName,
      distSlot: oldImg.distSlot,
      targetWidth,
      targetHeight,
      label: oldImg.label,
      badge: oldImg.badge,
      slotIndex: oldImg.slotIndex,
      stageKey: oldImg.stageKey,
      stagePrompt: promptToRun,
      stepNum: 3,
      hdUrl: fetchedNew.finalHdUrl,
      role: oldImg.role,
      upscaleEnabled,
      autoDownload: false
    });

    entry.images[targetImgIndex] = updatedImg;
    history[entryIndex] = entry;
    await chrome.storage.local.set({ history });

    broadcastStatus({
      state: "completed",
      step: 4,
      message: `Regenerated ${oldImg.label} (${updatedImg.width}×${updatedImg.height} JPG) in Studio Showcase!`
    });

    return { ok: true, updatedImg, entry };
  } catch (error) {
    broadcastStatus({
      state: "error",
      message: error.message || "Failed to regenerate state."
    });
    return { ok: false, error: error.message };
  }
}

/**
 * Full Automated Pipeline (routes both Zedge Multi-Wallpaper Sets and Classic Dual/Single workflows)
 */
async function generateDualWallpaperWorkflow(options = {}) {
  const {
    prompt = "",
    negativePrompt = "",
    landscapePrompt = "make it landscape mode",
    workflowMode = "set_dual",
    customStages = null,
    storyArc = "auto",
    variationStrength = "clear",
    displayTarget = "any",
    colorBoost = "off",
    aiDirectorEnabled = false,
    autoWriteMetadata = true,
    includeFoldableCompanion = false,
    referenceDataUrl = null,
    referenceFilename = "reference_image.jpg",
    forceImagePrefix = true,
    upscaleEnabled = true,
    autoDownload = false,
    useExactZedgeNames = true,
    subfolder = "Gemini_HD",
    portraitWidth = PORTRAIT_WIDTH,
    portraitHeight = PORTRAIT_HEIGHT,
    landscapeWidth = LANDSCAPE_WIDTH,
    landscapeHeight = LANDSCAPE_HEIGHT
  } = options;

  try {
    if (
      workflowMode === "set_dual" ||
      workflowMode === "set_24h" ||
      workflowMode === "set_battery"
    ) {
      return await generateWallpaperSetWorkflow({
        prompt,
        negativePrompt,
        workflowMode,
        customStages,
        storyArc,
        variationStrength,
        displayTarget,
        colorBoost,
        aiDirectorEnabled,
        autoWriteMetadata,
        includeFoldableCompanion,
        landscapePrompt,
        referenceDataUrl,
        referenceFilename,
        forceImagePrefix,
        upscaleEnabled,
        autoDownload,
        useExactZedgeNames,
        subfolder,
        portraitWidth,
        portraitHeight,
        landscapeWidth,
        landscapeHeight
      });
    }

    const session = await getGeminiSession(false);
    const safeSlug =
      (prompt || referenceFilename || "gemini_wallpaper")
        .toLowerCase()
        .replace(/\.[^.]+$/, "")
        .replace(/[^a-z0-9]+/g, "_")
        .replace(/^_+|_+$/g, "")
        .slice(0, 36) || "gemini_wallpaper";
    const timestamp = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19);
    const folderPrefix = subfolder ? `${subfolder.replace(/^\/+|\/+$/g, "")}/` : "";

    const savedOutputs = [];
    let portraitSourceBlob = null;
    let portraitSourceFilename = `${safeSlug}_${timestamp}_1_HD.jpg`;
    let portraitBaseUrls = [];

    if (workflowMode === "img2img_file" && referenceDataUrl) {
      portraitSourceBlob = dataUrlToBlob(referenceDataUrl);
      portraitSourceFilename = referenceFilename || `${safeSlug}_ref.jpg`;

      broadcastStatus({
        state: "upscaling",
        step: 1,
        message: `Step 1/4: Upscaling & preparing 9:16 Portrait (${portraitWidth}×${portraitHeight} JPG 100%)...`
      });

      const portraitItem = await upscaleResizeAndSaveBlob({
        sourceBlob: portraitSourceBlob,
        uploadFilename: portraitSourceFilename,
        downloadFilename: `${folderPrefix}${safeSlug}_${timestamp}_1_${portraitWidth}x${portraitHeight}_Portrait_HD.jpg`,
        exactFilename: `wallpaper.jpg`,
        zipName: `wallpaper.jpg`,
        distSlot: `wallpaper`,
        targetWidth: portraitWidth,
        targetHeight: portraitHeight,
        label: `Portrait ${portraitWidth}×${portraitHeight}`,
        badge: "9:16 Portrait",
        slotIndex: 1,
        stageKey: "wallpaper",
        stagePrompt: prompt,
        stepNum: 2,
        hdUrl: null,
        role: "portrait",
        upscaleEnabled,
        autoDownload
      });
      savedOutputs.push(portraitItem);
    }

    const styleSuffix = buildStyleSuffix(displayTarget, colorBoost);
    const negGuard = buildNegativeGuard(negativePrompt);

    if (workflowMode === "dual" || workflowMode === "portrait_only") {
      const styledBase = `${prompt.trim()}${styleSuffix}${negGuard}${PRO_FINISH_SUFFIX}`;
      const portraitPrompt = buildImagePrompt(styledBase, "9:16", forceImagePrefix);

      broadcastStatus({
        state: "generating",
        step: 1,
        message: `Step 1/4: Generating 9:16 Portrait image via Gemini RPC ("${portraitPrompt.slice(0, 55)}...")`
      });

      const parsedPortrait = await callGeminiStreamGenerate({
        prompt: portraitPrompt,
        session
      });

      if (!parsedPortrait.urls || parsedPortrait.urls.length === 0) {
        const hint = parsedPortrait.assistantText
          ? `Gemini replied with text instead of an image: "${parsedPortrait.assistantText.slice(0, 180)}"`
          : "No 9:16 image URL was returned by Gemini StreamGenerate.";
        throw new Error(hint);
      }

      portraitBaseUrls = parsedPortrait.urls;
      const firstPortraitUrl = parsedPortrait.urls[0];

      broadcastStatus({
        state: "downloading",
        step: 2,
        message: "Step 2/4: Fetching Gemini 9:16 (=s0) & running Cloudinary AI Upscale..."
      });

      const fetchedPortrait = await fetchGeminiHdBlob(firstPortraitUrl);
      portraitSourceBlob = fetchedPortrait.blob;
      portraitSourceFilename = `${safeSlug}_${timestamp}_1_HD.${fetchedPortrait.ext}`;

      const portraitSaved = await upscaleResizeAndSaveBlob({
        sourceBlob: portraitSourceBlob,
        uploadFilename: portraitSourceFilename,
        downloadFilename: `${folderPrefix}${safeSlug}_${timestamp}_1_${portraitWidth}x${portraitHeight}_Portrait_HD.jpg`,
        exactFilename: `wallpaper.jpg`,
        zipName: `wallpaper.jpg`,
        distSlot: `wallpaper`,
        targetWidth: portraitWidth,
        targetHeight: portraitHeight,
        label: `9:16 Portrait (${portraitWidth}×${portraitHeight})`,
        badge: "9:16 Portrait",
        slotIndex: 1,
        stageKey: "wallpaper",
        stagePrompt: portraitPrompt,
        stepNum: 2,
        hdUrl: fetchedPortrait.finalHdUrl,
        role: "portrait",
        upscaleEnabled,
        autoDownload
      });

      savedOutputs.push(portraitSaved);
    }

    if (
      workflowMode === "dual" ||
      workflowMode === "img2img_file" ||
      workflowMode === "landscape_only"
    ) {
      let parsedLandscape = null;

      if (portraitSourceBlob && (workflowMode === "dual" || workflowMode === "img2img_file")) {
        const uploadedAttachment = await uploadImageToGeminiForImg2Img(
          portraitSourceBlob,
          portraitSourceFilename,
          session,
          3
        );

        const baseFoldablePrompt = (landscapePrompt || "make it landscape mode, re-frame the exact same artwork for foldable screen without cropping the main subject").trim();
        const img2imgPrompt = `${baseFoldablePrompt}, keep the exact same subject, color palette, lighting and style${styleSuffix}${negGuard}`;

        broadcastStatus({
          state: "img2img_generating",
          step: 3,
          message: `Step 3/4: Running Gemini Image-to-Image RPC ("${img2imgPrompt}")...`
        });

        parsedLandscape = await callGeminiStreamGenerate({
          prompt: img2imgPrompt,
          session,
          attachment: uploadedAttachment,
          aspectRatioHint: "4:3",
          excludeUrls: portraitBaseUrls
        });

        if (!parsedLandscape.urls || parsedLandscape.urls.length === 0) {
          parsedLandscape = await callGeminiStreamGenerate({
            prompt: `Generate a wide landscape version of this exact image: ${img2imgPrompt} (aspect ratio 16:9)`,
            session,
            attachment: uploadedAttachment,
            aspectRatioHint: "4:3",
            excludeUrls: portraitBaseUrls
          });
        }
      } else {
        const directLandscapePrompt = buildImagePrompt(prompt, "16:9", forceImagePrefix);
        broadcastStatus({
          state: "generating",
          step: 3,
          message: `Generating Landscape image via Gemini RPC ("${directLandscapePrompt.slice(0, 55)}...")`
        });
        parsedLandscape = await callGeminiStreamGenerate({
          prompt: directLandscapePrompt,
          session
        });
      }

      if (!parsedLandscape || !parsedLandscape.urls || parsedLandscape.urls.length === 0) {
        const hint =
          parsedLandscape && parsedLandscape.assistantText
            ? `Gemini Image-to-Image replied with text: "${parsedLandscape.assistantText.slice(0, 160)}"`
            : "No Landscape image URL was returned by Gemini Image-to-Image RPC.";
        throw new Error(hint);
      }

      const firstLandscapeUrl = parsedLandscape.urls[0];

      broadcastStatus({
        state: "upscaling",
        step: 4,
        message: `Step 4/4: Fetching Landscape (=s0), AI Upscaling & preparing ${landscapeWidth}×${landscapeHeight} JPG (100%)...`
      });

      const fetchedLandscape = await fetchGeminiHdBlob(firstLandscapeUrl);
      const landscapeUploadName = `${safeSlug}_${timestamp}_1_Landscape_HD.${fetchedLandscape.ext}`;

      const landscapeSaved = await upscaleResizeAndSaveBlob({
        sourceBlob: fetchedLandscape.blob,
        uploadFilename: landscapeUploadName,
        downloadFilename: `${folderPrefix}${safeSlug}_${timestamp}_1_${landscapeWidth}x${landscapeHeight}_Wallpaper_HD.jpg`,
        exactFilename: `wallpaper-landscape.jpg`,
        zipName: `wallpaper-landscape.jpg`,
        distSlot: `wallpaper-landscape`,
        targetWidth: landscapeWidth,
        targetHeight: landscapeHeight,
        label: `Foldable (${landscapeWidth}×${landscapeHeight})`,
        badge: `Foldable (${landscapeWidth}×${landscapeHeight})`,
        slotIndex: 2,
        stageKey: "wallpaper-landscape",
        stagePrompt: landscapePrompt,
        stepNum: 4,
        hdUrl: fetchedLandscape.finalHdUrl,
        role: "landscape",
        upscaleEnabled,
        autoDownload
      });

      savedOutputs.push(landscapeSaved);
    }

    let generatedMeta = null;
    if (autoWriteMetadata && savedOutputs.length > 0) {
      try {
        broadcastStatus({
          state: "generating",
          step: 4,
          message: "Writing AI listing metadata (Title, Tags, Category, Description) via Gemini..."
        });
        generatedMeta = await generateSetMetadata({
          workflowMode: "single",
          prompt: prompt || referenceFilename,
          file: `set-01/wallpaper.jpg`,
          session
        });
      } catch (_) {}
    }

    const { history = [] } = await chrome.storage.local.get("history");
    const newEntry = {
      id: Date.now(),
      prompt: prompt || `[Image-to-Image] ${referenceFilename}`,
      landscapePrompt,
      workflowMode,
      setTypeLabel:
        workflowMode === "dual"
          ? `9:16 + Foldable Set (2 JPGs • ${portraitWidth}×${portraitHeight} + ${landscapeWidth}×${landscapeHeight})`
          : workflowMode === "portrait_only"
          ? `Single 9:16 Portrait (${portraitWidth}×${portraitHeight})`
          : workflowMode === "landscape_only"
          ? `Foldable Wallpaper (${landscapeWidth}×${landscapeHeight})`
          : `9:16 + Foldable Img2Img (${portraitWidth}×${portraitHeight} + ${landscapeWidth}×${landscapeHeight})`,
      setFolderName: `${safeSlug}_${timestamp}`,
      metadata: generatedMeta,
      createdAt: new Date().toISOString(),
      images: savedOutputs
    };
    const updatedHistory = [newEntry, ...history].slice(0, 20);
    await chrome.storage.local.set({ history: updatedHistory });

    const doneVerb = autoDownload ? "Downloaded" : "Ready in Studio Showcase";
    broadcastStatus({
      state: "completed",
      step: 4,
      message: `${doneVerb}: ${savedOutputs.map((o) => `${o.width}×${o.height} JPG`).join(" + ")}${generatedMeta ? ` + Metadata ("${generatedMeta.title}")` : ""}!`,
      results: savedOutputs
    });

    return { ok: true, results: savedOutputs, entry: newEntry };
  } catch (error) {
    broadcastStatus({
      state: "error",
      message: error.message || "Unknown error occurred during workflow."
    });
    return { ok: false, error: error.message };
  }
}

async function getOrPrepareImageBytes({
  assetId,
  filename,
  exactFilename,
  url,
  previewDataUrl,
  targetWidth = PORTRAIT_WIDTH,
  targetHeight = PORTRAIT_HEIGHT,
  upscaleEnabled = false
}) {
  if (assetId && readyJpgCache.has(assetId)) {
    const cached = readyJpgCache.get(assetId);
    const commaIdx = cached.base64DataUrl.indexOf(",");
    const base64 = cached.base64DataUrl.slice(commaIdx + 1);
    return {
      bytes: base64ToUint8Array(base64),
      base64DataUrl: cached.base64DataUrl,
      width: cached.width,
      height: cached.height,
      byteSize: cached.byteSize,
      exactFilename: exactFilename || cached.exactFilename || "wallpaper.jpg"
    };
  }

  if (url) {
    const fetched = await fetchGeminiHdBlob(url);
    const saved = await upscaleResizeAndSaveBlob({
      sourceBlob: fetched.blob,
      uploadFilename: exactFilename || "wallpaper.jpg",
      downloadFilename: filename || exactFilename || "wallpaper.jpg",
      exactFilename: exactFilename || "wallpaper.jpg",
      targetWidth,
      targetHeight,
      label: exactFilename || "Wallpaper",
      stepNum: 2,
      hdUrl: fetched.finalHdUrl,
      role: "portrait",
      upscaleEnabled,
      autoDownload: false
    });
    const cached = readyJpgCache.get(saved.assetId);
    const commaIdx = cached.base64DataUrl.indexOf(",");
    return {
      bytes: base64ToUint8Array(cached.base64DataUrl.slice(commaIdx + 1)),
      base64DataUrl: cached.base64DataUrl,
      width: saved.width,
      height: saved.height,
      byteSize: saved.byteSize,
      exactFilename: saved.exactFilename
    };
  }

  if (previewDataUrl) {
    const blob = dataUrlToBlob(previewDataUrl);
    const { jpgBlob, width, height } = await resizeImageToJpg100(blob, targetWidth, targetHeight);
    const buf = await jpgBlob.arrayBuffer();
    const b64 = `data:image/jpeg;base64,${arrayBufferToBase64(buf)}`;
    return {
      bytes: new Uint8Array(buf),
      base64DataUrl: b64,
      width,
      height,
      byteSize: buf.byteLength,
      exactFilename: exactFilename || "wallpaper.jpg"
    };
  }

  throw new Error("Image cache expired and no remote URL available to re-fetch.");
}

// ============================================================================
// READY FILES FOLDER ZIP + METADATA.JSON + PROMPTS/ BUILDER (from batch_screen.dart)
// ============================================================================

const CRC32_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) {
      c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
    }
    table[i] = c >>> 0;
  }
  return table;
})();

function crc32(bytes) {
  let crc = 0xffffffff;
  for (let i = 0; i < bytes.length; i++) {
    crc = CRC32_TABLE[(crc ^ bytes[i]) & 0xff] ^ (crc >>> 8);
  }
  return (crc ^ 0xffffffff) >>> 0;
}

function buildStoreZipBuffer(files) {
  const encoder = new TextEncoder();
  const localParts = [];
  const centralParts = [];
  let offset = 0;

  for (const file of files) {
    const nameBytes = encoder.encode(file.name);
    const data = file.bytes;
    const crc = crc32(data);

    const localHeader = new Uint8Array(30 + nameBytes.length);
    const lv = new DataView(localHeader.buffer);
    lv.setUint32(0, 0x04034b50, true);
    lv.setUint16(4, 20, true);
    lv.setUint16(6, 0x0800, true);
    lv.setUint16(8, 0, true);
    lv.setUint16(10, 0, true);
    lv.setUint16(12, 0x5621, true);
    lv.setUint32(14, crc, true);
    lv.setUint32(18, data.length, true);
    lv.setUint32(22, data.length, true);
    lv.setUint16(26, nameBytes.length, true);
    lv.setUint16(28, 0, true);
    localHeader.set(nameBytes, 30);

    const centralHeader = new Uint8Array(46 + nameBytes.length);
    const cv = new DataView(centralHeader.buffer);
    cv.setUint32(0, 0x02014b50, true);
    cv.setUint16(4, 20, true);
    cv.setUint16(6, 20, true);
    cv.setUint16(8, 0x0800, true);
    cv.setUint16(10, 0, true);
    cv.setUint16(12, 0, true);
    cv.setUint16(14, 0x5621, true);
    cv.setUint32(16, crc, true);
    cv.setUint32(20, data.length, true);
    cv.setUint32(24, data.length, true);
    cv.setUint16(28, nameBytes.length, true);
    cv.setUint16(30, 0, true);
    cv.setUint16(32, 0, true);
    cv.setUint16(34, 0, true);
    cv.setUint16(36, 0, true);
    cv.setUint32(38, 0, true);
    cv.setUint32(42, offset, true);
    centralHeader.set(nameBytes, 46);

    localParts.push(localHeader, data);
    centralParts.push(centralHeader);
    offset += localHeader.length + data.length;
  }

  const centralSize = centralParts.reduce((acc, p) => acc + p.length, 0);
  const eocd = new Uint8Array(22);
  const ev = new DataView(eocd.buffer);
  ev.setUint32(0, 0x06054b50, true);
  ev.setUint16(4, 0, true);
  ev.setUint16(6, 0, true);
  ev.setUint16(8, files.length, true);
  ev.setUint16(10, files.length, true);
  ev.setUint32(12, centralSize, true);
  ev.setUint32(16, offset, true);
  ev.setUint16(20, 0, true);

  const totalSize = offset + centralSize + eocd.length;
  const out = new Uint8Array(totalSize);
  let pos = 0;
  for (const part of localParts) {
    out.set(part, pos);
    pos += part.length;
  }
  for (const part of centralParts) {
    out.set(part, pos);
    pos += part.length;
  }
  out.set(eocd, pos);
  return out.buffer;
}

/**
 * Packs one or multiple Set entries into a Ready Studio ZIP archive containing:
 * - set-01/<slot>.jpg (or exact WP_Battery_*.jpg when useExactZedgeNames is true)
 * - metadata.json at the archive root (exact schema from GeminiApi.metadataJson)
 * - prompts/set-01-wallpaper.txt (reusable generation prompts)
 */
async function downloadReadySetsZip({
  entries = [],
  zipFilename = null,
  subfolder = "Gemini_HD",
  useHubSetFolders = true,
  upscaleEnabled = false
}) {
  if (!entries || entries.length === 0) {
    throw new Error("No sets available to package into Ready ZIP.");
  }

  const encoder = new TextEncoder();
  const zipFiles = [];
  const metadataArray = [];

  for (let sIdx = 0; sIdx < entries.length; sIdx++) {
    const entry = entries[sIdx];
    const setNum = String(sIdx + 1).padStart(2, "0");
    const setFolder = `set-${setNum}`;
    const images = entry.images || [];
    let firstZipPath = `${setFolder}/image.jpg`;

    for (let i = 0; i < images.length; i++) {
      const img = images[i];
      const hubName = img.zipName || img.exactFilename || `frame-${i + 1}.jpg`;
      const zedgeName = img.exactFilename || hubName;
      const entryPath = useHubSetFolders
        ? `${setFolder}/${hubName}`
        : entries.length > 1
        ? `${setFolder}/${zedgeName}`
        : zedgeName;

      if (i === 0) firstZipPath = entryPath;

      broadcastStatus({
        state: "downloading",
        step: 4,
        message: `Packing Ready ZIP [Set ${sIdx + 1}/${entries.length} • File ${i + 1}/${images.length}]: ${entryPath}...`
      });

      const prepared = await getOrPrepareImageBytes({
        assetId: img.assetId,
        filename: img.filename,
        exactFilename: zedgeName,
        url: img.hdUrl,
        previewDataUrl: img.previewDataUrl,
        targetWidth: img.width || PORTRAIT_WIDTH,
        targetHeight: img.height || PORTRAIT_HEIGHT,
        upscaleEnabled
      });

      zipFiles.push({
        name: entryPath,
        bytes: prepared.bytes
      });
    }

    // Add entry to root metadata.json
    const m = entry.metadata;
    const tagsArr = m && Array.isArray(m.tags) ? m.tags : [];
    metadataArray.push({
      file: firstZipPath,
      title: m && m.title ? m.title : "",
      tags: tagsArr,
      keywords: tagsArr.join(", "),
      category: m && m.category ? m.category : "",
      description: m && m.description ? m.description : ""
    });

    // Add prompts/set-XX-wallpaper.txt
    const promptLines = [
      `Set #${setNum} (${entry.setTypeLabel || entry.workflowMode || "Wallpaper Set"})`,
      `Core Prompt: ${entry.prompt || ""}`,
      ""
    ];
    images.forEach((img, idx) => {
      promptLines.push(`[${idx + 1}] ${img.exactFilename || img.label}:`);
      promptLines.push(img.stagePrompt || entry.prompt || "");
      promptLines.push("");
    });
    zipFiles.push({
      name: `prompts/set-${setNum}-wallpaper.txt`,
      bytes: encoder.encode(promptLines.join("\n"))
    });
  }

  // Write metadata.json at the root of the ZIP archive
  const metadataJsonStr = JSON.stringify(metadataArray, null, 2);
  zipFiles.push({
    name: "metadata.json",
    bytes: encoder.encode(metadataJsonStr)
  });

  const zipBuffer = buildStoreZipBuffer(zipFiles);
  const zipDataUrl = `data:application/zip;base64,${arrayBufferToBase64(zipBuffer)}`;
  const folderPrefix = subfolder ? `${subfolder.replace(/^\/+|\/+$/g, "")}/` : "";
  const defaultZipName =
    entries.length === 1
      ? `ready-${(entries[0].setFolderName || `set-${Date.now()}`).slice(0, 40)}.zip`
      : `ai-studio-sets-${Date.now()}.zip`;
  const cleanZipName = (zipFilename || defaultZipName).replace(/^\/+/, "");
  const finalZipPath = `${folderPrefix}${cleanZipName}`;

  const downloadId = await chrome.downloads.download({
    url: zipDataUrl,
    filename: finalZipPath,
    saveAs: false
  });

  broadcastStatus({
    state: "completed",
    step: 4,
    message: `Downloaded Ready ZIP (${finalZipPath}) with ${entries.length} set(s) + metadata.json!`
  });

  return {
    downloadId,
    filename: finalZipPath,
    byteSize: zipBuffer.byteLength,
    setCount: entries.length
  };
}

/**
 * Downloads standalone metadata.json file for one or all sets.
 */
async function downloadStandaloneMetadataJson({
  entries = [],
  subfolder = "Gemini_HD",
  filename = "metadata.json"
}) {
  const metadataArray = entries.map((entry, idx) => {
    const setNum = String(idx + 1).padStart(2, "0");
    const firstImg = (entry.images && entry.images[0]) || {};
    const firstPath = `set-${setNum}/${firstImg.zipName || firstImg.exactFilename || "image.jpg"}`;
    const m = entry.metadata || {};
    const tags = Array.isArray(m.tags) ? m.tags : [];
    return {
      file: firstPath,
      title: m.title || "",
      tags,
      keywords: tags.join(", "),
      category: m.category || "",
      description: m.description || ""
    };
  });

  const jsonStr = JSON.stringify(metadataArray, null, 2);
  const encoder = new TextEncoder();
  const b64 = arrayBufferToBase64(encoder.encode(jsonStr).buffer);
  const dataUrl = `data:application/json;base64,${b64}`;
  const folderPrefix = subfolder ? `${subfolder.replace(/^\/+|\/+$/g, "")}/` : "";
  const finalPath = `${folderPrefix}${filename.replace(/^\/+/, "")}`;

  const downloadId = await chrome.downloads.download({
    url: dataUrl,
    filename: finalPath,
    saveAs: false
  });

  broadcastStatus({
    state: "completed",
    step: 4,
    message: `Downloaded ${finalPath} (${metadataArray.length} set record(s))!`
  });

  return { downloadId, filename: finalPath };
}

// ============================================================================
// DIRECT UPLOAD SET TO PANEL (Ported 1:1 from lib/distribute.dart)
// Cloudflare R2 Worker Upload + Firebase Realtime Database Queue Push
// ============================================================================

function normalizeUrl(url) {
  return String(url || "").trim().replace(/\/+$/, "");
}

function getR2FolderForAccountName(name) {
  let f = String(name || "")
    .replace(/^zedge_?/i, "zedge")
    .replace(/[^a-zA-Z0-9_-]/g, "");
  return f || "studio";
}

function resolveDistSlot(workflowMode, img, index) {
  if (img.distSlot) return img.distSlot;
  const label = String(img.label || img.stageKey || img.exactFilename || "").toLowerCase();
  if (workflowMode === "set_battery") {
    const slots = ["critical", "low", "mid", "high", "full", "charging"];
    if (slots.includes(label)) return label;
    return slots[index] || `frame${index + 1}`;
  }
  if (workflowMode === "set_24h") {
    for (const s of ["morning", "afternoon", "evening", "night"]) {
      if (label.includes(s)) return s;
    }
    return ["morning", "afternoon", "evening", "night"][index] || `frame${index + 1}`;
  }
  if (workflowMode === "set_dual") {
    if (label.includes("lock")) return "lock";
    if (label.includes("home")) return "home";
    return index === 0 ? "lock" : "home";
  }
  if (label.includes("landscape")) return "wallpaper-landscape";
  return index === 0 ? "wallpaper" : `frame${index + 1}`;
}

function resolveDistContentType(workflowMode) {
  if (workflowMode === "set_24h") return "WALLPAPER_24H";
  if (workflowMode === "set_dual") return "WALLPAPER_DUAL";
  if (workflowMode === "set_battery") return "WALLPAPER_BATTERY";
  return "WALLPAPER";
}

async function uploadFileToR2Worker({ bytes, fileName, mime, workerUrl, folder }) {
  const cleaned = fileName.replace(/[^a-zA-Z0-9._-]/g, "_");
  const cleanFolder = folder.replace(/^\/+|\/+$/g, "");
  const key = `${cleanFolder}/wallpaper/${Date.now()}_${cleaned}`;

  const resp = await fetch(normalizeUrl(workerUrl), {
    method: "POST",
    headers: {
      "X-File-Name": key,
      "X-File-Type": mime || "image/jpeg"
    },
    body: bytes
  });

  if (!resp.ok) {
    const text = await resp.text().catch(() => "");
    throw new Error(`R2 upload failed (HTTP ${resp.status}): ${text.slice(0, 180)}`);
  }

  const data = await resp.json();
  const url = data && data.url ? String(data.url) : "";
  if (!url) {
    throw new Error("R2 worker response missing the url field.");
  }
  const folderSeg = `/${cleanFolder}/wallpaper/`;
  if (!url.includes(folderSeg)) {
    throw new Error(`R2 returned a URL outside ${cleanFolder}/wallpaper (${url}).`);
  }
  return url;
}

async function pushRecordToFirebase({ dbUrl, queuePath, record, secret }) {
  const authQuery =
    secret && String(secret).trim()
      ? `?auth=${encodeURIComponent(String(secret).trim())}`
      : "";
  const url = `${normalizeUrl(dbUrl)}/${String(queuePath || "wallpaperQueue").trim()}.json${authQuery}`;

  const resp = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(record)
  });

  if (!resp.ok) {
    const text = await resp.text().catch(() => "");
    throw new Error(`Database push failed (HTTP ${resp.status}): ${text.slice(0, 180)}`);
  }

  const data = await resp.json();
  const key = data && data.name ? String(data.name) : "";
  if (!key) {
    throw new Error("Database push returned no Firebase key.");
  }
  return key;
}

async function testPanelDatabaseConnection({ dbUrl, secret }) {
  const authParam =
    secret && String(secret).trim()
      ? `&auth=${encodeURIComponent(String(secret).trim())}`
      : "";
  const url = `${normalizeUrl(dbUrl)}/.json?shallow=true${authParam}`;
  const resp = await fetch(url, { method: "GET" });
  if (resp.status === 401 || resp.status === 403) {
    throw new Error(`Database refused access (HTTP ${resp.status}). Check URL and secret.`);
  }
  if (!resp.ok) {
    throw new Error(`Database test failed (HTTP ${resp.status}).`);
  }
  return { ok: true, message: "Database reachable (read-only shallow test passed)." };
}

/**
 * Uploads a finished Set from the Studio Showcase directly to the user's Panel
 * (Cloudflare R2 + Firebase Realtime Database Queue), mirroring `_uploadSet` in batch_screen.dart.
 */
async function uploadSetToPanel({ entryId, targetAccount = "spread" }) {
  try {
    const { history = [], distConfig = null, distSpreadCursor = 0 } =
      await chrome.storage.local.get(["history", "distConfig", "distSpreadCursor"]);

    if (
      !distConfig ||
      !distConfig.r2WorkerUrl ||
      !Array.isArray(distConfig.accounts) ||
      distConfig.accounts.length === 0
    ) {
      throw new Error(
        "Panel Distribution is not configured yet. Click 'Panel Upload Settings' in the top bar to add your R2 Worker URL and Firebase Database account(s)."
      );
    }

    const entryIndex = history.findIndex((h) => h.id === entryId);
    if (entryIndex === -1) {
      throw new Error("Set entry not found in Studio Showcase.");
    }
    const entry = history[entryIndex];
    const images = entry.images || [];
    if (images.length === 0) {
      throw new Error("Set has no images to upload.");
    }

    // Resolve target account ('spread' round-robin or specific account name)
    let account = null;
    const effectiveTarget = targetAccount || distConfig.defaultTarget || "spread";
    if (effectiveTarget !== "spread") {
      account = distConfig.accounts.find((a) => a.name === effectiveTarget) || null;
    }
    if (!account) {
      const poolNames =
        Array.isArray(distConfig.spreadPool) && distConfig.spreadPool.length > 0
          ? distConfig.spreadPool
          : distConfig.accounts.map((a) => a.name);
      const pool = distConfig.accounts.filter((a) => poolNames.includes(a.name));
      const activePool = pool.length > 0 ? pool : distConfig.accounts;
      account = activePool[distSpreadCursor % activePool.length];
      await chrome.storage.local.set({ distSpreadCursor: distSpreadCursor + 1 });
    }

    // Ensure AI Metadata exists before pushing to the panel; if missing, auto-generate it now!
    if (!entry.metadata || !entry.metadata.title) {
      try {
        broadcastStatus({
          state: "generating",
          step: 3,
          message: `Generating AI Metadata before uploading to ${account.name}...`
        });
        const session = await getGeminiSession(false);
        const firstZip = `set-01/${images[0].zipName || images[0].exactFilename || "wallpaper.jpg"}`;
        entry.metadata = await generateSetMetadata({
          workflowMode: entry.workflowMode || "set_24h",
          prompt: entry.prompt,
          file: firstZip,
          session
        });
      } catch (_) {}
    }

    const r2Folder = getR2FolderForAccountName(account.name);
    const meta = entry.metadata || {};
    const baseSlug = String(meta.title || entry.prompt.split(/[,.]/)[0] || "wallpaper_set")
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 32) || "set";

    const filesMap = {};
    let totalSize = 0;
    let firstUrl = "";
    let firstName = "";
    let firstSize = 0;
    let firstW = PORTRAIT_WIDTH;
    let firstH = PORTRAIT_HEIGHT;

    for (let i = 0; i < images.length; i++) {
      const img = images[i];
      const slot = resolveDistSlot(entry.workflowMode, img, i);
      const fileName = `${baseSlug}_${slot}.jpg`;

      broadcastStatus({
        state: "downloading",
        step: 3,
        message: `Uploading to Panel (${account.name}) [${i + 1}/${images.length}]: ${fileName} -> R2 (${r2Folder})...`
      });

      const prepared = await getOrPrepareImageBytes({
        assetId: img.assetId,
        filename: img.filename,
        exactFilename: img.exactFilename,
        url: img.hdUrl,
        previewDataUrl: img.previewDataUrl,
        targetWidth: img.width || PORTRAIT_WIDTH,
        targetHeight: img.height || PORTRAIT_HEIGHT,
        upscaleEnabled: false
      });

      const fileSha256 = await sha256Hex(prepared.bytes);
      const r2Url = await uploadFileToR2Worker({
        bytes: prepared.bytes,
        fileName,
        mime: "image/jpeg",
        workerUrl: distConfig.r2WorkerUrl,
        folder: r2Folder
      });

      filesMap[slot] = {
        fileUrl: r2Url,
        name: fileName,
        size: prepared.bytes.length,
        type: "image/jpeg",
        width: prepared.width,
        height: prepared.height,
        sha256: fileSha256
      };

      totalSize += prepared.bytes.length;
      if (i === 0) {
        firstUrl = r2Url;
        firstName = fileName;
        firstSize = prepared.bytes.length;
        firstW = prepared.width;
        firstH = prepared.height;
      }
    }

    broadcastStatus({
      state: "downloading",
      step: 4,
      message: `Pushing set record + metadata to ${account.name} Firebase Queue (${distConfig.queuePath || "wallpaperQueue"})...`
    });

    const now = Date.now();
    const isSingle = images.length === 1;
    const record = {
      name: firstName,
      type: "image/jpeg",
      size: isSingle ? firstSize : totalSize,
      width: firstW,
      height: firstH,
      isMp3: false,
      isImage: true,
      contentType: resolveDistContentType(entry.workflowMode),
      fileUrl: firstUrl,
      status: "queued",
      prompt: entry.prompt,
      imageModel: "gemini-hd-studio",
      source: "ai-image-studio-flutter",
      createdAt: now
    };

    if (!isSingle) {
      record.files = filesMap;
      record.setName = meta.title || baseSlug;
    }

    if (meta && (meta.title || (meta.tags && meta.tags.length > 0) || meta.category || meta.description)) {
      const tagsList = Array.isArray(meta.tags) ? meta.tags : [];
      record.title = meta.title || "";
      record.tags = tagsList.join(", ");
      record.tagsList = tagsList;
      record.category = meta.category || "DESIGNS";
      record.description = meta.description || "";
      record.metadataGeneratedAt = now;
      record.policyCheck = "passed";
      record.policyCheckedAt = now;
    }

    const firebaseKey = await pushRecordToFirebase({
      dbUrl: account.dbUrl,
      queuePath: distConfig.queuePath || "wallpaperQueue",
      record,
      secret: account.secret
    });

    entry.uploadedToPanel = {
      accountName: account.name,
      firebaseKey,
      uploadedAt: now
    };
    history[entryIndex] = entry;
    await chrome.storage.local.set({ history });

    broadcastStatus({
      state: "completed",
      step: 4,
      message: `Uploaded set "${meta.title || baseSlug}" to ${account.name} Panel! Queue Key: ${firebaseKey}`
    });

    return {
      ok: true,
      accountName: account.name,
      firebaseKey,
      entry
    };
  } catch (error) {
    broadcastStatus({
      state: "error",
      message: error.message || "Panel upload failed."
    });
    return { ok: false, error: error.message };
  }
}

async function downloadPreparedOrHistoryImage({
  assetId,
  filename,
  exactFilename,
  setFolderName,
  useExactZedgeNames = true,
  url,
  previewDataUrl,
  prompt = "gemini_wallpaper",
  subfolder = "Gemini_HD",
  targetWidth = PORTRAIT_WIDTH,
  targetHeight = PORTRAIT_HEIGHT,
  upscaleEnabled = true
}) {
  const folderPrefix = subfolder ? `${subfolder.replace(/^\/+|\/+$/g, "")}/` : "";
  const subSetPrefix = setFolderName ? `${setFolderName.replace(/^\/+|\/+$/g, "")}/` : "";

  if (assetId && readyJpgCache.has(assetId)) {
    const cached = readyJpgCache.get(assetId);
    const baseName =
      useExactZedgeNames && (exactFilename || cached.exactFilename)
        ? exactFilename || cached.exactFilename
        : (filename || cached.filename || "wallpaper_HD.jpg").split("/").pop();
    const finalPath = `${folderPrefix}${subSetPrefix}${baseName}`;

    const downloadId = await chrome.downloads.download({
      url: cached.base64DataUrl,
      filename: finalPath,
      saveAs: false
    });

    return {
      downloadId,
      filename: finalPath,
      width: cached.width,
      height: cached.height,
      byteSize: cached.byteSize,
      fromCache: true
    };
  }

  const prepared = await getOrPrepareImageBytes({
    assetId,
    filename,
    exactFilename,
    url,
    previewDataUrl,
    targetWidth,
    targetHeight,
    upscaleEnabled
  });

  const baseName =
    useExactZedgeNames && exactFilename
      ? exactFilename
      : (filename || exactFilename || `${prompt.slice(0, 24)}_HD.jpg`).split("/").pop();
  const finalPath = `${folderPrefix}${subSetPrefix}${baseName}`;

  const downloadId = await chrome.downloads.download({
    url: prepared.base64DataUrl,
    filename: finalPath,
    saveAs: false
  });

  broadcastStatus({
    state: "completed",
    step: 4,
    message: `Downloaded ${prepared.width}×${prepared.height} JPG (${finalPath})!`
  });

  return {
    downloadId,
    filename: finalPath,
    width: prepared.width,
    height: prepared.height,
    byteSize: prepared.byteSize
  };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (
    message.type === "GENERATE_DUAL_WALLPAPER" ||
    message.type === "GENERATE_WALLPAPER_SET" ||
    message.type === "GENERATE_IMAGE"
  ) {
    generateDualWallpaperWorkflow(message.options || {}).then(sendResponse);
    return true;
  }

  if (message.type === "IMPORT_LOCAL_SET_TO_STUDIO") {
    importLocalSetToStudio(message.options || {}).then(sendResponse);
    return true;
  }

  if (message.type === "GENERATE_SET_METADATA") {
    generateOrUpdateHistoryMetadata(message.options || {}).then(sendResponse);
    return true;
  }

  if (message.type === "REGENERATE_SET_STAGE") {
    regenerateSingleSetStage(message.options || {}).then(sendResponse);
    return true;
  }

  if (message.type === "DOWNLOAD_SET_ZIP" || message.type === "DOWNLOAD_READY_ZIP") {
    downloadReadySetsZip(message.options || {})
      .then((res) => sendResponse({ ok: true, result: res }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "DOWNLOAD_METADATA_JSON") {
    downloadStandaloneMetadataJson(message.options || {})
      .then((res) => sendResponse({ ok: true, result: res }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "UPLOAD_SET_TO_PANEL") {
    uploadSetToPanel(message.options || {}).then(sendResponse);
    return true;
  }

  if (message.type === "TEST_PANEL_DB") {
    testPanelDatabaseConnection(message.options || {})
      .then((res) => sendResponse(res))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "CHECK_SESSION") {
    getGeminiSession(Boolean(message.force), message.authUser)
      .then((session) =>
        sendResponse({
          ok: true,
          bl: session.bl,
          authUser: session.authUser,
          email: session.email
        })
      )
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "SCAN_GEMINI_ACCOUNTS") {
    scanAvailableGeminiAccounts()
      .then((accounts) => sendResponse({ ok: true, accounts }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }

  if (message.type === "SWITCH_GEMINI_ACCOUNT") {
    const mode = message.accountMode || "auto";
    chrome.storage.local.set({ geminiAccountMode: mode }).then(async () => {
      try {
        const targetIdx = mode === "auto" ? activeAuthUserIndex : parseInt(mode, 10) || 0;
        const session = await getGeminiSession(true, targetIdx);
        sendResponse({
          ok: true,
          accountMode: mode,
          authUser: session.authUser,
          email: session.email,
          bl: session.bl
        });
      } catch (err) {
        sendResponse({ ok: false, error: err.message });
      }
    });
    return true;
  }

  if (message.type === "DOWNLOAD_PREPARED_IMAGE" || message.type === "DOWNLOAD_DIRECT_HD") {
    downloadPreparedOrHistoryImage(message)
      .then((res) => sendResponse({ ok: true, result: res }))
      .catch((err) => sendResponse({ ok: false, error: err.message }));
    return true;
  }
});
