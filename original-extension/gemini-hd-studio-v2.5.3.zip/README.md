# Gemini HD Studio v2.5.2 — removed summary + presets

Removed the set-summary banner (mode badge / spec pill / description / file chips) and the theme-presets group entirely — HTML blocks deleted and the JS that populated them removed, so nothing can reappear at runtime. Nothing else changed from v2.5.1.

# Gemini HD Studio v2.5.1 — minimal clean UI

UI-only redesign on top of v2.5.0. No generation, upscale, metadata or upload logic changed.

- Slim header: short name, no subtitle keyword list, account controls as quiet ghost buttons.
- Set Designer: 4 modes as one segmented row (one line each), quiet sub-mode links, one-line set summary.
- Prompt first. Negative prompt, style/story, stage matrix and output sizes live under one collapsed "Advanced settings" section — all defaults still apply while it is closed.
- Short generate labels, slim stepper, flat panels, no heavy shadows, no coloured badge piles.
- Showcase: short title, ghost toolbar (only Ready ZIP is solid), quiet group/card/metadata styling.
- Zero emoji anywhere (last ⚡ in the account switcher removed).

# Gemini HD Studio: Wallpaper Set Designer, AI Metadata & Panel Uploader (v2.5.0)

Full-tab Chrome/Brave extension combining **Headless Gemini Image-to-Image RPCs**, **Cloudinary (`e_upscale`) AI Super-Resolution**, and the complete **AI Image Studio / Generator Hub** workflow:

1. **Zedge & Hub Multi-Wallpaper Set Modes (`1620×2880` JPG, `<=8 MB`, `<25 MP`)**:
   - **Dual Wallpaper Set (`2× JPEG`)**: `set-01/lock.jpg` (`WP_Dual_1_LockScreen.jpg`) + `set-01/home.jpg` (`WP_Dual_2_HomeScreen.jpg`).
   - **24-Hour Dynamic Set (`4× JPEG`)**: `set-01/morning.jpg`, `afternoon.jpg`, `evening.jpg`, `night.jpg` (`WP_24Hour_1_Morning.jpg` .. `4_Night.jpg`).
   - **Battery Level Set (`6× JPEG`)**: `set-01/0.jpg`..`100.jpg` / `critical`..`charging` (`WP_Battery_Level1_Critical.jpg` .. `WP_Battery_Charging.jpg`).
2. **Story Arcs, AI Set Director & Display/Color Tuning**:
   - **24-Hour Story Arcs**: `Auto (Smart Keyword Pick)`, `Light Only (Kelvin & Sun Elevation)`, `Bloom Cycle`, `Daily Rhythm`.
   - **Battery Story Arcs**: `Auto (Smart Keyword Pick)`, `Energy Glow (5%→100% Luminance Ladder)`, `Growth`, `Awakening`.
   - **Variation Strength**: `Subtle`, `Clear`, `Strong` + **Display Target** (`Any`, `AMOLED`, `IPS`) + **Color Boost** (`Off`, `Subtle`, `Vivid`, `Neon`).
   - **AI Set Director**: Optional pre-generation planning call where Gemini designs the set's story arc, neutral anchor, color palette, and quantitative stage directions.
3. **AI Listing Metadata Generator (`metadata.json`)**:
   - Uses your active Gemini Web session to generate validated Zedge/Hub listing metadata for every set:
     - `title` (max 30 chars, Title Case)
     - `tags` (8–12 single lowercase words) + `keywords` (clean comma-separated CSV ready to paste into Search Tags)
     - `category` (validated against the 20 official Zedge categories)
     - `description` (1–2 natural sentences, max 200 chars)
   - Includes 1-click **Copy Title**, **Copy Tags CSV**, **Inline Metadata Editor**, **Rewrite with AI**, and standalone **`metadata.json`** download.
4. **Ready Files Folder `.ZIP` + `metadata.json` + `prompts/` Packaging**:
   - **Ready `.ZIP + JSON`** packs every set into `set-01/<variant>.jpg`, `set-02/<variant>.jpg` (or exact `WP_Battery_*.jpg`), writes `prompts/set-01-wallpaper.txt`, and places a formatted `metadata.json` at the root of the ZIP archive.
5. **Direct Upload Set to Panel (Cloudflare R2 Worker + Firebase Realtime Database Queue) & Local Set Import**:
   - Configure your **R2 Worker URL**, **Queue Path (`wallpaperQueue`)**, and multiple **Firebase Database Accounts (`zedge_1`, `zedge_2`, ...)** in **Panel Upload Settings**.
   - Click **Upload to Panel** on any set (or **Upload All to Panel**) to upload each frame to `<r2Folder>/wallpaper/<timestamp>_<slug>_<slot>.jpg` with SHA-256 verification and push the complete record + metadata to your Firebase queue (supporting **Spread** auto-rotation or specific account targets).
   - Click **Import Local Set** in the top bar to drop existing images from your PC directly into the Studio Panel for `1620×2880` formatting, AI Metadata generation, Ready `.ZIP` export, or direct Panel Upload.
