const workflowModeSelect = document.getElementById("workflowMode");
const modeTabs = document.querySelectorAll(".mode-tab");
const subModePills = document.querySelectorAll(".sub-mode-pill");
const promptInput = document.getElementById("promptInput");
const promptLabel = document.getElementById("promptLabel");
const negativePromptInput = document.getElementById("negativePromptInput");
const resetNegativePromptBtn = document.getElementById("resetNegativePromptBtn");
const negChipBtns = document.querySelectorAll(".neg-chip-btn[data-neg]");
const landscapePromptGroup = document.getElementById("landscapePromptGroup");
const landscapePromptInput = document.getElementById("landscapePromptInput");
const foldSizeBtns = document.querySelectorAll(".fold-size-btn");
const batchModeCheckbox = document.getElementById("batchMode");
const includeFoldableCompanionCheckbox = document.getElementById("includeFoldableCompanion");
const foldableCompanionToggleWrap = document.getElementById("foldableCompanionToggleWrap");

const DEFAULT_NEGATIVE_PROMPT =
  "no text, no letters, no numbers, no percentage signs, no battery icons, no UI widgets, no clock, no watermark, no signature, no logo, no blurry details, no deformed anatomy";


const arcAndStyleBox = document.getElementById("arcAndStyleBox");
const arcStyleGrid = document.getElementById("arcStyleGrid");
const storyArcField = document.getElementById("storyArcField");
const storyArcSelect = document.getElementById("storyArcSelect");
const variationStrengthSelect = document.getElementById("variationStrengthSelect");
const displayTargetSelect = document.getElementById("displayTargetSelect");
const colorBoostSelect = document.getElementById("colorBoostSelect");


const stageMatrixBox = document.getElementById("stageMatrixBox");
const stageMatrixTitle = document.getElementById("stageMatrixTitle");
const stagePillsPreview = document.getElementById("stagePillsPreview");
const stageEditorsList = document.getElementById("stageEditorsList");
const toggleStageMatrixBtn = document.getElementById("toggleStageMatrixBtn");
const resetStagePromptsBtn = document.getElementById("resetStagePromptsBtn");

const dropzone = document.getElementById("dropzone");
const refFileInput = document.getElementById("refFileInput");
const dropzoneEmpty = document.getElementById("dropzoneEmpty");
const dropzonePreview = document.getElementById("dropzonePreview");
const refPreviewImg = document.getElementById("refPreviewImg");
const refFileName = document.getElementById("refFileName");
const clearRefBtn = document.getElementById("clearRefBtn");

const upscaleEnabledCheckbox = document.getElementById("upscaleEnabled");
const resGridContainer = document.getElementById("resGridContainer");
const portraitWidthInput = document.getElementById("portraitWidth");
const portraitHeightInput = document.getElementById("portraitHeight");
const landscapeResBox = document.getElementById("landscapeResBox");
const landscapeWidthInput = document.getElementById("landscapeWidth");
const landscapeHeightInput = document.getElementById("landscapeHeight");
const specStatusBadge = document.getElementById("specStatusBadge");
const subfolderInput = document.getElementById("subfolderInput");
const autoWriteMetadataCheckbox = document.getElementById("autoWriteMetadata");
const aiDirectorEnabledCheckbox = document.getElementById("aiDirectorEnabled");
const useHubSetFoldersCheckbox = document.getElementById("useHubSetFolders");
const useExactZedgeNamesCheckbox = document.getElementById("useExactZedgeNames");
const forceImagePrefixCheckbox = document.getElementById("forceImagePrefix");
const autoDownloadCheckbox = document.getElementById("autoDownloadEnabled");

const generateBtn = document.getElementById("generateBtn");
const checkSessionBtn = document.getElementById("checkSessionBtn");
const sessionIndicator = document.getElementById("sessionIndicator");
const geminiAccountSelect = document.getElementById("geminiAccountSelect");
const scanGeminiAccountsBtn = document.getElementById("scanGeminiAccountsBtn");
const addGeminiAccountBtn = document.getElementById("addGeminiAccountBtn");
const statusBox = document.getElementById("statusBox");
const statusSpinner = document.getElementById("statusSpinner");
const statusText = document.getElementById("statusText");
const gallery = document.getElementById("gallery");
const clearHistoryBtn = document.getElementById("clearHistoryBtn");
const stepItems = document.querySelectorAll(".step-item");
const stepLabel1 = document.getElementById("stepLabel1");
const stepLabel2 = document.getElementById("stepLabel2");
const stepLabel3 = document.getElementById("stepLabel3");
const stepLabel4 = document.getElementById("stepLabel4");

// Batch Results Toolbar Buttons
const writeAllMetadataBtn = document.getElementById("writeAllMetadataBtn");
const downloadAllReadyZipBtn = document.getElementById("downloadAllReadyZipBtn");
const downloadAllMetaJsonBtn = document.getElementById("downloadAllMetaJsonBtn");
const uploadAllToPanelBtn = document.getElementById("uploadAllToPanelBtn");

// Lightbox Modal Elements
const lightboxModal = document.getElementById("lightboxModal");
const lightboxBackdrop = document.getElementById("lightboxBackdrop");
const lightboxCloseBtn = document.getElementById("lightboxCloseBtn");
const lightboxImg = document.getElementById("lightboxImg");
const lightboxBadge = document.getElementById("lightboxBadge");
const lightboxTitle = document.getElementById("lightboxTitle");
const lightboxMeta = document.getElementById("lightboxMeta");
const lightboxDownloadBtn = document.getElementById("lightboxDownloadBtn");

// Phone Transition Simulator Modal Elements
const simulatorModal = document.getElementById("simulatorModal");
const simulatorBackdrop = document.getElementById("simulatorBackdrop");
const simCloseBtn = document.getElementById("simCloseBtn");
const simModeBadge = document.getElementById("simModeBadge");
const simTitle = document.getElementById("simTitle");
const simShowOverlay = document.getElementById("simShowOverlay");
const simShowFocalCrosshair = document.getElementById("simShowFocalCrosshair");
const simAutoPlayBtn = document.getElementById("simAutoPlayBtn");
const simMainImg = document.getElementById("simMainImg");
const simPhoneOverlay = document.getElementById("simPhoneOverlay");
const simStatusTime = document.getElementById("simStatusTime");
const simStatusRight = document.getElementById("simStatusRight");
const simClockWidget = document.getElementById("simClockWidget");
const simBigClock = document.getElementById("simBigClock");
const simSubLabel = document.getElementById("simSubLabel");
const simCenterGuide = document.getElementById("simCenterGuide");
const simHomeIcons = document.getElementById("simHomeIcons");
const simActiveStateBadge = document.getElementById("simActiveStateBadge");
const simActiveFilename = document.getElementById("simActiveFilename");
const simActiveSpecs = document.getElementById("simActiveSpecs");
const simStateButtons = document.getElementById("simStateButtons");

// Distribution / Panel Upload Settings Modal Elements
const openDistSettingsBtn = document.getElementById("openDistSettingsBtn");
const distSettingsModal = document.getElementById("distSettingsModal");
const distSettingsBackdrop = document.getElementById("distSettingsBackdrop");
const closeDistSettingsBtn = document.getElementById("closeDistSettingsBtn");
const distR2WorkerInput = document.getElementById("distR2WorkerInput");
const distQueuePathInput = document.getElementById("distQueuePathInput");
const distAccountsList = document.getElementById("distAccountsList");
const addDistAccountBtn = document.getElementById("addDistAccountBtn");
const distDefaultTargetSelect = document.getElementById("distDefaultTargetSelect");
const distTestStatusBox = document.getElementById("distTestStatusBox");
const saveDistSettingsBtn = document.getElementById("saveDistSettingsBtn");

// Import Local Set Modal Elements
const openImportSetModalBtn = document.getElementById("openImportSetModalBtn");
const importSetModal = document.getElementById("importSetModal");
const importSetBackdrop = document.getElementById("importSetBackdrop");
const closeImportSetModalBtn = document.getElementById("closeImportSetModalBtn");
const importSetModeSelect = document.getElementById("importSetModeSelect");
const importSetPromptInput = document.getElementById("importSetPromptInput");
const importDropzone = document.getElementById("importDropzone");
const importSetFilesInput = document.getElementById("importSetFilesInput");
const importSelectedCountText = document.getElementById("importSelectedCountText");
const importUpscaleToggle = document.getElementById("importUpscaleToggle");
const importAutoMetaToggle = document.getElementById("importAutoMetaToggle");
const runImportSetBtn = document.getElementById("runImportSetBtn");

// Edit Metadata Modal Elements
const editMetaModal = document.getElementById("editMetaModal");
const editMetaBackdrop = document.getElementById("editMetaBackdrop");
const closeEditMetaBtn = document.getElementById("closeEditMetaBtn");
const editMetaTitleInput = document.getElementById("editMetaTitleInput");
const editMetaCategorySelect = document.getElementById("editMetaCategorySelect");
const editMetaTagsInput = document.getElementById("editMetaTagsInput");
const editMetaDescInput = document.getElementById("editMetaDescInput");
const saveEditMetaBtn = document.getElementById("saveEditMetaBtn");

const ZEDGE_CATEGORIES = [
  "ANIMALS", "ANIME", "CARS_N_VEHICLES", "COMICS", "DESIGNS", "DRAWINGS",
  "ENTERTAINMENT", "FUNNY", "GAMES", "HOLIDAYS", "LOVE", "MUSIC", "NATURE",
  "PATTERNS", "PEOPLE", "SAYINGS", "SPACE", "SPIRITUAL", "SPORTS", "TECHNOLOGY"
];

let currentReferenceDataUrl = null;
let currentReferenceFilename = null;
let activeLightboxDownloadHandler = null;
let stageEditorsExpanded = false;
let simAutoPlayTimer = null;
let simActiveImages = [];
let simActiveIndex = 0;
let simActiveWorkflowMode = "set_dual";
let currentDistConfig = {
  r2WorkerUrl: "",
  queuePath: "wallpaperQueue",
  accounts: [],
  defaultTarget: "spread",
  spreadPool: []
};
let pendingImportFiles = [];
let activeEditingMetaEntryId = null;

function icon(name, sizeClass = "icon") {
  return `<svg class="${sizeClass}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><use href="#i-${name}"></use></svg>`;
}

function deriveR2Folder(accountName) {
  const clean = String(accountName || "")
    .replace(/^zedge_?/i, "zedge")
    .replace(/[^a-zA-Z0-9_-]/g, "");
  return clean || "studio";
}

// Populate Zedge Categories in Edit Metadata Modal
ZEDGE_CATEGORIES.forEach((cat) => {
  const opt = document.createElement("option");
  opt.value = cat;
  opt.textContent = cat;
  editMetaCategorySelect.appendChild(opt);
});

const STORY_ARC_OPTIONS = {
  set_24h: [
    { value: "auto", label: "Auto (Smart Keyword Pick)" },
    { value: "light", label: "Light Only (Kelvin & Elevation)" },
    { value: "bloom", label: "Bloom Cycle (Awaken → Peak → Rest)" },
    { value: "rhythm", label: "Daily Rhythm (Calm → Active → Quiet)" }
  ],
  set_battery: [
    { value: "auto", label: "Auto (Smart Keyword Pick)" },
    { value: "energy", label: "Energy Glow (5%→100% Ladder)" },
    { value: "growth", label: "Growth (Tiny Seed → Monumental)" },
    { value: "awaken", label: "Awakening (Dormant → Peak Vitality)" }
  ]
};

const SET_MODE_CONFIGS = {
  dual: {
    badge: "9:16 + Foldable · 2 JPGs",
    desc: "Phone 1620×2880 + a foldable companion reframed from the same artwork.",
    chips: [
      "<strong>2 Files:</strong> wallpaper.jpg + wallpaper-landscape.jpg",
      "<strong>Phone:</strong> 1620×2880 (9:16)",
      "<strong>Foldable:</strong> 2800×2400 or 2000×2000",
    ],
    stepLabels: ["9:16 Gen", "HD Upscale", "Foldable Gen", "AI Metadata"],
    stages: [
      {
        slot: 1,
        name: "9:16 Phone Wallpaper (প্রথম ছবি)",
        filename: "wallpaper.jpg",
        isAnchor: true,
        defaultPrompt:
          "9:16 vertical phone wallpaper, strong central focal subject, clean upper space for lock clock and widgets, ultra-detailed 8k finish"
      },
      {
        slot: 2,
        name: "Foldable Companion (দ্বিতীয় ছবি)",
        filename: "wallpaper-landscape.jpg",
        isAnchor: false,
        defaultPrompt:
          "make it landscape mode, re-frame the exact same artwork for foldable screen without cropping the main subject, extend background naturally"
      }
    ],
    presets: [
      {
        title: "Cybernetic Fox + Foldable City",
        prompt:
          "A glowing neon cybernetic fox sitting in a rain-slicked cyberpunk alley at night with holographic reflections, cinematic lighting, 8k detail",
        stages: null
      },
      {
        title: "Mystical Lotus Temple + Foldable Courtyard",
        prompt:
          "A centered glowing mystical lotus flower floating in an ornate stone basin inside a serene temple courtyard under starlight, 8k digital art",
        stages: null
      },
      {
        title: "Alpine Mirror Lake + Foldable Mountains",
        prompt:
          "A tranquil alpine mirror lake with a warm wooden A-frame cabin on the shore, pine trees, and snow-capped mountain peaks, crisp stylized illustration",
        stages: null
      },
      {
        title: "Cosmic Astronaut + Foldable Nebula",
        prompt:
          "A lone astronaut standing on a crystalline asteroid overlooking a vibrant violet-gold spiral nebula and ringed planet, epic sci-fi wallpaper",
        stages: null
      }
    ]
  },
  set_dual: {
    badge: "Dual · 2 JPGs",
    desc: "Lock screen close-up + home screen wide view, same scene.",
    chips: [
      "<strong>2 Files:</strong> lock.jpg + home.jpg",
      "<strong>Min:</strong> 1620×2880",
      "<strong>Max:</strong> ≤8 MB / <25 MP",
    ],
    stepLabels: ["Lock Gen", "Anchor Sync", "Home Gen", "AI Metadata"],
    stages: [
      {
        slot: 1,
        name: "Lock Screen (প্রথম ছবি)",
        filename: "WP_Dual_1_LockScreen.jpg",
        isAnchor: true,
        defaultPrompt:
          "lock screen framing: macro close-up, the hero fills about 80 percent of the frame height, shallow depth of field with a softly blurred background, striking fine surface detail, hero mass in the lower two thirds"
      },
      {
        slot: 2,
        name: "Home Screen (দ্বিতীয় ছবি)",
        filename: "WP_Dual_2_HomeScreen.jpg",
        isAnchor: false,
        defaultPrompt:
          "home screen framing: wide establishing view of the same scene pulled far back, the hero now occupies only about 30 percent of the frame height and sits low, deep focus, generous calm negative space and quiet low-detail area across the upper half for icons and widgets"
      }
    ],
    presets: [
      {
        title: "Complementary Lock + Clean Home",
        prompt:
          "A serene bioluminescent crystal sanctuary floating above a misty mountain lake under a starry aurora sky, stylized digital art, ultra-detailed 8k",
        stages: null
      },
      {
        title: "Closed Portal → Awakened Portal",
        prompt:
          "An ancient carved stone portal arch standing in a tranquil mossy zen garden surrounded by floating lanterns, cinematic fantasy illustration",
        stages: [
          "Lock Screen (1/2): The ancient stone portal in a mysterious dormant state with soft dim runes and calm twilight mist, clean upper space for the lock clock",
          "Home Screen (2/2): Keep the exact same stone portal, camera angle, and zen garden from this image, but awaken the portal with a warm golden-cyan celestial gateway glow and illuminated floating lanterns (aspect ratio 9:16)"
        ]
      },
      {
        title: "Hero Character → Wide World",
        prompt:
          "A futuristic samurai standing on a neon-lit cyberpunk rooftop overlooking a rain-slicked megacity skyline at night, vibrant synthwave palette",
        stages: null
      },
      {
        title: "Golden Dusk → Starry Night",
        prompt:
          "A cozy cliffside lighthouse overlooking calm ocean waves and distant sailboats, painterly anime landscape art",
        stages: null
      }
    ]
  },

  set_24h: {
    badge: "24-Hour · 4 JPGs",
    desc: "Morning, afternoon, evening, night — same scene, light and colour only.",
    chips: [
      "<strong>4 Files:</strong> morning → night.jpg",
      "<strong>Rule 1:</strong> Identical Scene",
      "<strong>Rule 2:</strong> Light & Color Only",
    ],
    stepLabels: ["Morning", "Afternoon", "Evening", "Night & Meta"],
    stages: [
      {
        slot: 1,
        name: "Morning • সকাল (1/4)",
        filename: "WP_24Hour_1_Morning.jpg",
        isAnchor: true,
        defaultPrompt:
          "6 am dawn: key light low on the horizon from the left at about 10 degrees elevation, roughly 3000K rose-gold color temperature, long soft shadows stretching to the right, low-lying mist, cool blue shadow tones, fresh tranquil mood"
      },
      {
        slot: 2,
        name: "Afternoon • দুপুর (2/4)",
        filename: "WP_24Hour_2_Afternoon.jpg",
        isAnchor: false,
        defaultPrompt:
          "1 pm midday: key light almost straight overhead at about 80 degrees elevation, roughly 5600K neutral white daylight, short hard shadows directly under the subject, no mist, maximum color saturation and micro-detail, bright high-contrast clarity"
      },
      {
        slot: 3,
        name: "Evening • সন্ধ্যা (3/4)",
        filename: "WP_24Hour_3_Evening.jpg",
        isAnchor: false,
        defaultPrompt:
          "6 pm golden hour: key light raking in low from the right at about 8 degrees elevation, roughly 2200K amber-orange color temperature, long dramatic shadows falling to the left, warm haze and strong rim light tracing every edge"
      },
      {
        slot: 4,
        name: "Night • রাত (4/4)",
        filename: "WP_24Hour_4_Night.jpg",
        isAnchor: false,
        defaultPrompt:
          "11 pm night: no sun, only cool moonlight from high behind at roughly 7500K deep indigo, about 70 percent of the frame in deep shadow, silver specular highlights on edges only, soft local glow from the scene own light sources"
      }
    ],
    presets: [
      {
        title: "Alpine Mountain Lake",
        prompt:
          "A tranquil alpine mirror lake with a small wooden A-frame cabin on the shore, pine trees, and snow-capped mountain peaks in the background, crisp stylized landscape illustration",
        stages: null
      },
      {
        title: "Cozy Japanese Lantern Street",
        prompt:
          "A charming traditional Japanese hillside street with a cozy wooden tea shop, hanging paper lanterns, power lines, and distant cherry blossom trees overlooking the bay, Makoto Shinkai inspired anime art",
        stages: null
      },
      {
        title: "Cyberpunk Skyline Terrace",
        prompt:
          "A high-tech glass observatory terrace overlooking a futuristic solarpunk-cyberpunk city skyline with suspended monorails and gardens, detailed digital matte painting",
        stages: null
      },
      {
        title: "Minimalist Desert Arch",
        prompt:
          "A minimalist monumental sandstone arch framed by sweeping desert dunes and a lone oasis palm below a vast open sky, clean geometric vector art style",
        stages: null
      },
      {
        title: "Enchanted Forest Torii Shrine",
        prompt:
          "A vermilion Torii gate standing on a mossy stone island in the middle of a calm forest pond surrounded by ancient cedar trees and stone lanterns, atmospheric fantasy art",
        stages: null
      }
    ]
  },

  set_battery: {
    badge: "Battery · 6 JPGs",
    desc: "0% to 100% + charging — same scene, light level only.",
    chips: [
      "<strong>6 Files:</strong> 0%–100% / WP_Battery_*.jpg",
      "<strong>Focal Point:</strong> Dead-Center",
      "<strong>Hub Slots:</strong> critical..charging",
    ],
    stepLabels: ["Mid Anchor", "Low / Crit", "High / Full", "Charge & Meta"],
    stages: [
      {
        slot: 1,
        name: "0% (Level 1: Critical)",
        filename: "WP_Battery_Level1_Critical.jpg",
        isAnchor: false,
        defaultPrompt:
          "charge level 0 of 100: the scene is almost completely dark, about 5 percent of the frame carries any light, a single dim ember of its own glow hue no larger than a coin, no bloom, no light spill, deep crushed black shadows filling the rest of the frame"
      },
      {
        slot: 2,
        name: "20% (Level 2: Low)",
        filename: "WP_Battery_Level2_Low.jpg",
        isAnchor: false,
        defaultPrompt:
          "charge level 20 of 100: about 20 percent of the frame is lit, the glow is a thin low-intensity core with a tight halo roughly twice its own size, faint light spill on the nearest surface only, the outer two thirds of the frame still sit in deep shadow"
      },
      {
        slot: 3,
        name: "40% (Level 3: Mid Anchor)",
        filename: "WP_Battery_Level3_Mid.jpg",
        isAnchor: true,
        defaultPrompt:
          "charge level 40 of 100: centered central focal point composition, about 40 percent of the frame is lit, the glow core is clearly visible with its halo reaching roughly a quarter of the frame width, visible light rays and reflections on mid-distance surfaces"
      },
      {
        slot: 4,
        name: "60% (Level 4: High)",
        filename: "WP_Battery_Level4_High.jpg",
        isAnchor: false,
        defaultPrompt:
          "charge level 60 of 100: about 60 percent of the frame is lit and roughly two stops brighter than the previous stage, the glow core is burning hot with a wide bloom reaching half the frame width, strong rays and reflections across the whole mid-ground"
      },
      {
        slot: 5,
        name: "80% (Level 5: Full)",
        filename: "WP_Battery_Level5_Full.jpg",
        isAnchor: false,
        defaultPrompt:
          "charge level 80 of 100: about 80 percent of the frame is lit and clearly brighter again, the glow core is near-white hot at its center, heavy bloom with visible lens flare and volumetric light beams crossing the frame, bright haze filling the air"
      },
      {
        slot: 6,
        name: "100% (Charging / Active)",
        filename: "WP_Battery_Charging.jpg",
        isAnchor: false,
        defaultPrompt:
          "charge level 100 of 100: the whole frame is flooded with light at maximum output, the glow core is blown out pure white at its center with saturated hue at its rim, extreme bloom covering the entire frame, strong star-burst flare, zero dark areas"
      }
    ],
    presets: [
      {
        title: "Botanical Bloom (Flower Rule 4)",
        prompt:
          "A single centered ornamental lotus-rose plant in a minimalist ceramic pot on a clean dark stone pedestal, soft studio background, 8k botanical illustration",
        stages: null
      },
      {
        title: "Glass Aquarium Terrarium",
        prompt:
          "A centered crystal-clear glass cube aquarium terrarium with aquatic plants, mossy driftstones, and glowing tetra fish on a sleek dark desk, 8k render",
        stages: null
      },
      {
        title: "Abstract Crystal Core",
        prompt:
          "A centered levitating geometric crystal energy core suspended above a dark obsidian ring pedestal in a sleek futuristic chamber, 8k abstract 3D render",
        stages: null
      },
      {
        title: "Minimalist Zen Orb",
        prompt:
          "A minimalist centered luminous glass sphere above concentric matte black ripple rings, clean modern abstract wallpaper",
        stages: null
      },
      {
        title: "Cute Spirit Mascot",
        prompt:
          "A cute centered kawaii star-spirit character sitting inside a cozy stone garden lantern surrounded by moss, stylized 3D illustration",
        stages: null
      },
      {
        title: "Bioluminescent Bonsai",
        prompt:
          "A centered ancient bonsai spirit tree growing on a small floating rock island over calm dark water, fantasy landscape art",
        stages: null
      }
    ]
  }
};

function setStepperState(activeStep, completedAll = false) {
  stepItems.forEach((el) => {
    const stepNum = parseInt(el.getAttribute("data-step"), 10);
    el.classList.remove("active", "done");
    if (completedAll || (activeStep && stepNum < activeStep)) {
      el.classList.add("done");
    } else if (activeStep && stepNum === activeStep) {
      el.classList.add("active");
    }
  });
}

function showStatus(message, type = "info", loading = false, step = null) {
  statusBox.classList.remove("hidden", "error", "success");
  if (type === "error") statusBox.classList.add("error");
  if (type === "success") statusBox.classList.add("success");

  if (loading) {
    statusSpinner.classList.remove("hidden");
  } else {
    statusSpinner.classList.add("hidden");
  }
  statusText.textContent = message;

  if (type === "success") {
    setStepperState(4, true);
  } else if (step) {
    setStepperState(step, false);
  }
}

function isZedgeSetMode(mode) {
  return mode === "set_dual" || mode === "set_24h" || mode === "set_battery";
}

function getCustomStagePromptsFromDOM() {
  if (!stageEditorsExpanded) return null;
  const inputs = stageEditorsList.querySelectorAll(".stage-editor-input");
  if (!inputs || inputs.length === 0) return null;
  return Array.from(inputs).map((inp) => inp.value.trim());
}

function populateStoryArcOptions(mode, selectedValue = "auto") {
  if (mode === "set_24h" || mode === "set_battery") {
    storyArcField.classList.remove("hidden");
    arcStyleGrid.classList.remove("cols-3");
    const opts = STORY_ARC_OPTIONS[mode] || STORY_ARC_OPTIONS.set_24h;
    storyArcSelect.innerHTML = "";
    opts.forEach((o) => {
      const el = document.createElement("option");
      el.value = o.value;
      el.textContent = o.label;
      storyArcSelect.appendChild(el);
    });
    if (opts.some((o) => o.value === selectedValue)) {
      storyArcSelect.value = selectedValue;
    } else {
      storyArcSelect.value = "auto";
    }
  } else {
    storyArcField.classList.add("hidden");
    arcStyleGrid.classList.add("cols-3");
  }
}

function syncFoldableVisibility(mode) {
  const isMultiSet = isZedgeSetMode(mode);
  const wantsFoldableInSet = isMultiSet && includeFoldableCompanionCheckbox && includeFoldableCompanionCheckbox.checked;
  const showFoldableControls =
    mode === "dual" ||
    mode === "img2img_file" ||
    mode === "landscape_only" ||
    wantsFoldableInSet;

  if (foldableCompanionToggleWrap) {
    foldableCompanionToggleWrap.classList.toggle("hidden", !isMultiSet);
  }
  landscapePromptGroup.classList.toggle("hidden", !showFoldableControls);
  landscapeResBox.classList.toggle("hidden", !showFoldableControls);
  resGridContainer.classList.toggle("one-col", !showFoldableControls);

  const lw = parseInt(landscapeWidthInput.value, 10) || 2800;
  const lh = parseInt(landscapeHeightInput.value, 10) || 2400;
  foldSizeBtns.forEach((btn) => {
    const bw = parseInt(btn.getAttribute("data-w"), 10);
    const bh = parseInt(btn.getAttribute("data-h"), 10);
    btn.classList.toggle("active", bw === lw && bh === lh);
  });
}

function renderSetModeUI(mode, customStageValues = null, savedArc = "auto") {
  modeTabs.forEach((tab) => {
    tab.classList.toggle("active", tab.getAttribute("data-mode") === mode);
  });
  subModePills.forEach((pill) => {
    pill.classList.toggle("active", pill.getAttribute("data-mode") === mode);
  });

  const pw = Math.max(1620, parseInt(portraitWidthInput.value, 10) || 1620);
  const ph = Math.max(2880, parseInt(portraitHeightInput.value, 10) || 2880);
  const mp = ((pw * ph) / 1000000).toFixed(2);
  specStatusBadge.textContent = `JPG • ≤8MB • ${mp} MP`;

  populateStoryArcOptions(mode, savedArc);
  syncFoldableVisibility(mode);

  if (SET_MODE_CONFIGS[mode]) {
    const cfg = SET_MODE_CONFIGS[mode];
    arcAndStyleBox.classList.remove("hidden");
    stageMatrixBox.classList.toggle("hidden", mode === "dual");

    stepLabel1.textContent = cfg.stepLabels[0];
    stepLabel2.textContent = cfg.stepLabels[1];
    stepLabel3.textContent = cfg.stepLabels[2];
    stepLabel4.textContent = cfg.stepLabels[3];


    stageMatrixTitle.textContent = `Set Stage Matrix (${cfg.stages.length} Deliverables)`;
    const effectiveStages =
      Array.isArray(customStageValues) && customStageValues.length === cfg.stages.length
        ? customStageValues
        : cfg.stages.map((s) => s.defaultPrompt);
    renderStageMatrixEditors(cfg.stages, effectiveStages);
  } else {
    arcAndStyleBox.classList.remove("hidden");
    stageMatrixBox.classList.add("hidden");

    stepLabel1.textContent = "9:16 Gen";
    stepLabel2.textContent = "HD Upscale";
    stepLabel3.textContent = "Foldable Gen";
    stepLabel4.textContent = "Save JPG";
  }

  updateActionLabels();
}

function renderStageMatrixEditors(stages, values) {
  stagePillsPreview.innerHTML = "";
  stageEditorsList.innerHTML = "";

  stages.forEach((st, idx) => {
    const pill = document.createElement("span");
    pill.className = `stage-slot-pill${st.isAnchor ? " anchor" : ""}`;
    pill.innerHTML = `<span class="stage-slot-num">${st.slot}</span><span>${st.name}</span>`;
    stagePillsPreview.appendChild(pill);

    const editorItem = document.createElement("div");
    editorItem.className = "stage-editor-item";

    const top = document.createElement("div");
    top.className = "stage-editor-top";
    top.innerHTML = `<span>#${st.slot} ${st.name}</span><span class="stage-editor-filename">${st.filename}</span>`;

    const input = document.createElement("textarea");
    input.className = "stage-editor-input";
    input.rows = 2;
    input.value = values && values[idx] ? values[idx] : st.defaultPrompt;
    input.addEventListener("input", saveFormState);

    editorItem.appendChild(top);
    editorItem.appendChild(input);
    stageEditorsList.appendChild(editorItem);
  });
}

toggleStageMatrixBtn.addEventListener("click", () => {
  stageEditorsExpanded = !stageEditorsExpanded;
  stageEditorsList.classList.toggle("hidden", !stageEditorsExpanded);
  toggleStageMatrixBtn.textContent = stageEditorsExpanded ? "Hide Prompts" : "Edit Stage Prompts";
});

resetStagePromptsBtn.addEventListener("click", () => {
  const mode = workflowModeSelect.value;
  if (isZedgeSetMode(mode)) {
    const cfg = SET_MODE_CONFIGS[mode];
    renderStageMatrixEditors(
      cfg.stages,
      cfg.stages.map((s) => s.defaultPrompt)
    );
    saveFormState();
    showStatus("Reset stage instructions to default specification rules.", "info", false);
  }
});

modeTabs.forEach((tab) => {
  tab.addEventListener("click", () => {
    const targetMode = tab.getAttribute("data-mode");
    workflowModeSelect.value = targetMode;
    renderSetModeUI(targetMode);
    saveFormState();
  });
});

subModePills.forEach((pill) => {
  pill.addEventListener("click", () => {
    const targetMode = pill.getAttribute("data-mode");
    workflowModeSelect.value = targetMode;
    renderSetModeUI(targetMode);
    saveFormState();
  });
});

function updateActionLabels() {
  const mode = workflowModeSelect.value;
  const pw = parseInt(portraitWidthInput.value, 10) || 1620;
  const ph = parseInt(portraitHeightInput.value, 10) || 2880;
  const lw = parseInt(landscapeWidthInput.value, 10) || 2800;
  const lh = parseInt(landscapeHeightInput.value, 10) || 2400;
  const actionVerb = autoDownloadCheckbox.checked ? "Generate & Save" : "Generate";

  if (mode === "set_dual") {
    generateBtn.innerHTML = `${icon("sparkles")}<span>${actionVerb} Dual Set</span>`;
  } else if (mode === "set_24h") {
    generateBtn.innerHTML = `${icon("sparkles")}<span>${actionVerb} 24-Hour Set</span>`;
  } else if (mode === "set_battery") {
    generateBtn.innerHTML = `${icon("sparkles")}<span>${actionVerb} Battery Set</span>`;
  } else if (mode === "dual") {
    generateBtn.innerHTML = `${icon("sparkles")}<span>${actionVerb} 9:16 + Foldable Set</span>`;
  } else if (mode === "img2img_file") {
    generateBtn.innerHTML = `${icon("sparkles")}<span>Generate from Reference</span>`;
  } else if (mode === "portrait_only") {
    generateBtn.innerHTML = `${icon("sparkles")}<span>${actionVerb} Single 9:16</span>`;
  } else {
    generateBtn.innerHTML = `${icon("sparkles")}<span>${actionVerb} Single Foldable</span>`;
  }
}

async function loadSavedState() {
  const hasChromeStorage = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
  const data = hasChromeStorage ? await chrome.storage.local.get([
    "workflowMode",
    "savedPrompt",
    "negativePrompt",
    "includeFoldableCompanion",
    "landscapePrompt",
    "customStagesByMode",
    "storyArc",
    "variationStrength",
    "displayTarget",
    "colorBoost",
    "autoWriteMetadata",
    "aiDirectorEnabled",
    "useHubSetFolders",
    "batchMode",
    "upscaleEnabled",
    "portraitWidth",
    "portraitHeight",
    "landscapeWidth",
    "landscapeHeight",
    "subfolder",
    "useExactZedgeNames",
    "forceImagePrefix",
    "autoDownloadEnabled",
    "geminiAccountMode",
    "discoveredGeminiAccounts",
    "activeGeminiAccountInfo",
    "distConfig",
    "history"
  ]) : {};

  const mode = data.workflowMode || "dual";
  workflowModeSelect.value = mode;
  if (data.savedPrompt) promptInput.value = data.savedPrompt;
  if (data.negativePrompt !== undefined && negativePromptInput) {
    negativePromptInput.value = data.negativePrompt;
  }
  if (data.includeFoldableCompanion !== undefined && includeFoldableCompanionCheckbox) {
    includeFoldableCompanionCheckbox.checked = Boolean(data.includeFoldableCompanion);
  }
  if (data.landscapePrompt) landscapePromptInput.value = data.landscapePrompt;
  if (data.variationStrength) variationStrengthSelect.value = data.variationStrength;
  if (data.displayTarget) displayTargetSelect.value = data.displayTarget;
  if (data.colorBoost) colorBoostSelect.value = data.colorBoost;
  if (data.autoWriteMetadata !== undefined) {
    autoWriteMetadataCheckbox.checked = Boolean(data.autoWriteMetadata);
  }
  if (data.aiDirectorEnabled !== undefined) {
    aiDirectorEnabledCheckbox.checked = Boolean(data.aiDirectorEnabled);
  }
  if (data.useHubSetFolders !== undefined) {
    useHubSetFoldersCheckbox.checked = Boolean(data.useHubSetFolders);
  }
  if (data.batchMode !== undefined) batchModeCheckbox.checked = data.batchMode;
  if (data.upscaleEnabled !== undefined) upscaleEnabledCheckbox.checked = data.upscaleEnabled;
  if (data.portraitWidth) portraitWidthInput.value = data.portraitWidth;
  if (data.portraitHeight) portraitHeightInput.value = data.portraitHeight;
  if (data.landscapeWidth) landscapeWidthInput.value = data.landscapeWidth;
  if (data.landscapeHeight) landscapeHeightInput.value = data.landscapeHeight;
  if (data.subfolder !== undefined) subfolderInput.value = data.subfolder;
  if (data.useExactZedgeNames !== undefined) {
    useExactZedgeNamesCheckbox.checked = Boolean(data.useExactZedgeNames);
  }
  if (data.forceImagePrefix !== undefined) forceImagePrefixCheckbox.checked = data.forceImagePrefix;
  if (data.autoDownloadEnabled !== undefined) {
    autoDownloadCheckbox.checked = Boolean(data.autoDownloadEnabled);
  }
  if (data.distConfig) {
    currentDistConfig = data.distConfig;
  }

  const savedStagesForMode =
    data.customStagesByMode && data.customStagesByMode[mode] ? data.customStagesByMode[mode] : null;
  populateGeminiAccountsDropdown(
    data.discoveredGeminiAccounts || [],
    data.geminiAccountMode || "auto"
  );
  if (data.activeGeminiAccountInfo && data.activeGeminiAccountInfo.email) {
    const info = data.activeGeminiAccountInfo;
    sessionIndicator.textContent = `u/${info.authUser || 0}: ${String(info.email).split("@")[0]}`;
    sessionIndicator.classList.add("ok");
  }
  renderSetModeUI(mode, savedStagesForMode, data.storyArc || "auto");
  renderGallery(data.history || []);
}

async function saveFormState() {
  const mode = workflowModeSelect.value;
  const hasChromeStorage = typeof chrome !== "undefined" && chrome.storage && chrome.storage.local;
  syncFoldableVisibility(mode);
  updateActionLabels();
  if (!hasChromeStorage) return;

  const { customStagesByMode = {} } = await chrome.storage.local.get("customStagesByMode");
  if (isZedgeSetMode(mode) && stageEditorsExpanded) {
    const domStages = getCustomStagePromptsFromDOM();
    if (domStages) {
      customStagesByMode[mode] = domStages;
    }
  }

  chrome.storage.local.set({
    workflowMode: mode,
    savedPrompt: promptInput.value,
    negativePrompt: negativePromptInput ? negativePromptInput.value : DEFAULT_NEGATIVE_PROMPT,
    includeFoldableCompanion: includeFoldableCompanionCheckbox ? includeFoldableCompanionCheckbox.checked : false,
    landscapePrompt: landscapePromptInput.value,
    customStagesByMode,
    storyArc: storyArcSelect.value,
    variationStrength: variationStrengthSelect.value,
    displayTarget: displayTargetSelect.value,
    colorBoost: colorBoostSelect.value,
    autoWriteMetadata: autoWriteMetadataCheckbox.checked,
    aiDirectorEnabled: aiDirectorEnabledCheckbox.checked,
    useHubSetFolders: useHubSetFoldersCheckbox.checked,
    batchMode: batchModeCheckbox.checked,
    upscaleEnabled: upscaleEnabledCheckbox.checked,
    portraitWidth: parseInt(portraitWidthInput.value, 10) || 1620,
    portraitHeight: parseInt(portraitHeightInput.value, 10) || 2880,
    landscapeWidth: parseInt(landscapeWidthInput.value, 10) || 2800,
    landscapeHeight: parseInt(landscapeHeightInput.value, 10) || 2400,
    subfolder: subfolderInput.value,
    useExactZedgeNames: useExactZedgeNamesCheckbox.checked,
    forceImagePrefix: forceImagePrefixCheckbox.checked,
    autoDownloadEnabled: autoDownloadCheckbox.checked
  });
  updateActionLabels();
}

function formatBytes(bytes) {
  if (!bytes) return "≤ 8 MB JPG";
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function copyTextToClipboard(text, label = "Copied") {
  navigator.clipboard.writeText(text || "").then(() => {
    showStatus(`${label} copied to clipboard!`, "success", false);
  });
}

function setReferenceImage(dataUrl, filename) {
  currentReferenceDataUrl = dataUrl;
  currentReferenceFilename = filename;
  refPreviewImg.src = dataUrl;
  refFileName.textContent = filename;
  dropzoneEmpty.classList.add("hidden");
  dropzonePreview.classList.remove("hidden");
}

function clearReferenceImage() {
  currentReferenceDataUrl = null;
  currentReferenceFilename = null;
  refPreviewImg.src = "";
  refFileInput.value = "";
  dropzonePreview.classList.add("hidden");
  dropzoneEmpty.classList.remove("hidden");
}

dropzone.addEventListener("click", (e) => {
  if (e.target === clearRefBtn) return;
  refFileInput.click();
});

clearRefBtn.addEventListener("click", (e) => {
  e.stopPropagation();
  clearReferenceImage();
});

refFileInput.addEventListener("change", (e) => {
  const file = e.target.files && e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    setReferenceImage(reader.result, file.name);
  };
  reader.readAsDataURL(file);
});

dropzone.addEventListener("dragover", (e) => {
  e.preventDefault();
  dropzone.classList.add("dragover");
});

dropzone.addEventListener("dragleave", () => {
  dropzone.classList.remove("dragover");
});

dropzone.addEventListener("drop", (e) => {
  e.preventDefault();
  dropzone.classList.remove("dragover");
  const file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    setReferenceImage(reader.result, file.name);
  };
  reader.readAsDataURL(file);
});

// ============================================================================
// DISTRIBUTION / PANEL UPLOAD SETTINGS MODAL LOGIC (2-Row Account Cards)
// ============================================================================

function renderDistAccountsEditor() {
  distAccountsList.innerHTML = "";
  const accounts = currentDistConfig.accounts || [];

  if (accounts.length === 0) {
    accounts.push({ name: "zedge_1", dbUrl: "", secret: "" });
  }

  accounts.forEach((acc, idx) => {
    const card = document.createElement("div");
    card.className = "dist-account-card";

    // Row 1: Account Name + Live R2 Folder Pill + Test Connection + Remove
    const topRow = document.createElement("div");
    topRow.className = "dist-account-top";

    const nameGroup = document.createElement("div");
    nameGroup.className = "dist-account-name-group";

    const nameInp = document.createElement("input");
    nameInp.type = "text";
    nameInp.className = "dist-account-name-input";
    nameInp.placeholder = "zedge_1";
    nameInp.value = acc.name || "";

    const r2Pill = document.createElement("span");
    r2Pill.className = "dist-r2-folder-pill";
    r2Pill.textContent = `R2 Folder: ${deriveR2Folder(acc.name || "zedge_1")}/wallpaper/`;

    nameInp.addEventListener("input", () => {
      r2Pill.textContent = `R2 Folder: ${deriveR2Folder(nameInp.value)}/wallpaper/`;
      syncDistTargetSelectOptions();
    });

    nameGroup.appendChild(nameInp);
    nameGroup.appendChild(r2Pill);

    const actions = document.createElement("div");
    actions.className = "dist-account-actions";

    // Row 2: Firebase Realtime DB URL + Secret Input with Show/Hide Toggle
    const bottomRow = document.createElement("div");
    bottomRow.className = "dist-account-bottom";

    const urlWrap = document.createElement("div");
    urlWrap.className = "field-group";
    const urlLabel = document.createElement("label");
    urlLabel.className = "field-label";
    urlLabel.textContent = "Firebase Realtime Database URL";
    const urlInp = document.createElement("input");
    urlInp.type = "text";
    urlInp.className = "dist-account-url-input";
    urlInp.placeholder = "https://your-project-default-rtdb.firebaseio.com";
    urlInp.value = acc.dbUrl || "";
    urlWrap.appendChild(urlLabel);
    urlWrap.appendChild(urlInp);

    const secWrap = document.createElement("div");
    secWrap.className = "field-group";
    const secLabel = document.createElement("label");
    secLabel.className = "field-label";
    secLabel.textContent = "Database Secret / Auth Token (Optional)";
    const secInner = document.createElement("div");
    secInner.className = "secret-input-wrap";
    const secInp = document.createElement("input");
    secInp.type = "password";
    secInp.className = "dist-account-secret-input";
    secInp.placeholder = "Optional DB secret";
    secInp.value = acc.secret || "";

    const toggleSecBtn = document.createElement("button");
    toggleSecBtn.type = "button";
    toggleSecBtn.className = "btn-toggle-secret";
    toggleSecBtn.textContent = "Show";
    toggleSecBtn.addEventListener("click", () => {
      const isPass = secInp.type === "password";
      secInp.type = isPass ? "text" : "password";
      toggleSecBtn.textContent = isPass ? "Hide" : "Show";
    });

    secInner.appendChild(secInp);
    secInner.appendChild(toggleSecBtn);
    secWrap.appendChild(secLabel);
    secWrap.appendChild(secInner);

    bottomRow.appendChild(urlWrap);
    bottomRow.appendChild(secWrap);

    const testBtn = document.createElement("button");
    testBtn.type = "button";
    testBtn.className = "btn-tiny";
    testBtn.textContent = "Test DB Connection";
    testBtn.addEventListener("click", () => {
      const dbUrl = urlInp.value.trim();
      if (!dbUrl) {
        distTestStatusBox.className = "dist-test-status err";
        distTestStatusBox.textContent = `Enter a Firebase Database URL for "${nameInp.value || "account"}" first.`;
        return;
      }
      distTestStatusBox.className = "dist-test-status";
      distTestStatusBox.textContent = `Testing connection to ${nameInp.value || "DB"}...`;
      chrome.runtime.sendMessage(
        {
          type: "TEST_PANEL_DB",
          options: { dbUrl, secret: secInp.value.trim() }
        },
        (res) => {
          if (res && res.ok) {
            distTestStatusBox.className = "dist-test-status ok";
            distTestStatusBox.textContent = `${nameInp.value || "Account"}: ${res.message}`;
          } else {
            distTestStatusBox.className = "dist-test-status err";
            distTestStatusBox.textContent = `${nameInp.value || "Account"}: ${res ? res.error : "Connection failed"}`;
          }
        }
      );
    });

    const delBtn = document.createElement("button");
    delBtn.type = "button";
    delBtn.className = "btn-small-danger";
    delBtn.textContent = "Remove";
    delBtn.addEventListener("click", () => {
      currentDistConfig.accounts = readDistAccountsFromDOM();
      currentDistConfig.accounts.splice(idx, 1);
      renderDistAccountsEditor();
    });

    actions.appendChild(testBtn);
    actions.appendChild(delBtn);
    topRow.appendChild(nameGroup);
    topRow.appendChild(actions);

    card.appendChild(topRow);
    card.appendChild(bottomRow);
    distAccountsList.appendChild(card);
  });

  syncDistTargetSelectOptions();
}

function readDistAccountsFromDOM() {
  const cards = distAccountsList.querySelectorAll(".dist-account-card");
  const list = [];
  cards.forEach((c) => {
    const nameInp = c.querySelector(".dist-account-name-input");
    const urlInp = c.querySelector(".dist-account-url-input");
    const secInp = c.querySelector(".dist-account-secret-input");
    const name = nameInp ? nameInp.value.trim() : "";
    const dbUrl = urlInp ? urlInp.value.trim() : "";
    const secret = secInp ? secInp.value.trim() : "";
    if (name || dbUrl) {
      list.push({ name: name || "zedge_1", dbUrl, secret });
    }
  });
  return list;
}

function syncDistTargetSelectOptions() {
  const prev = distDefaultTargetSelect.value || currentDistConfig.defaultTarget || "spread";
  distDefaultTargetSelect.innerHTML = `<option value="spread">Spread (Auto-Rotate Across Accounts)</option>`;
  const domAccounts = readDistAccountsFromDOM();
  domAccounts.forEach((a) => {
    if (a.name) {
      const opt = document.createElement("option");
      opt.value = a.name;
      opt.textContent = a.name;
      distDefaultTargetSelect.appendChild(opt);
    }
  });
  if (Array.from(distDefaultTargetSelect.options).some((o) => o.value === prev)) {
    distDefaultTargetSelect.value = prev;
  } else {
    distDefaultTargetSelect.value = "spread";
  }
}

openDistSettingsBtn.addEventListener("click", () => {
  distR2WorkerInput.value = currentDistConfig.r2WorkerUrl || "";
  distQueuePathInput.value = currentDistConfig.queuePath || "wallpaperQueue";
  renderDistAccountsEditor();
  distSettingsModal.classList.remove("hidden");
});

function closeDistSettingsModal() {
  distSettingsModal.classList.add("hidden");
}

distSettingsBackdrop.addEventListener("click", closeDistSettingsModal);
closeDistSettingsBtn.addEventListener("click", closeDistSettingsModal);

addDistAccountBtn.addEventListener("click", () => {
  currentDistConfig.accounts = readDistAccountsFromDOM();
  currentDistConfig.accounts.push({
    name: `zedge_${currentDistConfig.accounts.length + 1}`,
    dbUrl: "",
    secret: ""
  });
  renderDistAccountsEditor();
});

saveDistSettingsBtn.addEventListener("click", async () => {
  const accounts = readDistAccountsFromDOM().filter((a) => a.name && a.dbUrl);
  currentDistConfig = {
    r2WorkerUrl: distR2WorkerInput.value.trim(),
    queuePath: distQueuePathInput.value.trim() || "wallpaperQueue",
    accounts,
    defaultTarget: distDefaultTargetSelect.value || "spread",
    spreadPool: accounts.map((a) => a.name)
  };
  await chrome.storage.local.set({ distConfig: currentDistConfig });
  distTestStatusBox.className = "dist-test-status ok";
  distTestStatusBox.textContent = `Saved ${accounts.length} account(s) & R2 Worker configuration.`;
  const { history = [] } = await chrome.storage.local.get("history");
  renderGallery(history);
  setTimeout(closeDistSettingsModal, 500);
});

// ============================================================================
// IMPORT LOCAL SET TO STUDIO PANEL MODAL LOGIC
// ============================================================================

openImportSetModalBtn.addEventListener("click", () => {
  pendingImportFiles = [];
  importSetFilesInput.value = "";
  importSelectedCountText.textContent = "No files selected yet";
  importSetModal.classList.remove("hidden");
});

function closeImportSetModal() {
  importSetModal.classList.add("hidden");
}

importSetBackdrop.addEventListener("click", closeImportSetModal);
closeImportSetModalBtn.addEventListener("click", closeImportSetModal);

importDropzone.addEventListener("click", () => importSetFilesInput.click());

async function handleSelectedImportFiles(fileList) {
  if (!fileList || fileList.length === 0) return;
  const arr = Array.from(fileList);
  pendingImportFiles = [];
  for (const f of arr) {
    const dataUrl = await new Promise((resolve) => {
      const r = new FileReader();
      r.onload = () => resolve(r.result);
      r.readAsDataURL(f);
    });
    pendingImportFiles.push({ dataUrl, filename: f.name });
  }
  importSelectedCountText.textContent = `${pendingImportFiles.length} image file(s) ready: ${pendingImportFiles.map((f) => f.filename).join(", ")}`;
  if (pendingImportFiles.length === 2) importSetModeSelect.value = "set_dual";
  if (pendingImportFiles.length === 4) importSetModeSelect.value = "set_24h";
  if (pendingImportFiles.length >= 6) importSetModeSelect.value = "set_battery";
}

importSetFilesInput.addEventListener("change", (e) => {
  handleSelectedImportFiles(e.target.files);
});

importDropzone.addEventListener("dragover", (e) => {
  e.preventDefault();
  importDropzone.classList.add("dragover");
});

importDropzone.addEventListener("dragleave", () => {
  importDropzone.classList.remove("dragover");
});

importDropzone.addEventListener("drop", (e) => {
  e.preventDefault();
  importDropzone.classList.remove("dragover");
  handleSelectedImportFiles(e.dataTransfer && e.dataTransfer.files);
});

runImportSetBtn.addEventListener("click", () => {
  if (pendingImportFiles.length === 0) {
    showStatus("Please select 2, 4, or 6 images to import into the Studio Panel.", "error", false);
    return;
  }
  runImportSetBtn.disabled = true;
  runImportSetBtn.innerHTML = `<span class="spinner spinner-sm"></span><span>Importing &amp; Formatting...</span>`;

  chrome.runtime.sendMessage(
    {
      type: "IMPORT_LOCAL_SET_TO_STUDIO",
      options: {
        files: pendingImportFiles,
        workflowMode: importSetModeSelect.value,
        prompt: importSetPromptInput.value.trim(),
        upscaleEnabled: importUpscaleToggle.checked,
        autoWriteMetadata: importAutoMetaToggle.checked,
        subfolder: subfolderInput.value.trim(),
        portraitWidth: parseInt(portraitWidthInput.value, 10) || 1620,
        portraitHeight: parseInt(portraitHeightInput.value, 10) || 2880
      }
    },
    async (res) => {
      runImportSetBtn.disabled = false;
      runImportSetBtn.innerHTML = `${icon("upload", "icon icon-sm")}<span>Import Set &amp; Generate Metadata</span>`;
      if (res && res.ok) {
        closeImportSetModal();
        const { history = [] } = await chrome.storage.local.get("history");
        renderGallery(history);
      } else {
        showStatus(res ? res.error : "Import failed.", "error", false);
      }
    }
  );
});

// ============================================================================
// EDIT METADATA MODAL LOGIC
// ============================================================================

function openEditMetadataModal(item) {
  activeEditingMetaEntryId = item.id;
  const m = item.metadata || {};
  editMetaTitleInput.value = m.title || "";
  editMetaCategorySelect.value = ZEDGE_CATEGORIES.includes(m.category) ? m.category : "DESIGNS";
  editMetaTagsInput.value = Array.isArray(m.tags) ? m.tags.join(", ") : m.keywords || "";
  editMetaDescInput.value = m.description || "";
  editMetaModal.classList.remove("hidden");
}

function closeEditMetadataModal() {
  editMetaModal.classList.add("hidden");
  activeEditingMetaEntryId = null;
}

editMetaBackdrop.addEventListener("click", closeEditMetadataModal);
closeEditMetaBtn.addEventListener("click", closeEditMetadataModal);

saveEditMetaBtn.addEventListener("click", () => {
  if (!activeEditingMetaEntryId) return;
  const tags = editMetaTagsInput.value
    .split(",")
    .map((t) => t.trim().toLowerCase().replace(/[^a-z0-9]/g, ""))
    .filter(Boolean)
    .slice(0, 12);

  chrome.runtime.sendMessage(
    {
      type: "GENERATE_SET_METADATA",
      options: {
        entryId: activeEditingMetaEntryId,
        customMetadata: {
          title: editMetaTitleInput.value.trim().slice(0, 30),
          category: editMetaCategorySelect.value,
          tags,
          keywords: tags.join(", "),
          description: editMetaDescInput.value.trim().slice(0, 200)
        }
      }
    },
    async (res) => {
      closeEditMetadataModal();
      if (res && res.ok) {
        const { history = [] } = await chrome.storage.local.get("history");
        renderGallery(history);
        showStatus("Updated set metadata (metadata.json).", "success", false);
      }
    }
  );
});

// ============================================================================
// LIGHTBOX & PHONE SCREEN SIMULATOR
// ============================================================================

function openLightbox({ img, prompt, isLandscape, onDownload }) {
  const w = img.width || (isLandscape ? 2800 : 1620);
  const h = img.height || (isLandscape ? 2400 : 2880);
  lightboxImg.src = img.previewDataUrl || img.hdUrl;
  lightboxBadge.className = `output-role-badge${isLandscape ? " landscape" : ""}`;
  lightboxBadge.textContent = img.badge || img.label || (isLandscape ? "Landscape Wallpaper" : "9:16 Portrait");
  lightboxTitle.textContent = `${img.exactFilename ? img.exactFilename + " — " : ""}${w} × ${h} px JPG`;
  lightboxMeta.textContent = `${img.upscaledViaCloudinary ? "Cloudinary AI Upscaled • " : ""}${formatBytes(img.byteSize)} (≤8MB Verified)`;
  lightboxDownloadBtn.innerHTML = `${icon("download", "icon icon-sm")}<span>Download ${img.exactFilename || `${w}×${h} JPG`}</span>`;
  activeLightboxDownloadHandler = onDownload;
  lightboxModal.classList.remove("hidden");
}

function closeLightbox() {
  lightboxModal.classList.add("hidden");
  lightboxImg.src = "";
  activeLightboxDownloadHandler = null;
}

lightboxBackdrop.addEventListener("click", closeLightbox);
lightboxCloseBtn.addEventListener("click", closeLightbox);
lightboxDownloadBtn.addEventListener("click", () => {
  if (typeof activeLightboxDownloadHandler === "function") {
    activeLightboxDownloadHandler();
  }
});

function stopSimulatorAutoPlay() {
  if (simAutoPlayTimer) {
    clearInterval(simAutoPlayTimer);
    simAutoPlayTimer = null;
  }
  simAutoPlayBtn.innerHTML = `${icon("play", "icon icon-sm")}<span>Auto-Cycle States</span>`;
}

function selectSimulatorState(index) {
  if (!simActiveImages || simActiveImages.length === 0) return;
  simActiveIndex = ((index % simActiveImages.length) + simActiveImages.length) % simActiveImages.length;
  const img = simActiveImages[simActiveIndex];
  const w = img.width || 1620;
  const h = img.height || 2880;
  const mp = ((w * h) / 1000000).toFixed(2);

  simMainImg.src = img.previewDataUrl || img.hdUrl;
  simActiveStateBadge.textContent = img.badge || img.label || `State ${simActiveIndex + 1}`;
  simActiveFilename.textContent = img.exactFilename || img.filename || `state_${simActiveIndex + 1}.jpg`;
  simActiveSpecs.textContent = `${w} × ${h} px • JPEG • ${formatBytes(img.byteSize)} • ${mp} MP (Zedge Compliant)`;

  const isHomeScreen = img.role === "dual_home";
  simClockWidget.classList.toggle("hidden", isHomeScreen);
  simHomeIcons.classList.toggle("hidden", !isHomeScreen);

  if (simActiveWorkflowMode === "set_24h") {
    const times = ["06:45", "13:15", "18:30", "23:10"];
    const labels = ["Morning • সকাল", "Afternoon • দুপুর", "Evening • সন্ধ্যা", "Night • রাত"];
    const t = times[simActiveIndex] || "09:41";
    simStatusTime.textContent = t;
    simBigClock.textContent = t;
    simSubLabel.textContent = labels[simActiveIndex] || "24-Hour Dynamic Wallpaper";
    simStatusRight.textContent = "24H Auto";
  } else if (simActiveWorkflowMode === "set_battery") {
    const pcts = ["0% Critical", "20% Low", "40% Mid", "60% High", "80% Full", "100% Charging"];
    const sub = pcts[simActiveIndex] || "100%";
    simStatusTime.textContent = "09:41";
    simBigClock.textContent = "09:41";
    simSubLabel.textContent = `Battery State: ${sub}`;
    simStatusRight.textContent = sub;
  } else {
    simStatusTime.textContent = "09:41";
    simBigClock.textContent = "09:41";
    simSubLabel.textContent = isHomeScreen ? "Home Screen Companion" : "Lock Screen Wallpaper";
    simStatusRight.textContent = isHomeScreen ? "Home" : "Locked";
  }

  const allBtns = simStateButtons.querySelectorAll(".sim-state-btn");
  allBtns.forEach((b, idx) => {
    b.classList.toggle("active", idx === simActiveIndex);
  });
}

function openSetSimulator(item) {
  stopSimulatorAutoPlay();
  simActiveImages = item.images || [];
  simActiveWorkflowMode = item.workflowMode || "set_dual";
  if (simActiveImages.length === 0) return;

  simModeBadge.textContent = item.setTypeLabel || "Wallpaper Set Simulator";
  simTitle.textContent = item.prompt || "Set Continuity & Transition Preview";

  simStateButtons.innerHTML = "";
  simActiveImages.forEach((img, idx) => {
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = `sim-state-btn${idx === 0 ? " active" : ""}`;
    btn.innerHTML = `
      <img class="sim-state-thumb" src="${img.previewDataUrl || img.hdUrl}" alt="${img.label || ""}" />
      <div class="sim-state-meta">
        <span class="sim-state-name">${img.badge || img.label || `State ${idx + 1}`}</span>
        <span class="sim-state-file">${img.exactFilename || `image_${idx + 1}.jpg`}</span>
      </div>
    `;
    btn.addEventListener("click", () => {
      stopSimulatorAutoPlay();
      selectSimulatorState(idx);
    });
    simStateButtons.appendChild(btn);
  });

  selectSimulatorState(0);
  simulatorModal.classList.remove("hidden");
}

function closeSetSimulator() {
  stopSimulatorAutoPlay();
  simulatorModal.classList.add("hidden");
  simMainImg.src = "";
}

simulatorBackdrop.addEventListener("click", closeSetSimulator);
simCloseBtn.addEventListener("click", closeSetSimulator);

simShowOverlay.addEventListener("change", () => {
  simPhoneOverlay.classList.toggle("hidden", !simShowOverlay.checked);
});

simShowFocalCrosshair.addEventListener("change", () => {
  simCenterGuide.classList.toggle("hidden", !simShowFocalCrosshair.checked);
});

simAutoPlayBtn.addEventListener("click", () => {
  if (simAutoPlayTimer) {
    stopSimulatorAutoPlay();
  } else {
    simAutoPlayBtn.innerHTML = `${icon("pause", "icon icon-sm")}<span>Pause Cycle</span>`;
    simAutoPlayTimer = setInterval(() => {
      selectSimulatorState(simActiveIndex + 1);
    }, 1500);
  }
});

document.addEventListener("keydown", (e) => {
  if (e.key === "Escape") {
    if (!lightboxModal.classList.contains("hidden")) closeLightbox();
    if (!simulatorModal.classList.contains("hidden")) closeSetSimulator();
    if (!distSettingsModal.classList.contains("hidden")) closeDistSettingsModal();
    if (!importSetModal.classList.contains("hidden")) closeImportSetModal();
    if (!editMetaModal.classList.contains("hidden")) closeEditMetadataModal();
  }
});

// ============================================================================
// DOWNLOADS, READY ZIP, METADATA.JSON & PANEL UPLOAD ACTIONS
// ============================================================================

async function triggerSingleCardDownload(img, itemPrompt, setFolderName, buttonEl) {
  const isLandscape = img.role === "landscape" || (img.width && img.height && img.width > img.height);
  const w = img.width || (isLandscape ? 2800 : 1620);
  const h = img.height || (isLandscape ? 2400 : 2880);
  const displayFile = img.exactFilename || `${w}×${h} JPG`;

  if (buttonEl) {
    buttonEl.disabled = true;
    buttonEl.innerHTML = `<span class="spinner spinner-sm"></span><span>Saving JPG...</span>`;
  }

  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      {
        type: "DOWNLOAD_PREPARED_IMAGE",
        assetId: img.assetId || null,
        filename: img.filename || null,
        exactFilename: img.exactFilename || null,
        setFolderName: setFolderName || null,
        useExactZedgeNames: useExactZedgeNamesCheckbox.checked,
        url: img.hdUrl || null,
        previewDataUrl: img.previewDataUrl || null,
        prompt: itemPrompt,
        subfolder: subfolderInput.value.trim(),
        targetWidth: w,
        targetHeight: h,
        role: img.role || (isLandscape ? "landscape" : "portrait"),
        upscaleEnabled: upscaleEnabledCheckbox.checked
      },
      async (res) => {
        if (buttonEl) {
          buttonEl.disabled = false;
        }
        if (res && res.ok) {
          if (buttonEl) {
            buttonEl.classList.add("downloaded");
            buttonEl.innerHTML = `${icon("check-circle", "icon icon-sm")}<span>Saved JPG (${formatBytes(img.byteSize)})</span>`;
          }
          showStatus(
            `Downloaded ${res.result ? res.result.filename : displayFile} (≤8MB JPG)!`,
            "success",
            false,
            4
          );
          resolve(true);
        } else {
          if (buttonEl) {
            buttonEl.innerHTML = `${icon("download", "icon icon-sm")}<span>Download JPG (${formatBytes(img.byteSize)})</span>`;
          }
          showStatus(res ? res.error : "Download failed.", "error", false);
          resolve(false);
        }
      }
    );
  });
}

async function triggerReadyZipDownload(entries, zipFilename, buttonEl) {
  if (!entries || entries.length === 0) return;

  const originalHtml = buttonEl ? buttonEl.innerHTML : "";
  if (buttonEl) {
    buttonEl.disabled = true;
    buttonEl.innerHTML = `<span class="spinner spinner-sm"></span><span>Packing ZIP...</span>`;
  }

  chrome.runtime.sendMessage(
    {
      type: "DOWNLOAD_READY_ZIP",
      options: {
        entries,
        zipFilename,
        subfolder: subfolderInput.value.trim(),
        useHubSetFolders: useHubSetFoldersCheckbox.checked,
        upscaleEnabled: upscaleEnabledCheckbox.checked
      }
    },
    (res) => {
      if (buttonEl) {
        buttonEl.disabled = false;
      }
      if (res && res.ok) {
        if (buttonEl) {
          buttonEl.innerHTML = `${icon("check-circle", "icon icon-sm")}<span>ZIP saved</span>`;
        }
        showStatus(
          `Downloaded Ready ZIP (${res.result.filename}) with set folder(s) + metadata.json!`,
          "success",
          false,
          4
        );
      } else {
        if (buttonEl) buttonEl.innerHTML = originalHtml;
        showStatus(res ? res.error : "Ready ZIP download failed.", "error", false);
      }
    }
  );
}

async function triggerGenerateMetadataForEntry(item, buttonEl) {
  const originalHtml = buttonEl ? buttonEl.innerHTML : "";
  if (buttonEl) {
    buttonEl.disabled = true;
    buttonEl.innerHTML = `<span class="spinner spinner-sm"></span><span>Writing AI Meta...</span>`;
  }

  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      {
        type: "GENERATE_SET_METADATA",
        options: { entryId: item.id }
      },
      async (res) => {
        if (buttonEl) {
          buttonEl.disabled = false;
          buttonEl.innerHTML = originalHtml;
        }
        if (res && res.ok) {
          const { history = [] } = await chrome.storage.local.get("history");
          renderGallery(history);
          resolve(true);
        } else {
          showStatus(res ? res.error : "Failed to generate metadata.", "error", false);
          resolve(false);
        }
      }
    );
  });
}

async function triggerUploadSetToPanel(item, targetAccount, buttonEl) {
  if (
    !currentDistConfig ||
    !currentDistConfig.r2WorkerUrl ||
    !Array.isArray(currentDistConfig.accounts) ||
    currentDistConfig.accounts.length === 0
  ) {
    openDistSettingsBtn.click();
    showStatus("Configure your R2 Worker URL & Firebase Database account(s) first.", "error", false);
    return false;
  }

  const originalHtml = buttonEl ? buttonEl.innerHTML : "";
  if (buttonEl) {
    buttonEl.disabled = true;
    buttonEl.innerHTML = `<span class="spinner spinner-sm"></span><span>Uploading...</span>`;
  }

  return new Promise((resolve) => {
    chrome.runtime.sendMessage(
      {
        type: "UPLOAD_SET_TO_PANEL",
        options: {
          entryId: item.id,
          targetAccount: targetAccount || currentDistConfig.defaultTarget || "spread"
        }
      },
      async (res) => {
        if (buttonEl) {
          buttonEl.disabled = false;
        }
        if (res && res.ok) {
          if (buttonEl) {
            buttonEl.innerHTML = `${icon("check-circle", "icon icon-sm")}<span>Uploaded (${res.accountName})</span>`;
          }
          const { history = [] } = await chrome.storage.local.get("history");
          renderGallery(history);
          resolve(true);
        } else {
          if (buttonEl) buttonEl.innerHTML = originalHtml;
          showStatus(res ? res.error : "Panel upload failed.", "error", false);
          resolve(false);
        }
      }
    );
  });
}

// Batch Results Toolbar Listeners
writeAllMetadataBtn.addEventListener("click", async () => {
  const { history = [] } = await chrome.storage.local.get("history");
  if (history.length === 0) {
    showStatus("No sets in showcase yet.", "error", false);
    return;
  }
  writeAllMetadataBtn.disabled = true;
  for (let i = 0; i < history.length; i++) {
    showStatus(`Writing AI Metadata [${i + 1}/${history.length}]...`, "info", true, 4);
    await triggerGenerateMetadataForEntry(history[i], null);
  }
  writeAllMetadataBtn.disabled = false;
  showStatus(`AI Metadata written for all ${history.length} set(s)!`, "success", false, 4);
});

downloadAllReadyZipBtn.addEventListener("click", async () => {
  const { history = [] } = await chrome.storage.local.get("history");
  if (history.length === 0) {
    showStatus("No sets in showcase to export.", "error", false);
    return;
  }
  triggerReadyZipDownload(
    history,
    `ai-studio-sets-${Date.now()}.zip`,
    downloadAllReadyZipBtn
  );
});

downloadAllMetaJsonBtn.addEventListener("click", async () => {
  const { history = [] } = await chrome.storage.local.get("history");
  if (history.length === 0) {
    showStatus("No sets in showcase to export metadata.json.", "error", false);
    return;
  }
  chrome.runtime.sendMessage({
    type: "DOWNLOAD_METADATA_JSON",
    options: {
      entries: history,
      subfolder: subfolderInput.value.trim(),
      filename: "metadata.json"
    }
  });
});

uploadAllToPanelBtn.addEventListener("click", async () => {
  const { history = [] } = await chrome.storage.local.get("history");
  if (history.length === 0) {
    showStatus("No sets in showcase to upload.", "error", false);
    return;
  }
  if (
    !currentDistConfig ||
    !currentDistConfig.r2WorkerUrl ||
    !Array.isArray(currentDistConfig.accounts) ||
    currentDistConfig.accounts.length === 0
  ) {
    openDistSettingsBtn.click();
    showStatus("Configure your R2 Worker URL & Firebase Database account(s) first.", "error", false);
    return;
  }
  uploadAllToPanelBtn.disabled = true;
  for (let i = 0; i < history.length; i++) {
    await triggerUploadSetToPanel(history[i], "spread", null);
  }
  uploadAllToPanelBtn.disabled = false;
});

async function triggerRegenerateSingleStage(item, img, buttonEl) {
  if (buttonEl) {
    buttonEl.disabled = true;
    buttonEl.innerHTML = `<span class="spinner spinner-sm"></span><span>Wait...</span>`;
  }

  chrome.runtime.sendMessage(
    {
      type: "REGENERATE_SET_STAGE",
      options: {
        entryId: item.id,
        slotIndex: img.slotIndex,
        stageKey: img.stageKey,
        customStagePrompt: img.stagePrompt,
        upscaleEnabled: upscaleEnabledCheckbox.checked,
        subfolder: subfolderInput.value.trim()
      }
    },
    async (res) => {
      if (buttonEl) {
        buttonEl.disabled = false;
        buttonEl.innerHTML = `${icon("refresh", "icon icon-sm")}<span>Regenerate</span>`;
      }
      if (res && res.ok) {
        const { history = [] } = await chrome.storage.local.get("history");
        renderGallery(history);
      } else {
        showStatus(res ? res.error : "Failed to regenerate state.", "error", false);
      }
    }
  );
}

// ============================================================================
// RENDER GALLERY & SET METADATA CARDS
// ============================================================================

function buildSetMetadataCard(item) {
  const metaBox = document.createElement("div");
  metaBox.className = "set-metadata-card";
  const m = item.metadata;

  if (!m || (!m.title && (!m.tags || m.tags.length === 0))) {
    const emptyRow = document.createElement("div");
    emptyRow.className = "meta-top-row";
    emptyRow.innerHTML = `<span class="meta-desc-text">No Zedge/Hub listing metadata generated for this set yet.</span>`;

    const actRow = document.createElement("div");
    actRow.className = "meta-actions-row";

    const genBtn = document.createElement("button");
    genBtn.type = "button";
    genBtn.className = "btn-meta-action";
    genBtn.innerHTML = `${icon("sparkles", "icon icon-xs")}<span>Generate AI Metadata (metadata.json)</span>`;
    genBtn.addEventListener("click", () => triggerGenerateMetadataForEntry(item, genBtn));

    const manualBtn = document.createElement("button");
    manualBtn.type = "button";
    manualBtn.className = "btn-meta-action";
    manualBtn.innerHTML = `${icon("edit", "icon icon-xs")}<span>Edit Manually</span>`;
    manualBtn.addEventListener("click", () => openEditMetadataModal(item));

    actRow.appendChild(genBtn);
    actRow.appendChild(manualBtn);
    emptyRow.appendChild(actRow);
    metaBox.appendChild(emptyRow);
    return metaBox;
  }

  const topRow = document.createElement("div");
  topRow.className = "meta-top-row";

  const titleGroup = document.createElement("div");
  titleGroup.className = "meta-title-group";

  const titleEl = document.createElement("span");
  titleEl.className = "meta-title-text";
  titleEl.textContent = m.title || "Untitled Set";
  titleGroup.appendChild(titleEl);

  if (m.category) {
    const catPill = document.createElement("span");
    catPill.className = "meta-category-pill";
    catPill.textContent = m.category;
    titleGroup.appendChild(catPill);
  }

  if (item.uploadedToPanel && item.uploadedToPanel.accountName) {
    const upPill = document.createElement("span");
    upPill.className = "meta-uploaded-pill";
    upPill.textContent = `Queued on ${item.uploadedToPanel.accountName}`;
    titleGroup.appendChild(upPill);
  }

  const actionsRow = document.createElement("div");
  actionsRow.className = "meta-actions-row";

  const copyTitleBtn = document.createElement("button");
  copyTitleBtn.type = "button";
  copyTitleBtn.className = "btn-meta-action";
  copyTitleBtn.innerHTML = `${icon("copy", "icon icon-xs")}<span>Copy Title</span>`;
  copyTitleBtn.addEventListener("click", () => copyTextToClipboard(m.title, "Title"));

  const tagsCsv = Array.isArray(m.tags) ? m.tags.join(", ") : m.keywords || "";
  const copyTagsBtn = document.createElement("button");
  copyTagsBtn.type = "button";
  copyTagsBtn.className = "btn-meta-action";
  copyTagsBtn.innerHTML = `${icon("tag", "icon icon-xs")}<span>Copy Tags CSV</span>`;
  copyTagsBtn.addEventListener("click", () => copyTextToClipboard(tagsCsv, "Search Tags CSV"));

  const editBtn = document.createElement("button");
  editBtn.type = "button";
  editBtn.className = "btn-meta-action";
  editBtn.innerHTML = `${icon("edit", "icon icon-xs")}<span>Edit</span>`;
  editBtn.addEventListener("click", () => openEditMetadataModal(item));

  const rewriteBtn = document.createElement("button");
  rewriteBtn.type = "button";
  rewriteBtn.className = "btn-meta-action";
  rewriteBtn.innerHTML = `${icon("sparkles", "icon icon-xs")}<span>Rewrite AI</span>`;
  rewriteBtn.addEventListener("click", () => triggerGenerateMetadataForEntry(item, rewriteBtn));

  const jsonBtn = document.createElement("button");
  jsonBtn.type = "button";
  jsonBtn.className = "btn-meta-action";
  jsonBtn.innerHTML = `${icon("code", "icon icon-xs")}<span>metadata.json</span>`;
  jsonBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({
      type: "DOWNLOAD_METADATA_JSON",
      options: {
        entries: [item],
        subfolder: subfolderInput.value.trim(),
        filename: `${(item.setFolderName || "set").slice(0, 32)}_metadata.json`
      }
    });
  });

  actionsRow.appendChild(copyTitleBtn);
  actionsRow.appendChild(copyTagsBtn);
  actionsRow.appendChild(editBtn);
  actionsRow.appendChild(rewriteBtn);
  actionsRow.appendChild(jsonBtn);

  topRow.appendChild(titleGroup);
  topRow.appendChild(actionsRow);
  metaBox.appendChild(topRow);

  if (m.description) {
    const descEl = document.createElement("div");
    descEl.className = "meta-desc-text";
    descEl.textContent = m.description;
    metaBox.appendChild(descEl);
  }

  if (Array.isArray(m.tags) && m.tags.length > 0) {
    const tagsWrap = document.createElement("div");
    tagsWrap.className = "meta-tags-wrap";
    m.tags.forEach((t) => {
      const chip = document.createElement("span");
      chip.className = "meta-tag-chip";
      chip.textContent = `#${t}`;
      tagsWrap.appendChild(chip);
    });
    metaBox.appendChild(tagsWrap);
  }

  return metaBox;
}

function renderGallery(history) {
  gallery.innerHTML = "";
  if (!history || history.length === 0) {
    const empty = document.createElement("div");
    empty.className = "empty-state";
    empty.innerHTML = `${icon("image", "icon icon-xl empty-icon")}<strong>No generated or imported wallpaper sets in your showcase yet.</strong><br/>Choose <strong>Dual Set (2)</strong>, <strong>24-Hour Set (4)</strong>, or <strong>Battery Level Set (6)</strong> on the left — or click <strong>Import Local Set</strong> in the top bar to load existing images for AI Metadata, Ready <code>.ZIP</code> + <code>metadata.json</code> packaging, and direct Panel Upload.`;
    gallery.appendChild(empty);
    return;
  }

  history.forEach((item, groupIndex) => {
    const groupCard = document.createElement("div");
    groupCard.className = `batch-group-card${groupIndex === 0 ? " latest-featured" : ""}`;

    const header = document.createElement("div");
    header.className = "batch-group-header";

    const topRow = document.createElement("div");
    topRow.className = "batch-header-top-row";

    const badgesRow = document.createElement("div");
    badgesRow.className = "batch-badges-row";

    if (groupIndex === 0) {
      const latestPill = document.createElement("span");
      latestPill.className = "latest-pill";
      latestPill.innerHTML = `${icon("sparkles", "icon icon-xs")}<span>Latest</span>`;
      badgesRow.appendChild(latestPill);
    }

    if (item.setTypeLabel) {
      const setPill = document.createElement("span");
      setPill.className = "set-type-pill";
      setPill.textContent = item.setTypeLabel;
      badgesRow.appendChild(setPill);
    }

    const timeEl = document.createElement("span");
    timeEl.className = "batch-timestamp";
    const timeStr = item.createdAt
      ? new Date(item.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
      : "";
    timeEl.textContent = `${timeStr ? timeStr + " • " : ""}${(item.images || []).length} JPEGs • ≤8MB Verified`;
    badgesRow.appendChild(timeEl);

    const headerActions = document.createElement("div");
    headerActions.className = "group-header-actions";
    const cardDownloadButtons = [];

    if (item.images && item.images.length > 0) {
      if (item.images.length > 1) {
        const simBtn = document.createElement("button");
        simBtn.type = "button";
        simBtn.className = "btn-simulate-set";
        simBtn.innerHTML = `${icon("smartphone", "icon icon-sm")}<span>Simulate</span>`;
        simBtn.addEventListener("click", () => openSetSimulator(item));
        headerActions.appendChild(simBtn);
      }

      const zipBtn = document.createElement("button");
      zipBtn.type = "button";
      zipBtn.className = "btn-zip-set";
      zipBtn.innerHTML = `${icon("archive", "icon icon-sm")}<span>Ready ZIP</span>`;
      zipBtn.addEventListener("click", () => {
        const safeSlug =
          (item.metadata && item.metadata.title ? item.metadata.title : item.prompt || "set")
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, "-")
            .replace(/^-+|-+$/g, "")
            .slice(0, 28) || "set";
        triggerReadyZipDownload([item], `ready-${safeSlug}.zip`, zipBtn);
      });
      headerActions.appendChild(zipBtn);

      const uploadGroup = document.createElement("div");
      uploadGroup.className = "panel-upload-group";

      const targetSelect = document.createElement("select");
      targetSelect.className = "panel-target-select";
      targetSelect.title = "Choose target Firebase account or Spread rotation";
      const spreadOpt = document.createElement("option");
      spreadOpt.value = "spread";
      spreadOpt.textContent = "Spread (Auto)";
      targetSelect.appendChild(spreadOpt);
      (currentDistConfig.accounts || []).forEach((acc) => {
        if (acc.name) {
          const opt = document.createElement("option");
          opt.value = acc.name;
          opt.textContent = acc.name;
          targetSelect.appendChild(opt);
        }
      });
      if (currentDistConfig.defaultTarget) {
        targetSelect.value = currentDistConfig.defaultTarget;
      }

      const uploadPanelBtn = document.createElement("button");
      uploadPanelBtn.type = "button";
      uploadPanelBtn.className = "btn-upload-panel";
      uploadPanelBtn.innerHTML =
        item.uploadedToPanel && item.uploadedToPanel.accountName
          ? `${icon("check-circle", "icon icon-sm")}<span>Re-Upload (${item.uploadedToPanel.accountName})</span>`
          : `${icon("cloud-upload", "icon icon-sm")}<span>Upload to Panel</span>`;
      uploadPanelBtn.addEventListener("click", () => {
        triggerUploadSetToPanel(item, targetSelect.value, uploadPanelBtn);
      });

      uploadGroup.appendChild(targetSelect);
      uploadGroup.appendChild(uploadPanelBtn);
      headerActions.appendChild(uploadGroup);

      if (item.images.length > 1) {
        const downloadAllBtn = document.createElement("button");
        downloadAllBtn.type = "button";
        downloadAllBtn.className = "btn-download-both";
        downloadAllBtn.innerHTML = `${icon("download", "icon icon-sm")}<span>Save JPGs (${item.images.length})</span>`;
        downloadAllBtn.addEventListener("click", async () => {
          downloadAllBtn.disabled = true;
          downloadAllBtn.innerHTML = `<span class="spinner spinner-sm"></span><span>Saving...</span>`;
          for (let idx = 0; idx < item.images.length; idx++) {
            await triggerSingleCardDownload(
              item.images[idx],
              item.prompt,
              item.setFolderName,
              cardDownloadButtons[idx]
            );
          }
          downloadAllBtn.disabled = false;
          downloadAllBtn.innerHTML = `${icon("check-circle", "icon icon-sm")}<span>Saved (${item.images.length})</span>`;
        });
        headerActions.appendChild(downloadAllBtn);
      }
    }

    topRow.appendChild(badgesRow);
    topRow.appendChild(headerActions);

    const title = document.createElement("div");
    title.className = "batch-prompt-title";
    title.title = item.prompt || "";
    title.textContent = item.prompt;

    header.appendChild(topRow);
    header.appendChild(title);
    groupCard.appendChild(header);

    groupCard.appendChild(buildSetMetadataCard(item));

    const imgList = item.images || [];
    const pairGrid = document.createElement("div");
    pairGrid.className = `pair-grid${imgList.length >= 6 ? " grid-6" : ""}`;

    for (const img of imgList) {
      const card = document.createElement("div");
      card.className = "showcase-card";

      const isLandscape = img.role === "landscape" || (img.width && img.height && img.width > img.height);
      const isCharging = img.role === "battery_charging";
      const w = img.width || (isLandscape ? 2800 : 1620);
      const h = img.height || (isLandscape ? 2400 : 2880);
      const mp = img.megapixels || ((w * h) / 1000000).toFixed(2);
      const exactFile = img.exactFilename || (img.filename ? img.filename.split("/").pop() : `${w}x${h}.jpg`);

      const mediaWrap = document.createElement("div");
      mediaWrap.className = "showcase-media-wrap";

      const thumb = document.createElement("img");
      thumb.className = "showcase-img";
      thumb.src = img.previewDataUrl || img.hdUrl;
      thumb.alt = img.label || item.prompt;

      const overlayTop = document.createElement("div");
      overlayTop.className = "media-overlay-top";

      const badge = document.createElement("span");
      badge.className = `output-role-badge${isLandscape ? " landscape" : ""}${isCharging ? " charging" : ""}`;
      badge.textContent = img.badge || img.label || (isLandscape ? "Landscape Wallpaper" : "9:16 Portrait");

      const upscalePill = document.createElement("span");
      upscalePill.className = "upscale-status-pill";
      upscalePill.innerHTML = img.upscaledViaCloudinary
        ? `${icon("maximize", "icon icon-xs")}<span>AI Upscaled</span>`
        : `${icon("image", "icon icon-xs")}<span>HD Sampled</span>`;

      overlayTop.appendChild(badge);
      overlayTop.appendChild(upscalePill);

      const inspectHint = document.createElement("span");
      inspectHint.className = "inspect-hint-pill";
      inspectHint.innerHTML = `${icon("search", "icon icon-xs")}<span>Click to Inspect</span>`;

      mediaWrap.appendChild(thumb);
      mediaWrap.appendChild(overlayTop);
      mediaWrap.appendChild(inspectHint);

      const body = document.createElement("div");
      body.className = "showcase-body";

      const fileBar = document.createElement("div");
      fileBar.className = "exact-filename-bar";
      fileBar.title = `${exactFile} (ZIP slot: set-01/${img.zipName || exactFile})`;
      fileBar.textContent = `${exactFile} • set-01/${img.zipName || exactFile}`;

      const specsRow = document.createElement("div");
      specsRow.className = "showcase-specs-row";

      const dims = document.createElement("div");
      dims.className = "output-dims";
      dims.textContent = `${w} × ${h} px`;

      const filesize = document.createElement("div");
      filesize.className = "output-filesize";
      filesize.textContent = formatBytes(img.byteSize);

      specsRow.appendChild(dims);
      specsRow.appendChild(filesize);

      const specTags = document.createElement("div");
      specTags.className = "spec-tags";

      const tagFormat = document.createElement("span");
      tagFormat.className = "spec-tag compliant";
      tagFormat.textContent = `JPEG • ≤8MB`;

      const tagMp = document.createElement("span");
      tagMp.className = "spec-tag";
      tagMp.textContent = `${mp} MP (<25MP)`;

      specTags.appendChild(tagFormat);
      specTags.appendChild(tagMp);

      const actions = document.createElement("div");
      actions.className = "showcase-actions";

      const saveBtn = document.createElement("button");
      saveBtn.className = `btn-card-primary${img.downloaded ? " downloaded" : ""}`;
      saveBtn.title = `Download ${exactFile}`;
      saveBtn.innerHTML = img.downloaded
        ? `${icon("check-circle", "icon icon-sm")}<span>Saved JPG (${formatBytes(img.byteSize)})</span>`
        : `${icon("download", "icon icon-sm")}<span>Download JPG (${formatBytes(img.byteSize)})</span>`;

      const handleDownloadClick = () =>
        triggerSingleCardDownload(img, item.prompt, item.setFolderName, saveBtn);
      saveBtn.addEventListener("click", handleDownloadClick);
      cardDownloadButtons.push(saveBtn);

      mediaWrap.addEventListener("click", () => {
        openLightbox({
          img,
          prompt: item.prompt,
          isLandscape,
          onDownload: handleDownloadClick
        });
      });

      const subActions = document.createElement("div");
      subActions.className = "showcase-sub-actions";

      const previewBtn = document.createElement("button");
      previewBtn.className = "btn-card-secondary";
      previewBtn.innerHTML = `${icon("eye", "icon icon-sm")}<span>Preview</span>`;
      previewBtn.addEventListener("click", () => {
        openLightbox({
          img,
          prompt: item.prompt,
          isLandscape,
          onDownload: handleDownloadClick
        });
      });
      subActions.appendChild(previewBtn);

      const regenBtn = document.createElement("button");
      regenBtn.className = "btn-card-secondary";
      regenBtn.innerHTML = `${icon("refresh", "icon icon-sm")}<span>Regenerate</span>`;
      regenBtn.title = "Regenerate just this state from the set anchor image";
      regenBtn.addEventListener("click", () => {
        triggerRegenerateSingleStage(item, img, regenBtn);
      });
      subActions.appendChild(regenBtn);

      if (img.previewDataUrl) {
        const useRefBtn = document.createElement("button");
        useRefBtn.className = "btn-card-secondary";
        useRefBtn.innerHTML = `${icon("image-plus", "icon icon-sm")}<span>Use Ref</span>`;
        useRefBtn.title = "Lock this image as the Anchor Reference Image";
        useRefBtn.addEventListener("click", () => {
          setReferenceImage(img.previewDataUrl, exactFile);
          window.scrollTo({ top: 0, behavior: "smooth" });
          showStatus(`Locked "${exactFile}" as Anchor Reference Image.`, "info", false);
        });
        subActions.appendChild(useRefBtn);
      }

      actions.appendChild(saveBtn);
      actions.appendChild(subActions);

      body.appendChild(fileBar);
      body.appendChild(specsRow);
      body.appendChild(specTags);
      body.appendChild(actions);

      card.appendChild(mediaWrap);
      card.appendChild(body);
      pairGrid.appendChild(card);
    }

    groupCard.appendChild(pairGrid);
    gallery.appendChild(groupCard);
  });
}

workflowModeSelect.addEventListener("change", async () => {
  const mode = workflowModeSelect.value;
  const { customStagesByMode = {} } = await chrome.storage.local.get("customStagesByMode");
  renderSetModeUI(mode, customStagesByMode[mode] || null);
  saveFormState();
});

negChipBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    const snippet = btn.getAttribute("data-neg");
    if (!snippet || !negativePromptInput) return;
    const current = negativePromptInput.value.trim();
    if (!current.toLowerCase().includes(snippet.toLowerCase())) {
      negativePromptInput.value = current ? `${current}, ${snippet}` : snippet;
      saveFormState();
      showStatus(`Added to Negative Prompts: "${snippet}"`, "info", false);
    }
  });
});

if (resetNegativePromptBtn && negativePromptInput) {
  resetNegativePromptBtn.addEventListener("click", () => {
    negativePromptInput.value = DEFAULT_NEGATIVE_PROMPT;
    saveFormState();
    showStatus("Reset Negative Prompts to default Zedge rules.", "info", false);
  });
}

foldSizeBtns.forEach((btn) => {
  btn.addEventListener("click", () => {
    const w = btn.getAttribute("data-w");
    const h = btn.getAttribute("data-h");
    if (w && h) {
      landscapeWidthInput.value = w;
      landscapeHeightInput.value = h;
      if (w === "2000" && h === "2000") {
        landscapePromptInput.value =
          "recompose this wallpaper into a square 1:1 foldable/tablet frame (2000x2000), keep the exact same subject, color palette, lighting and style, extend the background naturally without cropping the subject";
      } else if (landscapePromptInput.value.includes("1:1")) {
        landscapePromptInput.value =
          "make it landscape mode, re-frame the exact same artwork for foldable screen without cropping the main subject";
      }
      saveFormState();
    }
  });
});

[
  promptInput,
  negativePromptInput,
  includeFoldableCompanionCheckbox,
  landscapePromptInput,
  storyArcSelect,
  variationStrengthSelect,
  displayTargetSelect,
  colorBoostSelect,
  autoWriteMetadataCheckbox,
  aiDirectorEnabledCheckbox,
  useHubSetFoldersCheckbox,
  batchModeCheckbox,
  upscaleEnabledCheckbox,
  portraitWidthInput,
  portraitHeightInput,
  landscapeWidthInput,
  landscapeHeightInput,
  subfolderInput,
  useExactZedgeNamesCheckbox,
  forceImagePrefixCheckbox,
  autoDownloadCheckbox
].forEach((el) => {
  if (!el) return;
  el.addEventListener("input", () => {
    const pw = Math.max(1620, parseInt(portraitWidthInput.value, 10) || 1620);
    const ph = Math.max(2880, parseInt(portraitHeightInput.value, 10) || 2880);
    specStatusBadge.textContent = `JPG • ≤8MB • ${((pw * ph) / 1000000).toFixed(2)} MP`;
    saveFormState();
  });
  el.addEventListener("change", saveFormState);
});

function populateGeminiAccountsDropdown(accounts = [], selectedMode = "auto") {
  if (!geminiAccountSelect) return;
  geminiAccountSelect.innerHTML = "";

  const autoOpt = document.createElement("option");
  autoOpt.value = "auto";
  autoOpt.textContent =
    Array.isArray(accounts) && accounts.length > 1
      ? `Auto-switch on limit (${accounts.length} Gmails)`
      : "Auto-switch on limit";
  geminiAccountSelect.appendChild(autoOpt);

  const byIndex = new Map();
  if (Array.isArray(accounts)) {
    accounts.forEach((acc) => {
      if (acc && typeof acc.authUser === "number") {
        byIndex.set(acc.authUser, acc.email || `Account u/${acc.authUser}`);
      }
    });
  }

  for (let u = 0; u <= 5; u++) {
    const emailLabel = byIndex.get(u);
    if (!emailLabel && u > 4 && byIndex.size > 0) continue;
    const opt = document.createElement("option");
    opt.value = String(u);
    opt.textContent = emailLabel
      ? `u/${u} • ${emailLabel}`
      : u === 0
      ? "u/0 • Default Gmail"
      : `u/${u} • Gmail Account #${u + 1}`;
    geminiAccountSelect.appendChild(opt);
  }

  geminiAccountSelect.value = selectedMode || "auto";
  if (!geminiAccountSelect.value) {
    geminiAccountSelect.value = "auto";
  }
}

if (geminiAccountSelect) {
  geminiAccountSelect.addEventListener("change", () => {
    const mode = geminiAccountSelect.value || "auto";
    showStatus(
      mode === "auto"
        ? "Enabled Smart Auto-Switch: will automatically switch Gmail accounts if one hits its limit!"
        : `Switching to Gemini Account u/${mode}...`,
      "info",
      true,
      1
    );
    if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({ type: "SWITCH_GEMINI_ACCOUNT", accountMode: mode }, (res) => {
        if (res && res.ok) {
          const shortEmail = res.email || `u/${res.authUser}`;
          sessionIndicator.textContent = `u/${res.authUser}: ${shortEmail.split("@")[0]}`;
          sessionIndicator.title = `${res.email} (${res.bl})`;
          sessionIndicator.classList.add("ok");
          showStatus(
            mode === "auto"
              ? `Auto-Switch Active! Current primary account: u/${res.authUser} (${res.email})`
              : `Switched to Gemini Account u/${res.authUser} (${res.email})!`,
            "success",
            false,
            4
          );
        } else {
          sessionIndicator.textContent = `u/${mode}: Not Signed In`;
          sessionIndicator.classList.remove("ok");
          showStatus(
            res && res.error
              ? res.error
              : `Account u/${mode} is not signed in yet. Click "+ Add Gmail" to sign in.`,
            "error",
            false
          );
        }
      });
    }
  });
}

if (scanGeminiAccountsBtn) {
  scanGeminiAccountsBtn.addEventListener("click", () => {
    showStatus("Scanning browser for signed-in Gmail / Gemini accounts (u/0 to u/5)...", "info", true, 1);
    if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({ type: "SCAN_GEMINI_ACCOUNTS" }, (res) => {
        if (res && res.ok && Array.isArray(res.accounts)) {
          const currentMode = geminiAccountSelect ? geminiAccountSelect.value : "auto";
          populateGeminiAccountsDropdown(res.accounts, currentMode);
          if (res.accounts.length > 0) {
            const first = res.accounts[0];
            sessionIndicator.textContent = `${res.accounts.length} Gmail(s) Active`;
            sessionIndicator.classList.add("ok");
            const summary = res.accounts.map((a) => `u/${a.authUser} (${a.email})`).join(", ");
            showStatus(
              `Detected ${res.accounts.length} signed-in Gmail account(s): ${summary}`,
              "success",
              false,
              4
            );
          } else {
            showStatus("No signed-in Gemini accounts detected. Please sign in at gemini.google.com.", "error", false);
          }
        } else {
          showStatus("Could not scan accounts. Make sure you are signed into gemini.google.com.", "error", false);
        }
      });
    }
  });
}

if (addGeminiAccountBtn) {
  addGeminiAccountBtn.addEventListener("click", () => {
    const addUrl = "https://accounts.google.com/AddSession?hl=en&continue=https%3A%2F%2Fgemini.google.com%2Fapp";
    if (typeof chrome !== "undefined" && chrome.tabs && chrome.tabs.create) {
      chrome.tabs.create({ url: addUrl });
    } else {
      window.open(addUrl, "_blank");
    }
  });
}

checkSessionBtn.addEventListener("click", () => {
  const mode = geminiAccountSelect ? geminiAccountSelect.value : "auto";
  const explicitAuthUser = mode === "auto" ? null : parseInt(mode, 10);
  showStatus("Verifying Gemini session in background...", "info", true, 1);
  chrome.runtime.sendMessage({ type: "CHECK_SESSION", force: true, authUser: explicitAuthUser }, (res) => {
    if (res && res.ok) {
      const shortEmail = res.email ? res.email.split("@")[0] : `u/${res.authUser || 0}`;
      sessionIndicator.textContent = `u/${res.authUser || 0}: ${shortEmail}`;
      sessionIndicator.title = `${res.email || ""} • ${res.bl || ""}`;
      sessionIndicator.classList.add("ok");
      showStatus(
        `Gemini session active on u/${res.authUser || 0} (${res.email || "Default"})! Build: ${res.bl}`,
        "success",
        false,
        4
      );
    } else {
      sessionIndicator.textContent = "Session Inactive";
      sessionIndicator.classList.remove("ok");
      showStatus(res ? res.error : "Session check failed.", "error", false);
    }
  });
});

generateBtn.addEventListener("click", async () => {
  const workflowMode = workflowModeSelect.value;
  const rawPrompt = promptInput.value.trim();

  if (workflowMode === "img2img_file" && !currentReferenceDataUrl) {
    showStatus("Please select or drop a reference image first for Image-to-Image mode.", "error", false);
    return;
  }

  if (workflowMode !== "img2img_file" && !rawPrompt) {
    showStatus("Please enter a core scene/theme prompt (or click one of the Quick Theme Presets above).", "error", false);
    return;
  }

  saveFormState();

  const prompts =
    workflowMode === "img2img_file"
      ? [rawPrompt || currentReferenceFilename || "reference_image"]
      : batchModeCheckbox.checked
      ? rawPrompt.split("\n").map((s) => s.trim()).filter(Boolean)
      : [rawPrompt];

  const portraitWidth = parseInt(portraitWidthInput.value, 10) || 1620;
  const portraitHeight = parseInt(portraitHeightInput.value, 10) || 2880;
  const landscapeWidth = parseInt(landscapeWidthInput.value, 10) || 2800;
  const landscapeHeight = parseInt(landscapeHeightInput.value, 10) || 2400;
  const autoDownload = Boolean(autoDownloadCheckbox.checked);
  const customStages = isZedgeSetMode(workflowMode) ? getCustomStagePromptsFromDOM() : null;

  generateBtn.disabled = true;

  for (let i = 0; i < prompts.length; i++) {
    const currentPrompt = prompts[i];
    const batchPrefix = prompts.length > 1 ? `[Set ${i + 1}/${prompts.length}] ` : "";

    const modeDesc =
      workflowMode === "set_dual"
        ? "Dual Wallpaper Set (2× 1620×2880 JPG)"
        : workflowMode === "set_24h"
        ? "24-Hour Wallpaper Set (4× 1620×2880 JPG)"
        : workflowMode === "set_battery"
        ? "Battery Level Wallpaper Set (6× 1620×2880 JPG)"
        : "Wallpaper Pipeline";

    showStatus(
      `${batchPrefix}Running ${modeDesc}...`,
      "info",
      true,
      1
    );

    await new Promise((resolve) => {
      chrome.runtime.sendMessage(
        {
          type: "GENERATE_WALLPAPER_SET",
          options: {
            prompt: currentPrompt,
            negativePrompt: negativePromptInput ? negativePromptInput.value.trim() : DEFAULT_NEGATIVE_PROMPT,
            includeFoldableCompanion: includeFoldableCompanionCheckbox ? includeFoldableCompanionCheckbox.checked : false,
            landscapePrompt: landscapePromptInput.value.trim() || "make it landscape mode",
            workflowMode,
            customStages,
            storyArc: storyArcSelect.value || "auto",
            variationStrength: variationStrengthSelect.value || "clear",
            displayTarget: displayTargetSelect.value || "any",
            colorBoost: colorBoostSelect.value || "off",
            aiDirectorEnabled: aiDirectorEnabledCheckbox.checked,
            autoWriteMetadata: autoWriteMetadataCheckbox.checked,
            referenceDataUrl: currentReferenceDataUrl,
            referenceFilename: currentReferenceFilename || "reference_image.jpg",
            forceImagePrefix: forceImagePrefixCheckbox.checked,
            upscaleEnabled: upscaleEnabledCheckbox.checked,
            autoDownload,
            useExactZedgeNames: useExactZedgeNamesCheckbox.checked,
            subfolder: subfolderInput.value.trim(),
            portraitWidth,
            portraitHeight,
            landscapeWidth,
            landscapeHeight
          }
        },
        async (res) => {
          if (res && res.ok) {
            const actionDone = autoDownload
              ? `Auto-saved to Downloads/${subfolderInput.value.trim() || ""}`
              : "Ready in Studio Showcase — inspect AI Metadata, export Ready .ZIP + metadata.json, or Upload to Panel!";
            showStatus(
              `${batchPrefix}Completed! ${res.results.length} JPEG wallpaper(s) generated — ${actionDone}`,
              "success",
              false,
              4
            );
            const { history = [] } = await chrome.storage.local.get("history");
            renderGallery(history);
          } else {
            showStatus(
              `${batchPrefix}${res ? res.error : "Generation failed."}`,
              "error",
              false
            );
          }
          resolve();
        }
      );
    });
  }

  generateBtn.disabled = false;
});

clearHistoryBtn.addEventListener("click", async () => {
  await chrome.storage.local.set({ history: [] });
  renderGallery([]);
});

if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "STATUS_UPDATE" && msg.payload) {
    const { state, message, step } = msg.payload;
    if (state === "error") {
      showStatus(message, "error", false, step);
    } else if (state === "completed") {
      showStatus(message, "success", false, 4);
    } else {
      showStatus(message, "info", true, step);
    }
  }
  });
}

loadSavedState();
